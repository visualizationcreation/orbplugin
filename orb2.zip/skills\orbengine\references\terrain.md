# Terrain — finding the positions and writing them

Geometry decides where a position sits. This file decides **what the
positions are**, which is the harder half and the one that makes an orb
worth opening.

---

## The axes, as tests you can apply

The six directions are easy to state and easy to confuse in practice.
Each has a sentence test. Say the sentence out loud; if it does not
parse, the relationship is not that one.

### DOWN — finer resolution of the same thing

> *"X is one of the ways Y happens."*
> *"X is a part of Y."*

DOWN keeps the subject and increases resolution. The child is not a
different topic; it is the same topic seen closer.

### UP — coarser resolution, two kinds

> **part-of:** *"Y is the larger thing X is a part of."*
> **instance-of:** *"Y is the general case X is an instance of."*

These are genuinely different moves and the format carries both: `level`
gives the part-of parent, `upalt` gives the instance-of parent. **The
instance-of climb sheds the anchor faster** — going from "the 1907 panic"
to "financial panics" keeps you close, but going to "systems with
feedback delays" is two removals in one step. That asymmetry is what `ab`
records.

### LEFT / RIGHT — same resolution, different instance

> *"X and Y are two of the ways Z happens."*

The test is that **you can name Z**, and Z is the parent. If you cannot
name the question all the siblings answer, they are not siblings — you
have a list, not a band.

**This is the single most useful diagnostic in the file.** Write the
parent question above the band before writing any of its members:

> *Band 2 answers: "what does a teacher actually do in the first term?"*

Every candidate that does not answer that question is in the wrong band,
and most authoring errors are caught here rather than later.

### FORWARD / BACKWARD — consequence

> *"X is what follows from Y."*

Not time alone — implication. A consequence axis that is merely
chronological is usually a ring laid out sideways.

### The confusion that costs most

**DOWN versus RIGHT.** They feel similar because both narrow. The
discriminator: after moving, ask whether you are still talking about the
same thing at higher resolution (DOWN) or about a peer (RIGHT). "Open
syllables" under "the syllable" is DOWN. "Open syllables" beside "closed
syllables" is RIGHT. The same position can be both, to different parents
— that is normal and is what `level` plus `lon` encodes.

---

## Finding the bands in a subject

Do this before writing a single view. It is cheap to redo now and
expensive later.

**1. Write the subject as a full predicate.** Not "Spanish literacy" but
"Reading is taught by syllable before letter". The predicate form forces
a claim, and the claim is what the orb is about.

**2. Climb until you run out of honest ground.** Ask "what is this an
instance of?" repeatedly. Stop when the answer stops being *about the
subject* — usually two or three climbs. That is the top band, and it will
be small.

**3. Descend until you hit primitives.** Ask "what are the ways this
happens?" until the answers are things that do not decompose further
within this subject. That is the bottom band, also small.

**4. Name the parent question for each band between.** If you cannot
name it, that band does not exist yet and you have a gap in the middle,
which is where gaps usually are.

**5. Fill one meridian wedge first — top to bottom, a single branch.**
Then the next. This is the ordering that produces vertical coherence; see
`geometry.md`.

**The most common structural failure is a missing middle band.** An orb
jumps from framings to techniques with nothing between, and UP from a
technique lands on something three removals away. If a DOWN move feels
like a large drop, insert a band rather than accepting it.

---

## Reading or working — decide before writing a single label

People come to an orb for one of two reasons, and everything else follows
from which. Some are here to **find out** — they will read, the way they
read an encyclopaedia. Some are here to **make or do** — they want the
next move. The mode is set once, by `kind`, and then governs every label
in the file.

| | **READING orb** (`knowledge`, `rhythm`) | **WORKING orb** (`task`) |
| --- | --- | --- |
| why they opened it | to find something out | to make or do something |
| a position is | a claim about the world | a move on the work |
| grammar | **declarative** — subject + verb | **imperative** — bare verb, no subject |
| example | *Reading is taught by syllable before letter* | *Drill one consonant across all five vowels* |
| DOWN | finer resolution of the same thing | a finer-grained version of the same move |
| LEFT/RIGHT | other answers to the parent question | other moves you could make instead |
| FORWARD | what follows from it | what this move makes possible next |
| angles offer | a better question | the next action |
| it paid off if | they understood something | they can execute without asking |

### A reading orb's subject may be entirely dynamic

**This is the confusion the naming invites, so it is worth stating
plainly.** The split is not static subjects versus moving ones. It is the
reader's posture.

Photosynthesis is a process. A financial panic is a sequence. A rhythm
orb is *about nothing but* things moving through time. All three are
READING orbs — declarative throughout — because the reader is
understanding them, not performing them.

What makes an orb a working orb is not that its subject moves. **It is
that its positions are moves the reader makes.** Reach for `kind: task`
only when someone will act on each position, not when the topic happens
to involve action.

### Drift is the failure to watch for

The two modes are easy to slide between mid-file. A working orb that
opens with *"Cut the second paragraph"* and three positions later says
*"Concision improves readability"* has stopped offering moves and started
teaching — and the reader who came to act now has to translate. The
reverse happens too: a reading orb sliding into advice.

**The test is mechanical**, which is what keeps mode honest when the
framing is about intent. Read the band's labels as a flat list and ask
whether each could be preceded by *"you could…"*. In a working orb every
label passes. In a reading orb none does. Some passing and some not means
the file has drifted, and the parser flags it.

**A working file must not imply it can act.** A session performs the move
when you click the pad; a file only names it. That is a real reduction,
and `format.md` requires it be declared in the header rather than left
for the reader to discover.

---

## Writing the label

Below is the **noun-orb** rule. For task orbs, substitute "imperative"
for "predicate" throughout — everything else about labels holds
unchanged, including that the label must make a claim rather than name a
category.

**A full predicate, not a noun phrase.** This rule does more for orb
quality than every other rule in this skill combined, and it is the first
casualty of authoring in bulk.

| noun phrase | predicate |
| --- | --- |
| The Syllable Method | Reading is taught by syllable before letter |
| Orthographic Transparency | Transparency sets the ceiling on decoding speed |
| Vowel Drilling | A consonant is drilled across all five vowels before moving on |

A noun phrase is a filing category. It tells a reader what drawer they
are looking at and nothing about whether to open it. A predicate makes a
claim, and a claim can be surprising, contestable or dull — all three of
which are information a reader can act on.

**The test:** read the band's labels as a flat list, with nothing else.
If it reads like a table of contents, rewrite. If it reads like a set of
assertions someone might argue with, it is right.

---

## Writing the view

**Three tests, in order of how often they catch something.**

**1. The substitution test.** Could this view be pasted under a
neighbouring label with only cosmetic edits? If yes, it is describing the
band rather than the position, and the band is saying one thing n times.
This is the dominant way an orb gets thin while looking full.

**2. The specificity test.** Does the view commit to something that could
be wrong? Numbers, named cases, a boundary, a mechanism. A view that
cannot be false is a view that carries nothing. "This approach has
benefits and drawbacks" passes every validator and says nothing.

**3. The surprise test.** Would a well-read non-specialist already assume
this? If the whole view is what they would have guessed, the position is
a placeholder. At minimum, one sentence should tell them something they
did not have.

**Length.** 60 words is the validator's floor. 120–220 is the working
range. Longer is usually a position that should have been two.

**Structure that works:** open with the claim, give the mechanism or the
evidence, then name the boundary — where it stops being true. That last
move is what makes a view feel authored rather than generated, and it is
the one most often skipped.

---

## Writing the angles

Angles are copy-out prompts: the reader takes one and goes on. They are
the file's forward motion, two is the floor — **and what a good one looks
like depends entirely on which mode the file is in.** A curiosity prompt
handed to someone mid-build is useless, and a to-do handed to someone
reading is presumptuous.

### In a READING orb — a better question

- **a tension** — something in the view that pulls against something else
- **a boundary case** — where the claim starts to fail
- **a reader for whom it breaks** — who this does not serve

**The degenerate set:**

> *How do these relate?* · *Both involve…* ·
> *What are the implications?* · *Tell me more about this.*

These are not questions about the position; they are questions about
having a position.

### In a WORKING orb — the next action

- **a concrete move** the reader could make today
- **a check** that tells them whether this move worked
- **a fork** — the condition under which they would do the opposite

**The degenerate set, which is different and will otherwise appear
everywhere:**

> *Consider your options.* · *Think about the tradeoffs.* ·
> *Evaluate what works best for you.* · *Review and iterate.* ·
> *Assess your needs.*

These have the shape of advice and the content of none. They are what a
working angle collapses into when the author does not actually know the
next move — which is the signal to go find it, not to write around it.

**The working test is sharper than the reading one: could they do it
today without asking a follow-up question?** If the angle needs
clarification before it can be acted on, it is not an angle, it is a
topic.

### Both modes

The shared test still applies: **could this angle be attached to any
other position in the orb unchanged?** If yes, rewrite. It is describing
the orb rather than this position.

---

## Frontier honesty

If nothing lies below a position, declare `frontier: down` and the studio
renders a stated terminus. **Do not invent a plausible child to avoid an
edge.** In a session that was a small dishonesty; in a file it persists
and gets read by people who were not there.

The same applies to the ring. A band with three real members has three
members. Padding it to six so the ring looks full puts three positions in
the orb whose only property is that they are not the other three.

**`reduction:` is the file-scale version of the same honesty** — a
declared list of what this build does not carry. A file that declares its
gaps is complete; a file that hides them is broken.

---

## Scoring `ab` — the anchor

`ab` is anchor removals, 0–3, and it is the one judgement the studio
cannot compute. Score it in a **single pass at the end**, comparing each
view against the subject — scoring as you go lets the scale itself drift.

Run both halves of the strip test from `../orb/references/standalone.md`
on the position's own view against `subject`:

- **0** — the view is about the subject
- **1** — about something the subject is part of, or an instance of
- **2** — two removals; a reader would need the chain explained
- **3** — recognisably a different topic that the trail happens to reach

**A multi-band orb where every position reads `ab: 0` means the pass was
skipped**, and the studio warns. Genuine variation is expected: the top
band and the far side of the ring naturally carry more removal than the
subject's own wedge.

---

## What good looks like, in one paragraph

A reader opens the orb, sees five or six abstract claims across the top
band, picks one, descends a meridian into progressively more concrete
statements about the same branch, walks the ring and finds the ideas
arriving in a sensible near-to-far gradient, hits a floor that says it is
a floor, climbs back and lands where they left. Nothing they read could
have been pasted somewhere else. Every position offered them two real
questions. Nothing was padded and nothing was invented to avoid an edge.

Everything in this file is in service of that paragraph.
