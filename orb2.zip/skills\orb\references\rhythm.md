# Rhythm mode

**Module of orb v0.3.0 rev 4. Read when rhythm mode is invoked, or when
the offer condition below fires and the user accepts. Do not read it
otherwise — noun and verb mode need nothing here.**

Assertions for this module are A42–A57 in `references/testing.md`,
scenario S7. They are not restated here.

Rhythm mode is the third mode alongside noun and verb. The orb stops
browsing a subject's structure and starts browsing its **behaviour over
time** — where events recur, how the interval between them is changing,
which recurrences are real patterns and which are the archive playing
tricks.

**The one-line version: musical vocabulary is the interface, but every
musical word on the panel is backed by a count the turn already had to
write. A beat nobody can count is not a beat, it is a mood.**

---

## Why this mode needs harder rules than the other two

Noun mode's failure is drift — you end up somewhere else and nothing
says so. That is what the anchor fixed.

Rhythm mode's failure is worse, because it is **generative**. Hand any
sufficiently smart engine a topic and the word "cycle" and it will find
one, every time, on any data, in any direction. Historical pattern-talk
has no natural stopping condition: there is always another resonance,
always a rhyme, always a decade that maps onto this one if you squint.
The failure does not look like error. It looks like insight.

So this module does not ask the orb to be careful. Care is not
observable. Instead every reading in rhythm mode is **computed from a
list of dates the turn was already obliged to print**, and a reader who
disagrees can recount them. That is the same law that governs the rest
of the skill, applied where it is needed most.

**The rule that does the most work here, and the one to break last: a
period may never be claimed from two occurrences.** Two points define an
interval. Three define a rhythm, badly. The number of times a pattern
must recur before it may be called periodic is the entire difference
between historical analysis and astrology, and it is a countable
integer, so the panel counts it.

---

## Entering the mode

**Rhythm mode is never entered automatically.** Noun and verb are
auto-detected; rhythm is not, and the asymmetry is deliberate. An orb
that decides on its own to start finding cycles in current events has
appointed itself a forecaster. It must be asked.

**THE OFFER CONDITION — and it is a count, not a hunch.** Offer rhythm
mode when *the reading you have just written* contains **two or more
dated instances of the same kind of event**, separated by more than the
current position's natural span. Not when the topic feels historical.
Not when it feels like there might be something there. The trigger is a
property of text already on the page, so a reader can check whether the
offer was earned.

The offer is one line in the scenery, never a pad of its own on turn
one:

> *this reading names {n} dated recurrences — `rhythm` opens the
> timeline on them.*

If the count is under two, do not offer. A single dated event plus a
sense of significance is exactly the input that produces invented
cycles.

**The three-orb hook.** Where the build carries a multi-orb arrangement,
the offer condition is evaluated on the CENTRE orb only, and the flanking
orbs are what supply the left/right ring described below — each flank
holds one contemporaneous domain, and the coincidence reading is taken
across them. On a single-orb build the ring is traversed serially by
LEFT and RIGHT instead, and nothing else changes. Do not require the
multi-orb build for the mode to function; a mode that only runs in one
chrome is a mode that gets tested in one chrome.

---

## The axes are remapped, and the remap is announced

Rhythm mode is the only mode that changes what the six directions mean,
so it must say so on the turn it opens, in the pads' captions — the same
way pipeline, grid and cycle shapes already announce their LEFT/RIGHT.

| axis | noun mode | rhythm mode |
| --- | --- | --- |
| FORWARD / BACKWARD | consequence | **the timeline** — one step = one unit of the current scale |
| UP / DOWN | abstraction | **the time scale** — up widens (decade → century), down narrows (decade → year) |
| LEFT / RIGHT | the ring of siblings | **contemporaneous domains** — same window, adjacent field |

Each axis keeps its character. Forward still means "and then what",
literally now. Up still means broader — a wider window is a more
abstract view of the same subject, and the same things get lost climbing
it. The ring still holds siblings, but siblings in *time* rather than in
category: politics, economics, technology, culture and climate standing
at the same moment.

**LEFT and RIGHT are where this mode earns its keep.** A beat found in
one domain is a curiosity. The same beat found in an adjacent domain,
at a stable phase offset, is a finding — or a shared driver, which the
null check below exists to catch. Traversing the ring is how the orb
distinguishes the two, and it is the move to reach for when a cadence
reads *periodic* and the user asks "is this real".

**The timeline scrubber is a control, not a queue.** The movement panel's
click-to-append rule exists because a vector of six counts loses order in
a non-commutative space. A timeline position is not a move sequence — it
is a coordinate, and coordinates commute with themselves. So a scrubber
is legitimate here where a per-direction count slider is not. Scrubbing
records one jump on the trail, named by where it landed, and the trail
stays an undo stack.

---

## The instruments

Rhythm mode is the third column of the instrument table in the skill's
"Output format", which is the only place the instruments are enumerated.
**This module does not restate that table** — A19 grades the skill on
having exactly one enumeration, and a module that helpfully repeats it
for convenience is how three disagreeing lists got shipped last time.
Read the readings' NAMES there; what they MEAN is below.

Two are new to this mode: *cadence* in position 1 and *phase* in
position 3. The other three are unchanged and shared — in rhythm mode the
anchor is still the subject the user handed over, and the strip test
still runs on the words you just wrote. Drift is if anything more likely
here, because a timeline invites you to follow whatever is interesting
in 1870 rather than the thing you were asked about.

Grain reads off the DOWN fan as always: how finely does this *era*
divide? Some decades have honest yearly structure; some centuries are
one undifferentiated block in the record, and saying so is a true fact
about the terrain.

### CADENCE — instrument 1

Replaces *depth below*. It answers: **what kind of recurrence is this,
and how many times has it actually happened?**

Read it off the dated list in the reading. The turn must print the
dates — not "recurs roughly every generation" but the years. If you
cannot print the dates, the cadence is *once* by definition, and that is
the honest reading rather than a shape word that sounds researched.

From the dates, take the intervals `τᵢ` between consecutive events and
compute the burstiness of the sequence:

```
B = (σ_τ − μ_τ) / (σ_τ + μ_τ)

B ≈ 0    intervals are as variable as a random process — clustered by chance
B < 0    more regular than random  → something is imposing a clock
B > 0    bursty — long gaps broken by clusters
```

**The readings:**

| n | condition | reads | what you may say |
| --- | --- | --- | --- |
| 1 | — | *once* | no period, no rhythm, no projection |
| 2 | — | *pair* | one interval. **A period may NOT be named.** |
| ≥3 | B > 0.3 | *motif* | name the SHAPE; do not name a period |
| ≥3 | \|B\| ≤ 0.3 | *periodic* | a period may be named, as a range |
| ≥5 | B < −0.1 | *metronomic* | a period may be named tightly |

Four rules bind this gauge:

**A pair is not a rhythm, and the panel must not let it become one.**
Two dated events and an interval between them is the single most common
input to a false cycle, because the interval is always computable and
always sounds like a finding. On *pair* the phase gauge reads *undefined*
and the projection band is closed. This is not a caution the orb writes
in prose; it is a state the panel is in.

**B on fewer than five intervals is noisy, so report a word, not a
number.** With three or four intervals the burstiness estimate has no
precision worth displaying. Render the shape word; put the interval list
in the scenery so the reader can form their own view. A decimal implies
an accuracy the sample does not have — the numeric form is for the
scenery in long-record cases only.

**Metronomic almost always means an imposed clock, and you go looking
for it.** Human affairs do not produce sub-random regularity on their
own. When the gauge reads *metronomic*, the next obligation is to name
the calendar responsible — an election cycle, a fiscal year, a term
limit, a treaty renewal, a crop season, a scheduled review. If you
cannot find one, say the reading is anomalous rather than impressive.
Institutional clocks are the commonest true source of historical
periodicity and the least interesting one, and mistaking an imposed
schedule for an emergent cycle is the mode's most embarrassing
available failure.

**Motif is a first-class reading, not a downgrade.** Most real
historical patterns recur *irregularly* — same shape, unpredictable
spacing. Periodic analysis is blind to them; a reader looking only for
periods will either miss them or force them into a period they do not
have. On *motif* the job is to characterise the shape — what precedes
it, what the sequence of stages is, what it looks like from inside — and
to explicitly decline the period. "This has happened five times, in an
irregular cluster, and here is its structure" is a stronger claim than a
fabricated interval, not a weaker one.

### PHASE — instrument 3

Replaces *ring width*. It answers: **where in the cycle is the position
standing right now?**

Renders only when cadence is *periodic* or *metronomic*. On *motif* it
reads *no phase — motif only*. On *pair* and *once* it reads *undefined*
and the gauge is greyed rather than blank, because a blank cell reads as
an oversight and a greyed one reads as a fact.

```
early · rising · peak · falling · late · trough
```

**Phase is stated from a named zero, every time.** "Late in the cycle"
is not a reading; "late, measured from the 2008 trough" is. A phase
without a reference event cannot be checked and cannot be wrong, which
is precisely why it is tempting. Name the zero in the gauge caption.

Phase is also the mode's whole payoff, and worth being explicit about:
finding the period is the setup. Knowing where in the cycle you are
standing is what tells you what the system is currently sensitive to,
what is likely to come next, and where an intervention would land.
A reading that establishes a period and then says nothing about present
position has done the arithmetic and skipped the point.

### The span readout — a control's output, not a gauge

The timeline control reports three things, and the third is the one that
matters:

```
scale: decade   ·   window: 1890–1990   ·   record: dense from 1920, thin before
```

**RECORD DENSITY IS PART OF THE READOUT AND IS NOT OPTIONAL.** This is
the single most valuable import from time-series practice into
historical reading, and it kills more false patterns than any other
check: **you cannot see a rhythm faster than your records, and a rise in
documentation looks exactly like a rise in events.**

Concretely — apparent accelerations toward the present are the default
artifact of every archive, because recent decades are better recorded
than distant ones. A "quickening" that coincides with the arrival of
newspapers, or statistics bureaus, or the internet, is a claim about the
record before it is a claim about the world. Likewise a pattern with a
period shorter than the record's resolution cannot be observed at all —
annual data cannot show a seasonal rhythm, and decadal summaries cannot
show a five-year one.

So: state where the record thickens, and when a trend runs in the same
direction as the record's density, **say so in the same sentence as the
trend**. That sentence is checkable. A general caveat parked at the
bottom of the turn is not.

---

## The three bands — how a rhythm reading is written

Every rhythm reading is written in three labelled bands, in this order,
always. The bands are the mode's core epistemic device: they keep what
happened, what it resembles, and what might follow from dissolving into
each other, which is the exact dissolution that makes historical
pattern-talk untrustworthy.

### RECORD — what is documented

Dated events, printed. This band is where the cadence gauge gets its
input, so it cannot be skipped or summarised into prose without dates.
Sources or the honest absence of them. If the record is contested — and
for anything interesting it usually is — say who contests it.

Countable signature: **this band contains dates.** A RECORD band with no
years in it has not been written.

### RHYME — what it resembles

The interpretive layer. Analogy, structural similarity, the sense in
which this moment is like that one.

**Two obligations, both checkable:**

**One — name what differs, not only what matches.** An analogy offered
without its disanalogy is advocacy. The band must contain at least one
clause of the form "but unlike then, now —". A reader can look for that
clause.

**Two — the NULL CHECK. Before a rhyme is offered, name which of these
four could produce the appearance without any rhythm existing, and
address it.** One named and dismissed, minimum. This is the historical
form of surrogate testing: the point is not to prove the pattern, it is
to establish that a cheaper explanation was considered and found
wanting.

- **SHARED DRIVER.** Two things move together because a third thing
  moves them both, with no connection between them. Two national
  economies cycling in step may be coupled — or may both be tracking a
  commodity price. Two industries innovating in the same decade may be
  responding to one enabling technology. **This is the commonest false
  positive in cross-domain pattern-finding by a wide margin**, and it is
  why the LEFT/RIGHT ring must be traversed sceptically: finding the
  same beat in a neighbouring domain is as much evidence of a common
  cause as of a real coupling. Rule out the third thing before claiming
  the connection.
- **BASE RATE.** The event is common enough that recurrence at this
  spacing is unremarkable. If financial panics happen somewhere every
  few years, finding three at twenty-year intervals in one country is
  not a discovery. Ask what the expected count would be if the timing
  were arbitrary.
- **SELECTION.** The archive was searched until matches appeared. Every
  century contains a year that resembles this one. The question is
  whether the pattern was specified before the search or after it, and
  the honest answer is usually after — say so.
- **DEFINITION DRIFT.** The label is stable while the measured thing is
  not. "Revolution" in 1789, 1917 and 2011; "recession" before and after
  the NBER definition; "pandemic" before and after the germ theory.
  A recurrence of a word is not a recurrence of an event.

### PROJECTION — what might follow

The speculative band, and the one with the hardest gate.

**PROJECTION IS CLOSED unless cadence reads *periodic* or *metronomic*,
or a *motif* has recurred at least four times.** On *once* and *pair* the
band renders as a closed state with its reason — *projection closed:
cadence reads pair, one interval* — rather than being silently absent.
A closed band that says why is a fact about the terrain; a missing band
is an oversight the reader has to notice.

**THE BAND IS A POOL, NOT A PROJECTION.** A single forecast is the
weakest available output and the mode does not emit one. Where the band
is open it carries **three to five members**, and the reason is not
even-handedness — it is accuracy. A pool of independent estimates
outperforms any individual member on average, reliably enough that it is
the default in every field that keeps score: ensemble weather
forecasting, aggregated election models, forecasting tournaments.

The mechanism is worth stating exactly, because it is also the mechanism
by which pooling FAILS. Independent errors partly cancel when averaged;
error falls roughly as the square root of the number of independent
members. **Shared errors do not cancel at all.** Members reasoning from
the same assumption make the same mistake together and produce agreement
that looks like confirmation and carries no information. This is the
same lesson as SHARED DRIVER in the RHYME band, arriving a second time
from the other direction: there, a common cause fakes a pattern; here, a
common assumption fakes a consensus. Both are the mode's characteristic
false positive, and both are caught the same way — by naming the thing
that is shared.

So the pool has a distinctness requirement, and it is countable:

**Each member NAMES THE MECHANISM that would produce it, and no two
members may name the same one.** Three members reading "continues",
"continues faster", "continues more slowly" are not three members. That
is one projection wearing error bars — the same mechanism at three
magnitudes — and it is the projection-band form of the padding the fan
rules already forbid at coarse grain. Real members differ in *what
happens*, not in *how much*: the cycle continues, the cycle breaks
because its driver was removed, the cycle was never there and the record
was thin. **Count distinct mechanisms, not members**, and if two
collapse into one, say so and report the smaller number.

**THE SPREAD IS THE OUTPUT.** This is the part most easily missed. The
disagreement among the members is not a failure to reach an answer — it
IS the uncertainty estimate, and it is the most honest quantity the band
produces. Render it as a line beneath the pool:

> *spread: {converged | split | dispersed} across {n} distinct
> mechanisms*

- **converged** — members differ in mechanism but agree on the
  observable outcome. This is the only configuration that licenses the
  band's strongest confidence word, and only after the mechanisms have
  been confirmed distinct.
- **split** — members cluster into two incompatible outcomes. Say what
  the fork turns on. A named fork is more useful than a blend, because
  it tells the user what to watch.
- **dispersed** — members go in several directions. The honest headline
  is that the pattern does not constrain the future, and *cannot say* is
  the correct finish.

Spread renders as a line in the band rather than as a sixth gauge. The
instrument panel is five readings and stays five; this is the same
arrangement reversibility already has in verb mode — dedicated chrome
that fires exactly when it matters beats a permanent gauge that mostly
reads nothing.

**DO NOT AVERAGE THE MEMBERS.** Pooling *probabilities of one event* is
legitimate arithmetic. Pooling *distinct scenarios* is not, and the
difference matters more here than anywhere else in the mode, because
scenarios are what a timeline produces. The average of "the alliance
holds" and "the alliance collapses" is not a half-collapse; it is a
fourth outcome nobody holds and that may be structurally impossible.
Report the SET and the spread, name which member you find strongest and
why, and never synthesise a blend. Where the pooled quantity genuinely
is one number — a date, a magnitude — take the MEDIAN rather than the
mean, so one wild member cannot drag the estimate.

One asymmetry is worth knowing and is easy to get backwards: when
members are genuinely independent and they converge, the pooled estimate
should be held **more** confidently than any single member warrants, not
less. Averaging independent evidence is systematically underconfident.
But this applies only where the members are actually independent — which
is exactly the thing the mechanism-naming requirement exists to
establish, and exactly the thing a pool of rewordings does not have. Do
not reach for this without having done that work first.

**Every member carries its own falsifier with a date attached.**

> *If {specific observable} has not occurred by {year}, this member was
> wrong.*

The count is per member, not per band: a four-member pool carries four
falsifiers. This is what makes the pool a real forecast rather than a
hedge — a set of scenarios with no tripwires is unfalsifiable as a
group, because whatever happens, some member resembles it. Falsifiers
are what stop a pool from being a way of being right no matter what.

No falsifier, no projection. This is the one requirement that most
reliably separates analysis from prophecy, and it is trivially checkable
— the sentence is either there or it is not. It also does something
useful for the user: a projection with a date and a tripwire is
something they can actually file and return to.

**Confidence language is bounded.** The projection band may say *likely*,
*plausible*, *possible* or *cannot say*, and the last is a legitimate
finish to the band. It may not say *will*, *inevitable*, *due*, or
*overdue*. **"Due" is specifically forbidden** and deserves its own
sentence: it smuggles in the gambler's fallacy wearing the costume of
periodicity. A cycle being late is not evidence it is about to arrive.
For a genuinely periodic process the expected wait from now is what the
model says it is regardless of how long you have already waited, and for
a bursty one — which most historical processes are — a long gap is
weak evidence the process has *changed*, not that it is owed.

---

## The musical vocabulary, and what each word is backed by

The musical terms are the interface language and should be used freely —
they are why this mode is legible, and they carry real structural
intuitions. But each one is defined by an instrument, not by feel. Where
the backing is absent, the word is not available.

| word | what it means here | backed by | not available when |
| --- | --- | --- | --- |
| **beat** | one recurrence of the event | a printed date | — |
| **period** | the interval between beats | cadence ≥ *periodic* | cadence is *once*, *pair* or *motif* |
| **tempo** | the trend in that interval | ≥4 intervals, direction stated | fewer than 4 |
| **accelerando / ritardando** | the interval shortening / lengthening | same, plus the record-density check | the record thickens in the same direction |
| **motif** | a recurring shape without a fixed period | cadence *motif*, shape described | shape not described |
| **rest** | a documented gap where the beat was expected | a named expected beat that did not occur | no expectation was established first |
| **syncopation** | the event lands off the established beat | an established beat to be off from | cadence below *periodic* |
| **crescendo** | successive beats increasing in magnitude | a stated magnitude measure, same units | magnitude is impressionistic |
| **counterpoint** | two domains, two beats, stable offset | both cadences ≥ *periodic*, null check passed | either domain reads *motif* or below |
| **coincidence** | the two beats arriving together | both periods named, arithmetic shown | either period is inferred |
| **resolution** | phases converging toward alignment | phase defined in both domains | phase reads *undefined* anywhere |
| **coda** | the pattern demonstrably ending | a named terminating cause | the pattern merely stopped being recorded |
| **pool** | the set of projection members | ≥3 distinct named mechanisms | members differ by degree only |
| **spread** | disagreement across the pool | the pool's own members, counted | fewer than 3 distinct mechanisms |

Three of these repay extra care:

**REST is the mode's most underused move.** A beat that was expected and
did not arrive is often more informative than one that did — it dates the
moment something changed. But a rest can only be read against an
expectation that was established *first*, from prior beats. Declaring a
rest retroactively, to explain a gap that broke your pattern, is how a
falsified period gets rescued instead of abandoned. Establish the beat,
then note the miss, in that order, and the order is visible in the text.

**CRESCENDO has a mechanism question attached.** When the rate or
magnitude of events is rising, there are two different worlds:
events are triggering further events (contagion — each occurrence
raises the chance of the next), or the background conditions have
shifted and the events are independent responses to a common change.
These look identical in a count. They differ in what to expect next:
self-exciting sequences decay back on their own once triggering stops,
while a raised background persists until the conditions revert. **Ask
which one, and say which one you think it is and why** — the evidence is
whether individual events can be shown to have produced their
successors. This is the most decision-relevant distinction the mode can
draw, and it is invisible unless you go looking.

**COINCIDENCE arithmetic is where numerology enters.** Two cycles of
period p and q realign every LCM(p, q) — and that number is always
computable, always sounds significant, and is meaningless unless both
periods are real. Compute it only when both cadences read *periodic* or
better, show the arithmetic, and state the uncertainty in each period.
Two periods each uncertain by ±20% produce an alignment date uncertain
by decades, which is usually the honest headline. The mode's most
seductive available output is a precise date derived from two imprecise
numbers.

---

## Coupling across domains — what the ring is actually for

When a beat is found in two domains at once, one further distinction is
worth drawing, because it changes the interpretation entirely.

Systems locked to a common clock **do not sit in phase — they sit at a
stable offset**, and the size of that offset is set by how far each
system's natural pace differs from the clock. This is why regulatory
response reliably trails financial crisis by a characteristic interval
rather than arriving with it, and why the lag is roughly the same length
each time.

So: when two domains share a beat, **measure the offset and check
whether it is stable across recurrences**. A stable offset is real
evidence of coupling or common entrainment. A wandering offset means the
two are unrelated and you found the same period twice by chance — which,
given how many candidate periods exist and how many domains you can
check, will happen regularly. Print the offsets. Three offsets that read
"4 years, 5 years, 4 years" support the claim; "2 years, 11 years, 6
years" refute it, and the refutation is visible in the same list.

---

## What does not change

Rhythm mode alters the axes, two instruments and the reading's internal
structure. **It alters nothing else, and specifically:**

- The turn contract is unchanged: position · instruments including the
  anchor · delta · scenery · reading · at most one image on turn one and
  two after · the moves · the settings strip · **the exit line**.
- The exit line is still mandatory, still a caption, still never a
  button, still last.
- The anchor still runs the strip test every turn on the words just
  written. A timeline is a strong invitation to drift and the gauge does
  not get a holiday for it.
- The frontier rules still hold, and **the present is a frontier** —
  the same kind of edge as the depth frontier, handled the same way. Do
  not fabricate past it. The projection band is not an exception to the
  frontier; it is what the frontier's compass looks like in this mode,
  and it is gated accordingly.
- Photographs still key to the current position, which in this mode
  means the position's *era*. A timeline position with a real
  photographic referent should carry one; the drought counts as always.
- Creative mode still applies and is still off by default. In rhythm
  mode it loosens the RHYME band's reach — stranger analogies, further
  domains — and **loosens nothing in RECORD or PROJECTION**. Creative
  mode may not open a closed projection band, may not lower a cadence
  threshold, and may not waive a falsifier. If it could, it would be a
  switch for turning off the only rules that matter, and users would
  find it immediately.

---
