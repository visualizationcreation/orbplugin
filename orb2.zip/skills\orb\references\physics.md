# orb — physics

Geometry, variety, construction and motion. The instruments, the output
format and the terrain-honesty rules live in `SKILL.md`; the chrome lives
in `references/cockpit.md`. Nothing here is restated there.

---

## Shape detection — the geometry fits the topic, the sphere stays

**Shape is not a classification you assert. It is what the instruments
read.** Never announce a shape that contradicts your own gauges. Take the
readings honestly and the shape names below are simply labels for the
resulting profile:

- wide ring width, short reach → an ORB (centered)
- narrow ring width, long reach → a LINE (sequence)
- deep depth-below with a wide ring at every level → a TREE (taxonomy)
- a ring that closes within a few steps → a CYCLE
- ring width that comes as a PAIR (7 × 18) → a GRID (crossed axes)
- wide ring and long reach in both directions, shallow below → a NETWORK
- depth below reading zero → the FRONTIER

The user never has to learn a taxonomy, and neither do you: read the
gauges, then name what they say. In verb mode the same holds for the work
shapes above — blocked is unmet reach backward, pipeline is long reach
forward, polish is low distance-to-done with coarse grain, fork is
options-open of two. Blank page versus draft in hand is the one genuine
binary: does an artifact exist yet.

Note what the third axis repaired. Older versions put TIME on left/right
for sequence topics, which let two axes mean the same thing. Time belongs
on the thread. Left and right are facets in every shape, always.

- **centered** (default): a topic with facets — the classic orb.
- **sequence** (line): histories, processes, biographies. LEFT/RIGHT
  become EARLIER/LATER along the line.
- **cycle** (ring): water cycle, seasons, circle of fifths. LEFT/RIGHT
  move around the phase ring; DOWN enters the mechanics of the current
  phase; there is no "start."
- **taxonomy** (tree): species, languages, file systems. DOWN branches
  and widens (offer the branch fan); UP is the parent.
- **crossed-axes** (grid): periodic table, verb conjugation. LEFT/RIGHT
  walk one axis; note the second axis explicitly so up/down can walk it
  at the same abstraction level when the user wants.
- **network**: dense cross-linked fields. LEFT/RIGHT go to the
  strongest-linked neighbors.

The SPHERE remains the interface in all cases — movement is always
up/down/left/right on the orb — but the detected shape redefines what
the axes MEAN, and the header `.ob-meta` states it, and a shape that redefines LEFT and
RIGHT says so in the pads' captions — not in the position line.
Shape is a measurement, not decoration: classify from the real
structure, and default to centered (noun) or draft-in-hand (verb) when
unclear.

## Branch fans — handling variety in each direction

A direction almost always holds more than one honest destination.
EVERY direction pad carries branches by DEFAULT: the primary (best)
destination prominent, plus 1–2 alternates in its fan — every live pad,
every turn **from stop two onward**. Stop one is governed entirely by the
turn-one manifest in `SKILL.md`, which permits exactly one fan alternate
and names which; this file does not restate it and does not override it.
An earlier revision had three different rules for turn-one fans across
two files, which is the restatement failure the split was supposed to
prevent.
In widget mode the fan renders VISIBLY beneath its pad; never behind a
hover or a `display:none`, both of which arrive blank under streaming.
In text mode, letter them under the direction (2a, 2b). Field of view
counts AXES; branches live inside the directions those axes carry. Only
omit a pad's fan for one of the three fixed reasons below. The older
wording here was "scarcity must be real, never laziness", which `SKILL.md`
identifies as unenforceable — and which survived in this paragraph two
lines above its own replacement. Every branch must be real terrain; fans
express variety, never padding. When a fan CLOSES, cite one of the three fixed reasons in
SKILL.md ("Grain — instrument 5"); a closure with no cited reason is
laziness by definition.

**UP's fan outranks every rule that would close it.** Coarse grain
closes the fans; the compass form has no room for them; a frontier closes
them all — and UP's fan survives all three, because it is the only place
`instance-of` can be chosen and closing it makes drift invisible again.
The consequence for the compass is stated rather than left implied: **the
compass form is unavailable in noun mode whenever UP is live.** Use the
stack.

**UP's fan is special and is not optional.** UP is two moves — part-of
and instance-of — and the primary is part-of unless part-of would
retrace (see `SKILL.md`). instance-of is UP's fan alternate, labelled
anchor-shedding, every turn UP is live. That is the mechanism that turns
drift from something that happens into something the user chose.

**Where fans are closed, the anchor-shedding label survives on the pad.**
At a frontier every fan closes, but a frontier's UP is *the category the
obstacle belongs to* — an instance-of by definition. So the label moves
onto the pad caption itself. A closed fan may never be the reason a
shedding move goes unlabelled; the label is a property of the move, not
of the fan.

In verb mode a fan holds variants of the same move, not different
moves: DOWN's fan might be "write it warm", "write it blunt", "write it
in their words". The pad is the direction; the fan is the register.

## The triangulator — finding a destination rather than a bearing

The six directions answer *how do I get there*. The triangulator answers
*where should I go*. It is a CONSTRUCTION, not a seventh axis: it takes
two known positions as a base and returns a third point that neither
contains, plus the route to it. Its output is a destination the flight
system can then execute.

**Invoking it.** "Triangulate left and right", "what connects these
two", "what do stops 2 and 5 have in common", "find the third point".
Available in noun, verb and mixed mode, at any time.

**And once, on its own initiative.** When ANCHOR reads *out of sight*,
offer a triangulation of **anchor × current position** as a pad, without
being asked. This is the single exception to invocation-only, and it
exists because this skill already identified trail-pair triangulation as
"the most underused source" — answering *what have I actually been
circling* — and then gated the only built-in drift detector behind a user
who has no way to know it is there. If the base turns out degenerate, say
so: an anchor and a position with nothing but a triviality joining them
is the strongest possible evidence the session has left its subject.

**The base.** Any two positions that are NOT on the same axis. Left and
right works. Left and forward works. Two positions from the trail works,
and is the most underused source — triangulating two stops four moves
apart answers "what have I actually been circling", which none of the
six directions can ask. **UP · part-of and DOWN cannot form a base**:
they are opposite ends of one containment line, and three collinear
points make no triangle. Say so rather than forcing it. But
`UP · instance-of` and DOWN are NOT collinear — only part-of is
containment — so that pair is a legal base, and often a revealing one.

**The apex.** The thing both base points genuinely imply and neither
states. In noun mode it is a shared structure, mechanism or principle.
In verb mode it is the move both options are really reaching for. State
the apex, then state the route to it in directions, so the user can fly
there rather than teleport.

**The two readings, reported on invocation only** — do not add them to
the permanent panel:

- *base width* — narrow (adjacent, obviously kin) to wide (barely
  related, different rings or different threads).
- *apex distance* — near or far. It follows from base width: a wide base
  forces an apex abstract enough to contain both, so it lands further out
  and feels stranger.

**The engine must be able to FAIL, and this decides whether it is worth
anything.** Widen a base far enough and some commonality can always be
manufactured — "both involve time", "both are systems". A triangulator
that always succeeds is a triangulator that lies. When the only thing
joining two points is a triviality, report **degenerate**: say plainly
that these two do not triangulate, name the trivial link you rejected,
and offer a narrower base instead. The absence of a third point is a
real finding, exactly as the frontier is a real place.

Creative mode is the WIDE-BASE POLICY on this same engine — see below.

## Flying — chained moves

The user may compose a sequence rather than a single click: "two right,
two up, one forward", "3F 2L", "fly me four down."

- **A chain is a SEQUENCE, not a vector.** The orb is non-commutative:
  up-then-right lands somewhere different from right-then-up, because
  the ring at a higher altitude has different neighbours. Execute in the
  order given. When a different order would land somewhere materially
  different, say so in one line.
- **Movement always happens ONE FRAME AT A TIME.** Sliders and counts set
  the INTENDED distance; they never authorise a jump. Every intermediate
  position is a real place, is somewhere the user might want to stop,
  and in verb mode is performing real work they need to see. Never
  collapse a flight into a summary of where it ended.
- **Frame weight scales; frame count does not.** Intermediate frames are
  compact — position, what changed, and an illustration only if that
  stop earns one. The destination frame is full. But every stop is a
  frame, and the user can halt at any of them.
- **A chain stops at the terrain, not at the count.** If the ring runs
  out, the depth ends, the reach terminates, or a verb move is not
  available, HALT at the last real position and say which move failed
  and why. Never fly through terrain that is not there. Grain binds this
  too — "two right" may not exist on coarse ground.
- **In verb mode a chain performs work at every step.** That is a great
  deal of commitment in one instruction. Halt and ARM before any one-way
  move rather than flying through it, and record every intermediate
  state so the chain is undoable step by step, not only as a whole.
- **Preview before firing: name one stop, and say why only one.** Not
  because stop two is invisible — often it is perfectly visible — but
  because the flight may HALT before reaching it, and a named stop is a
  promise. This is a commitment claim, not a visibility claim, and
  saying so removes the contradiction of a "gauge" with its needle glued
  at one.
- **Every frame reports ANCHOR, and the strip test runs at every frame.**
  A chain is where drift accumulates fastest, because nobody is steering
  between the frames — which is exactly why the anchor is measured per
  frame rather than accumulated from move types the queue cannot even
  express. **The pre-flight line states the projected anchor at the
  destination**, and says plainly when a chain will leave the subject
  behind. **A frame that crosses to `2 removed` carries a wired
  halt-and-return affordance**, since flight frames are already
  clickable; the return pad has no slot mid-flight and the counterweight
  must not simply vanish for the duration of the manoeuvre.

## Creative mode — the eccentric compass

Creative mode is not a instruction to have taste. It is one parameter on
the triangulator: **widen the base.** Default mode triangulates near
pairs and gets modest, useful syntheses. Creative mode triangulates
distant pairs — facets from different rings, positions from opposite ends
of the trail, a point on this thread against a point on another — and the
apex therefore lands further out and reads as strange. Same engine, one
setting. This is the mechanism behind everything below, and the
degenerate verdict applies with MORE force at wide bases, not less: the
wider you push, the more often the honest answer is that no third point
exists.

When creative mode is ON, the physics stay identical but the compass
gets deliberately strange.

In NOUN mode, destination selection changes:

- At least half the MOVES each turn must be eccentric: strange-but-real
  connections — cross-domain leaps (the order book's DOWN might lead to
  ant-colony foraging math), historical oddities, obscure-but-true
  adjacencies, places a sensible navigator would never suggest.
- One option each turn is a **WILDCARD** door: labeled with a mystery or
  question rather than a plain destination ("the room where this idea
  was almost lost", "what this looks like to a bee"), resolving to a
  real topic when chosen.
- The VIEW may take more voice and wonder; illustrations may get
  whimsical.

In VERB mode, the MOVES get strange rather than the destinations:

- At least half the pads become moves a sensible collaborator would not
  propose: constraint injections ("write it without the word you keep
  leaning on"), inversions ("argue the opposite and keep whatever
  survives"), transplants ("do it the way a safety card would"),
  amputations ("delete the best line and rebuild around the hole").
- The WILDCARD pad is a move with an undisclosed rule, revealed only
  once it has been performed.
- Strange moves are still really performed, and the instruments stay
  truthful about what they cost.

Eccentric means eccentric SELECTION, never fabrication — and that is an
adjective, not a check, so here is the check: **every eccentric
destination must survive being named as an ordinary claim.** Write the
connection as a flat sentence with no wonder in it. "The order book and
ant-colony foraging both allocate scarce attention under competition" is
a claim you can argue with. If the flat version is not defensible, the
door was fabricated and the strangeness was doing the work.

**The flat sentence must reach the card**, as the pad's `.ob-sub` line —
a check performed silently is not a check. And it is graded by the
triangulator's own degenerate test, stated above and until now
unconnected to this one: substitute either term for a random third topic,
and if the sentence stays true ("both involve time", "both are systems"),
the door is degenerate and does not render.

Terrain honesty rules apply in full: every strange door leads somewhere
real, and every strange move does something real to the work. Creative
mode changes which doors you offer — not whether the rooms behind them
exist. It does not change the ANCHOR reading either: a wide-base
triangulation that lands somewhere strange is still measured against the
subject the user handed over.

When OFF (default), destinations are the most informative and natural
neighbors, and moves are the ones a strong collaborator would actually
make next.
