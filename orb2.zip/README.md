# orb2

The Informational Dimensions orb navigator, second generation.

Three skills:

- **orb** — the live clickable session.
- **orbprint** — emits one self-contained HTML file that renders itself.
- **orbengine** — authors a `.orb.txt` terrain file for Orb Studio.

## 1.2.1 — tested against a real orb

Built a fifteen-position, four-band orb end to end and looked at the
output rather than the warnings. Four things came back:

- **Wedge width was a no-op.** `min(2H, max(X, 2H))` is always `2H`, so
  every wedge filled its maximum width regardless of how alike its
  children were — siblings with the smallest break in the band came out
  the furthest apart. Sizing is now anchored to legibility: each wedge is
  guaranteed the arc it needs, and only the surplus is distributed by
  break.
- **Breaks barely mattered.** With sizing capped on parent spacing,
  careful scoring and flat 0.5 scoring produced the same ring to within
  4°. They now differ by a mean of 10°, up to 26° per position, and
  randomised breaks trigger four warnings.
- **The subject drifted off `lon 0`.** Hierarchical allocation inherits
  rotation from the band above. Pass `subjectId` and the whole orb is
  rigidly rotated to restore it.
- **`coherence-drift` was miscalibrated** — it tested a v1.1 property
  against a v1.2 design and fired on correctly authored orbs. Removed.
  The antipodal law is checked in `orb-validate.js` against view text,
  which is the only place it can honestly be tested.

New warning: `parents-too-tight`, when a wedge needs more arc than its
neighbours leave — a fact about the band above, reported rather than
absorbed.

## 1.2.0 — the fold is found, not fixed

Arc is allocated in proportion to **break** — how unlike each neighbouring
pair is — rather than scaled linearly from ring distance. The widest gap
that results **is** the fold. Nobody chooses it.

Allocation is **hierarchical**: children sit inside their own parent's
wedge, breaks space them within it, and the boundaries between wedges are
inherited from the band above. So a large break at one level becomes the
empty arc its children inherit at the next.

**Meridian coherence is now a consequence rather than an audit.** On an
eight-position, three-parent test band, flat allocation left children a
mean of 34 degrees from their parents, worst case 74. Hierarchical
allocation gives 19 and 31, with no violations.

`brk` is scored independently and must not be derived from adjacent `d`
differences — deriving it reproduces the previous version exactly, so it
adds nothing.

New warnings: `no-breaks`, `no-fold`, `break-belongs-above`,
`coherence-drift`. New validator check: view similarity must fall off
with angular distance, which is the file-checkable form of the antipodal
law and the first thing to actually test it.

## 1.1.0

Placement became computed rather than eyeballed: `placement.js` and
`placement.md` in orbengine, plus validator checks for colliding labels,
band capacity, and `ab`/ring-distance collinearity.
