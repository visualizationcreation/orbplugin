# orb — test suite

What this skill is graded against. Every assertion below is checkable
from a transcript by someone who did not write the run — that is the
whole design constraint. A rule that can only be verified by asking the
model whether it followed the rule is not tested, it is trusted.

Run the scenarios as independent agents against the assembled skill, then
read the outputs. The assertions catch structure. They cannot catch
whether it reads well, and *"do the outputs make clean sense"* is a
human question.

---

## Scenarios

**S1 · Concrete noun.** A specific building, place, object or artwork.
Eight stops, user-steered, at least two UP moves. *Watching for:* does
the anchor reading stay honest, does the photograph rule fire at least
once, does an instance-of UP get labelled as anchor-shedding.

**S2 · Abstract noun.** A concept with no physical referent — a legal
doctrine, a mathematical result, an economic mechanism. *Watching for:*
does the photograph rule decline gracefully and name a referent class
each time, and does the anchor stay meaningful when there was never
anything to photograph. This scenario exists because the drift that
prompted rev 3 was first visible as a photograph drought.

**S3 · Verb mode.** A real drafting task with a named artifact.
*Watching for:* does clicking PERFORM work rather than describe it, does
options-open move in both directions, is the cost note ever missing or
hedged, does the anchor catch a session that has wandered onto a
different artifact.

**S4 · Frontier-heavy.** A topic whose floor is close — an open research
question, or a task blocked on something the session cannot reach.
*Watching for:* blocker typing from the seven, the frontier compass obeying
the axis grammar, and the ceiling frontier when driven upward.

**S5 · Long chained flight.** Six or more composed moves. *Watching for:*
one frame per move, anchor reported per frame, a halt on terrain rather
than on a count, and a pre-flight warning if the chain will take the
anchor out of sight.

**S6 · Standalone build.** An explicit ask for an orb as a file, on a
subject with real causal structure either side of it. *Watching for:*
whether the build declares a reduction and then honours it, whether the
terrain is authored through to the outer worlds rather than stubbed, and
whether the anchor is referential rather than a restatement of distance.
The reduction table is the first thing to read: everything it places out
of scope must be absent, not faked.

**S7 · Rhythm mode.** A topic with real dated recurrence — a policy area,
a market, a technology, a conflict. Run it twice: once on a subject with
five or more documented instances, once on a subject with exactly TWO.
*Watching for:* whether the two-instance run refuses to name a period,
whether every analogy names a null cause, whether every projection
carries a dated falsifier, and whether the anchor survives a century of
scrubbing. **The two-instance run is the important half.** The
five-instance run tests whether the mode works; the two-instance run
tests whether it stops, and a mode that only ever produces findings has
no stopping condition and is therefore not producing findings.

---

## The pattern tests

Four rounds of scenario testing found that the same six failure shapes
keep recurring, and testing for the SHAPE finds more than testing for the
feature. Run these against any future revision, before the scenarios.

**P1 · The repair-collision test.** For every rule added since the last
revision, name the slot it writes to and every other rule claiming that
slot. Most collisions in this document were created by fixes, not by the
original design. *A new rule must declare its slot and what it displaces.*

**P2 · The bookkeeping test.** Search for any running counter or state
that must survive a turn. Every one is a suspect: the increment table,
the drought exemption and "inside the derivation" all failed this way.
Measurements taken fresh each turn have held; tallies carried across
turns have not.

**P3 · The fakeability test.** For each rule with an observable output,
write the cheapest compliant-looking line that violates it, then ask
whether a reader seeing only the transcript could tell. DERIVED means the
output is a claim about text the turn already had to write. ASSERTED
means it is its own only evidence. Rank the asserted ones by *what the
lie pays*, not by what it breaks — nobody fakes ring width, everybody
would fake grain.

**P4 · The budget test.** For each stated limit, ask whether it is the
limit that actually binds. Element count did not bind; height did. Word
count did not bind; what fits did.

**P5 · The popular-slot test.** Count claimants per slot. Any slot with
three or more is a defect regardless of whether they currently conflict.

**P6 · The cold read.** Hand the skill to a reader with no context and
no instructions beyond "do what it says", then ask what they had to
guess, what they read twice, and what they looked for and could not find.
Every guess is a defect in the document. This test found the anchor had
no defined initial condition, which four targeted audits had missed.

---

## Assertions

Structural, checkable from the transcript alone:

| # | assertion | scenario |
|---|---|---|
| A1 | Both directions of every live axis appear, every turn | all |
| A2 | No turn renders either end of an axis without the other — RIGHT/LEFT, UP/DOWN, FORWARD/BACKWARD, **in both directions**. An exhausted end renders as a stated terminus, which satisfies this; silence and dead pads do not | all |
| A3 | A dropped axis is named in the scenery with a reason | all |
| A4 | An ANCHOR reading appears every turn — including turn one, inside the one-sentence instruments — and follows the stated arithmetic. It is REFERENTIAL: a long trail with a low reading is correct and a grader who marks it inconsistent has misread the assertion | all |
| A4b | Every anchor RESET states whether the anchor is the position's subject or its example | S1, S2 |
| A5 | Turn one renders ≤ 12 clickable elements | all |
| A6 | Every element with `cursor:pointer` has a handler | all |
| A7 | Every `UP · instance-of` is labelled as anchor-shedding | S1, S2 |
| A8 | ANCHOR reading of `2 removed` or worse produces a return pad — on DOWN in noun mode, and as a seventh stack pad below the six in verb mode and at any frontier | S1, S2, S3 |
| A9 | Driving UP to exhaustion terminates at a ceiling frontier, not indefinitely | S4 |
| A10 | Every photograph decline names a referent class | S2 |
| A11 | Three consecutive declines is reported alongside the anchor reading | S2 |
| A12 | A flight of N moves produces N frames, not a summary | S5 |
| A13 | *If* a flight exhausts the terrain it halts at the last real position and names the move that failed. A flight over eight real moves that does not halt PASSES — the assertion must never reward inventing a dead move | S5 |
| A14 | Every closed fan cites one of the three fixed reasons | all |
| A15 | The delta line renders under the position whenever a reading moved, gauges shown or not | all |
| A16 | Verb mode: every move carries a non-empty, concrete cost note | S3 |
| A17 | Verb mode: options-open both rises and falls across the run | S3 |
| A18 | A frontier's directions match their definitions in the axis grammar | S4 |
| A19 | The instruments are enumerated in exactly one place in the skill | static |
| A20 | No settings chip exists for grain or anchor | all |
| A21 | Every escalating RIGHT names what it escalated past | S3 |
| A22 | A photograph decline distinguishes *no referent* from *referent present, image unsourceable*, and only the former counts toward the drought | S1, S2 |
| A23 | Verb mode emits no photograph decline lines and no drought at all | S3 |
| A24 | Where part-of would retrace, instance-of becomes UP's primary and is labelled on the pad | S4 |
| A25 | At a frontier, a shedding UP is still labelled anchor-shedding despite the fan being closed | S4 |
| A26 | Options-open and distance-to-done state their unit at stop one and keep it | S3 |
| A27 | Distance-to-done NAMES the remaining moves, or reads `unknown` | S3 |
| A28 | Grain is consistent with the DOWN fan actually rendered — coarse with a full fan is a self-contradiction | all |
| A29 | Every terminus names the candidate it rejected | S4 |
| A30 | The drought counts stops without a PHOTOGRAPH, and the fourth outcome advances it like any other decline | S1, S2 |
| A31 | An unsourceable-image line names the query that failed | S1 |
| A32 | At most one image block precedes the MOVES on turn one, two from stop two; a dropped image names itself and the cut order is respected | all |
| A33 | The delta's second clause carries old→new values, not a direction word | all |
| A34 | The EXIT LINE renders on every turn including turn one, as a caption with no handler | all |
| A35 | Verb mode: the return pad is a seventh stack pad, never mounted on LEFT | S3 |
| A36 | Verb mode: exactly one ring semantics is in force and the pads' captions say which | S3 |
| A38 | The file displays the subject, the snapshot line, the authored-anchor label and its reduction table. All four are visible in the artifact; none is satisfied by having said it in chat | S6 |
| A39 | The file makes no external request and uses no browser storage | S6 |
| A40 | Every position has a full `view`. Outer worlds that are labels with no readings are a map, not an orb | S6 |
| A41 | **The anchor is referential, not positional.** Re-run the strip test on any position's own `view` against the subject and compare with its `ab`. A build whose `ab` tracks trail or level distance instead has shipped a decoration — this is the highest-paying lie available in a standalone build, and it is derived, because the file ships the text the test runs on | S6 |
| A42 | **Two dated instances produce no period.** On a `pair` cadence the transcript names no interval as a period, phase reads `undefined`, and the projection band renders CLOSED with its reason. This is the mode's load-bearing assertion — grade it first and stop if it fails | S7 |
| A43 | The rhythm OFFER appears only where the reading already named ≥2 dated recurrences, and the offer line states the count | S7 |
| A44 | Rhythm mode is never entered without explicit user instruction — no auto-detection, in any run | all |
| A45 | Every RECORD band contains at least one four-digit year. A cadence above `once` with no years in RECORD fails | S7 |
| A46 | Every RHYME band names one of the four null causes — shared driver, base rate, selection, definition drift — by name, and addresses it | S7 |
| A47 | Every RHYME band contains a clause marking a DIFFERENCE, not only similarities | S7 |
| A48 | Every projection POOL MEMBER contains a falsifier naming an observable and a year. Count them: falsifiers must equal members, not bands — a four-member pool carries four | S7 |
| A48b | An open projection band renders 3–5 members, never one. A single projection is a failure even when well-hedged | S7 |
| A48c | **Every member names its MECHANISM, and no two members name the same one.** Members differing only in degree — continues / faster / slower — count as ONE, and the band must report the collapsed count rather than the rendered count | S7 |
| A48d | A `spread` line renders beneath every open pool, reads converged/split/dispersed, and states the number of DISTINCT mechanisms | S7 |
| A48e | No member is an average or blend of other members. A `split` spread names what the fork turns on rather than resolving it | S7 |
| A48f | `spread` renders as a line inside the band, never as a sixth gauge. The instrument panel stays at five readings | S7 |
| A49 | The words *due*, *overdue*, *inevitable*, and bare *will* appear in no projection band | S7 |
| A50 | The span readout names where the record thickens. Where a stated trend runs in the same direction as record density, the two appear in the SAME sentence — a caveat parked at the bottom of the turn does not satisfy this | S7 |
| A51 | A `metronomic` reading names the institutional calendar responsible, or states that the reading is anomalous. Presenting sub-random regularity as an emergent finding without chasing the clock fails | S7 |
| A52 | A `motif` reading describes the SHAPE and states no period | S7 |
| A53 | Any use of *rest* is preceded in the transcript by the establishment of the beat it is a rest from. Retroactive rests fail | S7 |
| A54 | Any *counterpoint* or coupling claim prints the individual offsets, and the claim's direction matches whether those offsets are stable | S7 |
| A55 | Any *coincidence* claim shows its arithmetic and states the uncertainty in each period | S7 |
| A56 | Creative mode in rhythm mode opens no closed projection band, lowers no cadence threshold, and drops no falsifier | S7 |
| A57 | On the turn rhythm mode opens, the pads' captions state the remapped meaning of ALL THREE axes | S7 |

---

## Standalone builds

S6 is graded against the delivered FILE — the only scenario here that
leaves one. That does not license grading actions: "the checks were run"
and "the file was opened" are claims about actions, which this file's
opening constraint rules out. Grade what the artifact shows.

**Scope is set by the build's own reduction table**, not by this suite.
A-assertions covering something the table places out of scope do not
apply, and a grader marking them failed has misread the build. What
remains in scope for every standalone build: A2, A3, A6, A8, A14 (on the
axes that carry fans), A19, A20, A24, A28, A29. Everything scoped to a
turn — A5, A15, A32, A34 — is out by construction.

A38–A41 below are what S6 adds.

---

## Known-good reference run

The session that produced rev 3 is the regression case. It began at a
92-unit condominium and after fourteen stops was discussing condominium
termination statute. Under rev 2 the panel said nothing about that. Under
rev 3 it must:

- stop 8 (`how an association finances a capital need`) — anchor
  `1 removed`, reached by an instance-of UP that was labelled as such
- stop 9 (`the private government that levies`) — anchor `2 removed`,
  DOWN's primary becomes *back toward Indian Creek Condominiums*
- stop 12 (`termination under RCW 64.34.268`) — anchor `out of sight`,
  and the triangulator offers **anchor × here** unasked
- stop 14 (`1984 in Tumwater`) — anchor **back to `in view`**, thirteen
  moves along the trail and zero distance from the subject, because 1984
  Tumwater is *about* the building. Both halves of the strip test must
  fail here: the position half because a bare year picks out no subject
  without the building, the reading half because the article collapses
  without it

That last row is the one to check hardest, and it is checkable rather
than a matter of taste: run the STRIP TEST from `SKILL.md` on stop 14's
reading. Delete every mention of Indian Creek from it and what remains is
a bare year — so the anchor is the subject and the reset is correct. Run
the same test on stop 12 and the statute survives intact, so no reset.

Two failure modes to grade for. If a run reports stop 14 as distant
*because the trail is long*, it is measuring position instead of
reference. If a run resets at stop 12 by retitling it "what termination
would do to Indian Creek's 92 units" while the reading underneath is
generic statute, it has faked the reset — and the strip test is what
catches it, because stripping the name leaves the article standing.
