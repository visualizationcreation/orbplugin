---
name: orbengine
description: "Author an orb as a loadable .orb.txt file for Orb Studio, which renders it. Use whenever the user invokes /orbengine or /orbtxt, asks to build orb data, author an orb file or orb engine, or produce a .orb.txt they will upload. Also use to extend, retag, re-order or validate an existing orb file, to convert an orb session or printed orb into studio data, or to author a rhythm orb with a timeline, cadence, bands and a projection pool. This skill owns TERRAIN and PLACEMENT: finding the bands, writing positions, ordering the ring so relatedness falls off toward the antipode, keeping meridians coherent, scoring the anchor, marking honest edges, and tagging for facets. Placement is COMPUTED, never eyeballed — `references/placement.js` turns anchored weights into lon and level, and running it is a required build step. It owns no rendering — the studio does projection, rotation, pads, gauges, path and chrome. For a live clickable session use orb; for one self-contained HTML file use orbprint."
---

# orbengine

Author the terrain, place it deliberately, ship a file. The studio draws
it.

This is the orb with the rendering removed, and what remains is the part
that was always hard. Projection maths, drag inertia and label collision
were the visible work; none of them ever made an orb good. **An orb is
good when its positions are real, its ring is ordered, its readings say
something, and its edges are marked rather than furnished.**

Removing the rendering is not a simplification — it reallocates the whole
budget to that list.

**Read these before writing a file:**

- **`references/terrain.md`** — the axis tests, finding the bands,
  writing labels and views and angles, frontier honesty, scoring `ab`.
- **`references/geometry.md`** — what `lon` and `level` MEAN, the
  antipodal law, band capacity, ring seriation, meridian sectors.
- **`references/placement.md`** — the anchor scheme and the two
  constraints it exposes. Read it before scoring anything.
- **`references/placement.js`** — the calculator itself. **Run it. Do
  not reimplement it and do not place by hand.** It is a separate file
  precisely so that the arithmetic stays in one place and the prose
  never drifts from it.
- **`references/format.md`** — the wire format and every validator rule.
- **`references/orb-validate.js`** — the studio's validator. Every rule
  it enforces is listed in `format.md`; read it when you want to know
  what will actually be checked on upload.
- **`references/example.orb.txt`** — a small conforming file.

This document does not restate them. It is the process that puts them in
the right order.

---

## The one thing to understand first

Everything else follows from it: **`lon` is not a slot number.**

A position's longitude carries three meanings at once — how *unlike* it
is from its siblings, the order a rotating orb reveals it in, and which
vertical wedge of the subject it belongs to. Assigning longitudes by
counting off `0, 45, 90, 135…` throws away the entire ring axis and
produces an orb that is structurally correct and says nothing.

The property worth building for:

> **From any position, relatedness falls as you walk the ring, bottoms
> out at 180°, and rises as it comes back around.**

You do not author that per point. It **emerges from ordering each band
correctly, once**, and then holds from everywhere at the same time.

### Two constraints that are not negotiable

Both fall out of the arithmetic rather than from taste, and both were
latent in the old rules until placement became computable.

**The ring folds, and where it folds is found rather than chosen.** A
child must sit within 95° of its parent or the DOWN-then-UP return
breaks, so a far anchor at 180° is unreachable — a single parent's
children span at most 190° of arc. Rather than impose one fold at a fixed
span on every band, arc is allocated in proportion to `brk` and the
widest resulting gap **is** the fold. Empty ring is not waste; it is the
accurate statement that the band has ends, placed where the ends actually
are.

**It costs capacity**, which is real — see Size below.

**`d` is measured within the band, not from the subject.** `ab` is already
removals from the subject; if `lon` were driven by the same distance the
two would be one measurement rendered twice, and `ab` would carry nothing.
Measured from the band's own reference member, `d` is dissimilarity among
siblings and `ab` stays topical removal — which can be high for something
adjacent on the ring. The calculator reports the correlation and warns
past `0.9`, so this is checked per file rather than assumed.

**And there is no Z axis.** The third coordinate is `ab` — radial
distance from the subject. The studio renders it as concentric shells
with the subject at the core, so a position rated `ab: 3` is placed on
the outer shell and looks like it. Drift becomes visible before anyone
reads a word. `geometry.md` is how.

---

## What this skill owns, and what it must not

**OWNS:** positions and ids · labels as full predicates · band structure ·
ring ordering and gaps · meridian coherence · `level` and `lon` · the
the `view` field · `[ANGLE]` blocks · `ab` · `up_alt` · declared frontiers · threads ·
tags · the `reduction` declaration · every rhythm field and band

**DOES NOT OWN:** projection · rotation · drag · pads · gauges · path
geometry · label placement · chrome · reading time · adjacency · which
pads are live

**The test: if the studio can compute it, do not author it.** A file
carrying a derived value can disagree with the studio's own calculation,
and then two things claim to be the same reading. `ab` is the one
exception — it is a judgement about meaning, not geometry, and nothing
downstream can reconstruct it.

---

## Why the validator matters more than the website

The orb skill's recurring problem, stated in its own revision notes: a
rule is only as good as someone's willingness to check it. Every honesty
mechanism was graded by whoever read the transcript, which in practice
meant nobody.

**A parser is a second reader that never gets tired.** Conventions become
upload errors — `positions` can no longer lie about the file's size, a
pool member can no longer lose its falsifier, a period can no longer be
claimed from two occurrences.

**Design new rules so they land in that table.** A rule that cannot be
expressed as a check on the file will decay exactly the way the old ones
did.

But be clear about the ceiling, because it is easy to over-trust: **a
parser cannot detect boring.** It checks that a view is over sixty words;
it cannot check that the view says anything. The rules that most drive
quality — the predicate label, the substitution test, a real angle — are
partly checkable at best. The validator raises the floor. Only the
authoring raises the ceiling.

---

## Working method

Follow the order. Steps 1–3 are cheap to redo and expensive to fix later;
step 4 is most of the work.

**0 · Decide READING or WORKING.** Is the person opening this to **find
something out**, or to **make or do something**? Reading orbs
(`kind: knowledge`, `kind: rhythm`) carry declarative claims and offer
better questions. Working orbs (`kind: task`) carry imperative moves and
offer next actions.

This is the first decision because it governs every label, every angle
and the whole reduction, and it cannot be changed halfway without
rewriting all of them. **It is about the reader's posture, not the
subject's** — a reading orb's subject may be entirely dynamic, and
`kind: task` is for when someone performs each position, not when the
topic merely involves action. See the table at the top of
`references/terrain.md`. A working orb also declares in its `reduction`
that it offers moves and does not perform them: a file has no engine.

**1 · Fix the subject.** Write it as a full predicate — or, in a task
orb, name the `work`. Decide `subject-id`; it conventionally sits at
`lon: 0`, level mid-stack, and faces the reader when the file opens.

**2 · Find the bands.** Climb by instance-of until the answers stop being
about the subject; descend by "what are the ways this happens" until you
hit primitives. **Name the parent question for every band between** — if
you cannot name it, that band does not exist yet, and that is where the
gap usually is. Check the count against the capacity table in
`geometry.md`: top and bottom bands hold about six, middle bands about
twelve.

**3 · Fix the anchors, score the weights, run the calculator.** Placement
is computed. This step has a fixed order and skipping any part of it puts
you back to placing by feel.

**3a · Fix four anchors.** `A` the apex — the broadest position still
honestly about the subject; it sets `level 0`. `S` the subject at
`lon 0`. `F` the far anchor — the most distant idea the trail still
honestly reaches; it sets the unit of ring distance. `L` an off-axis
member, which fixes which way round the ring runs.

**Three anchors are needed for the ring, not two.** S and F alone are
symmetric about their own axis: a position scored `d = 0.4` is equally
consistent with `+38°` and `−38°`, and nothing in those two anchors
chooses. `L` breaks the reflection. In practice it is the band's axis of
variation used as a sign.

**Choosing `F` sets the scale for everything else.** Too close and the
whole ring saturates near 1.0; not actually relevant and every real
position compresses toward the origin.

**3b · Classify each band's topology** — cycle, line, clustered, star —
because it decides `span`. A **star** means you have mis-leveled; re-level
rather than laying it out.

**3c · Score three weights, in one pass, against the anchors.** `g`
generality, `1` = as broad as `A`. `d` ring distance, `0` = the band's
reference member, `1` = `F` — this **orders** the ring. `brk` the break to
the next member, `0` = nearly the same, `1` = a real discontinuity — this
**spaces** it. Score by comparison to the anchors — *"nearer to the
subject or to F, and roughly where between?"* — never on an abstract
scale. One pass, like `ab`, for the same reason: the scale drifts
otherwise.

**Do not derive `brk` from adjacent `d` differences.** It looks like free
information and it is a no-op: the arithmetic collapses back to linear
`d` scaling and reproduces the old placement exactly. Two scores that
collapse into one are one score.

**3d · Run `references/placement.js`.** It returns `level`, `lon`, a
`drift` figure per position, and the located `folds`, plus warnings.
**Read the warnings before the coordinates.** `band-overfull`,
`high-drift`, `meridian-break`, `no-breaks`, `no-fold`,
`parents-too-tight`, `break-belongs-above` and `ab-collinear` each name an
authoring decision to revisit, and none of them is fixed by editing a
number in the output.

**Pass `subjectId`** so the subject is re-pinned to `lon 0` and faces the
reader when the file opens; hierarchical allocation inherits its rotation
from the band above and nothing else restores that.

**The fold is found, not set.** Every wedge is guaranteed the arc it needs
to stay legible, and the surplus is spent in proportion to `brk`. The
widest gap that results is the fold. Allocation is hierarchical —
children sit inside their own parent's wedge, breaks space them within
it, and the boundaries between wedges are inherited from the band above.
So a large break at one level becomes the empty arc its children inherit
at the next.

**Which means meridian coherence is now a consequence, not an audit.** A
child cannot leave its parent's wedge. If you find yourself wanting a
wide gap between two positions under *different* parents, that break
belongs one level up — the calculator says so.

**`drift` is the reading that matters.** It reports how far a position was
pushed from the angle its weight asked for. Low everywhere means geometry
and meaning agree. One high figure is usually a mis-scored `d`. High
across a whole band means the band carries more members than that latitude
can hold — re-level or split a thread; do not shrink the gap.

**3e · Run the antipodal check on three samples per band.** The
calculator guarantees spacing, not sense. It will place a star topology
cleanly and be wrong.

**4 · Write the views, one meridian wedge at a time.** Top to bottom
through a single branch, then the next wedge. Band-by-band authoring
produces rings that are individually tidy and vertically incoherent, and
the incoherence is invisible until someone flies UP. This step is the
bulk of the build and where the intelligence goes.

**5 · Score `ab` in one pass.** All positions, against the subject,
together. Scoring as you go lets the scale drift.

**6 · Tag in one pass.** `namespace:value`, three to seven per position,
no singletons. Tagging as you go produces forty values used once each,
which look like metadata and filter to nothing.

**7 · Recount and self-check.** Set `positions` to the actual `[POINT]`
count — the first thing the parser checks and the most embarrassing thing
to get wrong.

**Deliver as a file**, named `<subject-slug>.orb.txt`. It is an upload
target; a chat code block is not one.

---

## Size

**A folded ring holds about 27 positions across five bands** — 4 / 6 / 7 /
6 / 4 — and that is a full orb at legible density; 20 is a solid one.
The old figure of 44 assumed a closed ring, which the meridian rule does
not permit for a single parent's children. Use it only for a declared
CYCLE at `span: 180`. Adjacent threads take about a third of the subject's
world.

Do not treat the loss as something to engineer around. A band that wanted
twelve members and can hold seven was usually two bands.

**Author fewer worlds rather than thinner ones**, and fewer positions
rather than emptier ones. The HTML file's size used to cap ambition;
nothing caps it now, and the live temptation is sixty thin positions
instead of thirty good ones. Every position costs a full view — that is
the real budget, and the capacity table is a ceiling, not a target.

Ship incomplete honestly: `state:stub` on unfinished positions and a
`reduction:` header naming what the file does not carry.

---

## Rhythm orbs

`kind: rhythm`. `../orb/references/rhythm.md` governs what may be *said*
— the cadence gates, the three bands, the null check, the pool and its
falsifiers, the forbidden words. `format.md` carries it.

Three things the data form changes, all improvements:

**The timeline becomes real.** `era:` on every point lets the studio build
an actual scrubber rather than the session's simulated one. Tag
consistently or the axis is inferred, and inferred wrong.

**The ring becomes the coupling axis.** `domain:` on every point, because
LEFT/RIGHT holds contemporaneous domains. Positions sharing an `era:` and
differing in `domain:` are exactly what the coupling reading compares —
and the antipodal law now means the far side of a rhythm band is the
*least* related domain at that moment, which is the right shape.

**The gates are enforced.** `cadence: pair` plus a `period` is an upload
error. Author against the validator: wanting to state a period the
cadence does not license is the rule working.

---

## Self-check

1. `positions` equals the actual `[POINT]` count.
2. `subject-id`, every `upalt`, `entry` and `frontier` target resolves.
3. Every point: `view` over 60 words, two or more `[ANGLE]` blocks.
4. No angle could be attached unchanged to another position.
4a. **Angles match the mode.** Reading orbs: a tension, a boundary, a
    reader it fails. Working orbs: a move they could make today without
    asking a follow-up question. Neither degenerate set appears.
4b. **Mode is consistent file-wide.** Read every label as a flat list: in
    a working orb all accept "you could…" in front; in a reading orb none
    do. No file mixes the two.
4c. Working orbs only — every point has `does`, `~when` and `reversible`;
    every `reversible: no` has a `forecloses`; the header `reduction`
    states that moves are offered, not performed.
5. Read each band's labels as a flat list — none reads as a filing
   category.
6. Substitution test on three views: none could be pasted under a
   neighbouring label.
7. Antipodal check on three positions per band.
8. Every parent within 95° of its child in `lon`.
8a. **Placement was computed, not eyeballed.** `placement.js` was run,
    its warnings were read, and every one was resolved or consciously
    accepted. Longitudes that count off `0, 45, 90, 135…` are the
    signature of a skipped step.
8a-i. **Every band has `brk` scores** and they are not flat. A `no-breaks`
    or `no-fold` warning means the ring was spaced, not placed.
8a-ii. **The fold landed somewhere meaningful.** Read `folds` and say what
    the empty arc separates. If it separates nothing, the breaks were
    scored by reflex.
8a-iii. **No `break-belongs-above` warnings survive.** A discontinuity
    scored across a wedge boundary belongs to the band that placed the
    parents.
8b. **Four anchors are named** — `A`, `S`, `F`, `L` — and `F` is a
    position in the file, not a hypothetical.
8c. **No position sits past 95° from its parent.** Under hierarchical
    allocation this should hold by construction; a violation means a
    wedge was overfilled.
8c-i. **No `parents-too-tight` warnings survive.** A wedge that cannot fit
    under its parent means the band above is packed tighter than its
    children can sit — repair it one level up, not here.
8c-ii. **The subject sits at `lon 0`.**
8d. **`ab` and ring distance correlate below 0.9.** Above it, `ab` was
    scored from the subject instead of `d` from the band reference.
9. No band exceeds its latitude's slot count — 4 / 6 / 7 / 6 / 4 folded.
10. DOWN then UP returns you, from three samples. RIGHT around a band
    returns in exactly its length.
11. `ab` varies and was scored in one pass against the subject.
12. Tags: no singletons, no synonyms, three to seven per point.
13. Rhythm only — no `period` under `once`/`pair`; every pool member has
    a mechanism and a falsifier; no two mechanisms identical; no *due*,
    *overdue*, *inevitable*.
14. Opens with `ORB 1`; delivered as a file.

---

## Where the rest lives

`../orb/SKILL.md` is the grammar and the reasoning behind every rule
above. `../orb/references/physics.md` has fans, closure vocabulary and
creative mode. `../orb/references/standalone.md` has the absolute anchor
scale and the reduction table. `../orb/references/rhythm.md` is rhythm
mode in full.

Nothing here redefines those. Where this file and `orb` disagree on
terrain, `orb` wins; where they disagree on what belongs in a data file,
this file wins.
