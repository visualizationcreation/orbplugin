# The `.orb.txt` format — v2

**The contract between an authoring model and Orb Studio.** v2 keeps the
studio's existing tag-block syntax unchanged and adds what the format was
missing: a declared mode, honesty gates that a parser can enforce, and
facet tags.

**Every v1 file still parses.** All new fields are optional at the syntax
level; the gates only bind once `kind:` is declared.

---

## Syntax — unchanged from v1

```
[TAG]
key: value
long_key: |
  Indented by two spaces. Blank lines inside are preserved
  as paragraph breaks.

  No escaping. Quotes, dashes and code go in verbatim.
[/TAG]
```

- `# ` at column 0 outside a block is a comment.
- Tags are `[A-Z][A-Z0-9_]*`. Blocks must close before another opens.
- Repeated keys: **the last one wins.**
- Comma-list fields split on `,` and trim.
- A file beginning with `{` is parsed as JSON instead.

Three design choices here are better than the alternatives and should not
be revisited: explicit `[/TAG]` closers make a malformed block
*localizable* rather than swallowing the rest of the file; `key: |`
carries long prose with no escaping, which is the failure mode that kills
JSON authoring; and `[ANGLE]` as a separate block with **both** a `label`
and a `claim` gives the reader a hook and a prompt rather than a bare
question.

---

## `[ORB]` — one per file

| key | req | meaning |
| --- | --- | --- |
| `subject_id` | yes | id of the position that IS the subject. Must resolve. |
| `subject_label` | yes | the subject as a full predicate |
| `kind` | **v2** | `reading` · `working` · `rhythm`. Defaults to `reading`. **Sets the grammar of every label and the gates that apply.** |
| `density` | no | `sparse` · `normal` · `dense` |
| `positions` | no | defaults to the actual count |
| `subject_positions` | no | count in the subject's own world |
| `authored` | no | ISO date |
| `note` | no | one line shown on the face |
| `reduction` | **v2** | semicolon list of declared out-of-scope features. **Required for `kind: working`.** |

## `[THREAD]` — one per world

`id` · `label` · `entry` (must resolve) · `gloss` · `cap` (`origin` / `terminus`, v2)

## `[POINT]`

| key | req | meaning |
| --- | --- | --- |
| `world` | yes | thread id |
| `id` | yes | slug, unique |
| `label` | yes | **reading/rhythm: a declarative predicate. working: an imperative.** |
| `level` | yes | integer; higher is more abstract |
| `lon` | yes | 0–359 |
| `view` | yes | the reading |
| `parent` | yes | id or `null` |
| `tier` | no | numeric draw weight |
| `ab` | no | anchor removals 0–3 — **the R coordinate**, not a readout |
| `up_alt` | no | comma list: instance-of parents |
| `forward` | **v2** | id of the position this one leads to — a consequence **link**, not a coordinate. `back` derives as its inverse. |
| `back` | **v2** | id; only author it where the inverse is genuinely not symmetric |
| `refs`, `edge`, `seed`, `period` | no | as v1 |
| `tags` | **v2** | comma list, `namespace:value`. 3–7. |
| `frontier` | **v2** | comma list of directions that genuinely terminate: `up down left right forward back` |

**Working orbs add:** `does` (what the move changes) · `when` (the trigger)
· `reversible` (`yes`/`partial`/`no`) · `forecloses` (required when
`reversible: no`)

**Rhythm orbs add:** `cadence` (`once`/`pair`/`motif`/`periodic`/`metronomic`)
· `phase` · `phase_zero` · `clock` · `spread`
(`converged`/`split`/`dispersed`) · `record_density`

### The coordinate system — three ratings, three coordinates

**The orb has no Z axis.** A sphere surface carries exactly two degrees of
freedom, and X and Y consume both. The third coordinate is **radial**: how
far out from the subject a position sits. Closeness to the topic is depth
toward the middle, not a direction you travel in.

| coord | rating | range | meaning |
| --- | --- | --- | --- |
| **X** longitude | `lon` | 0–359 | ring position — semantic distance from siblings |
| **Y** latitude | `level` | integer | level of detail — how finely the subject is cut |
| **R** radius | `ab` | 0–3 | removals from the subject |

**Every position is rated on all three, and the ratings *are* the
coordinates.** There is no separate placement step: the studio derives
latitude from `level`, angle from `lon`, and shell radius from `ab`. This
is why `ab` is the one judgement the studio cannot compute for you — it is
a position, not a readout.

The centre of the orb is the subject itself at average detail. Author with
that in mind: a position rated `ab: 3` is being placed on the outer shell
and will look like it. If most of an orb sits on the outside, the orb is
about something other than its stated subject, and the geometry says so
before any reader has to.

**Anchor is carried three ways in the render** — shell radius, mark size,
and brightness — because a point facing the viewer sits near the centre of
the disc whatever shell it is on. Radius alone is ambiguous head-on.

### Consequence is a link, not an axis

`forward` threads a consequence chain through the terrain and draws as an
arc. It is **not** a coordinate and does not move a position. Only author
it where the sentence *"X is what follows from Y"* holds without needing
"and also" or "meanwhile" — a chain laid down in authoring order looks
navigable and means nothing. `back` derives as the inverse.

## `[ANGLE]`

`point` · `label` · `claim`. Two or more per position.

## `[RECORD]` — v2, rhythm

`point` · `year` · `event`. The dated evidence cadence is computed against.

## `[RHYME]` — v2, rhythm

`point` · `text` · `null_cause` (must name **shared driver**, **base rate**,
**selection**, or **definition drift**) · `disanalogy` (required)

## `[POOL]` — v2, rhythm

`point` · `member` · `mechanism` · `falsifier` (must contain a year) · `text`

Three to five per position, **each naming a distinct mechanism.**

## Unchanged v1 blocks

`[IMAGE]` (`point`, `src`, `alt`, `caption`, `credit`, `href`) ·
`[MATERIAL]` (`point`, `title`, `kind`, `source`, `minutes`, `url`,
`summary`, `text`) · `[NUMBER]` · `[SOURCE]` (`title` and **`url` are both
required** — this is easy to miss) · `[APEX]` (`a`, `b`, `apex`, `note`,
`degenerate`) · `[PORTAL_AXIS]`

---

## Validation

`orb-validate.js` implements this. **Errors refuse the file; warnings load
it and flag.** The split matters: an author fixing warnings is the loop
this format exists to create, and an author fighting a rejection over a
one-member ring stops using the tool.

**ERRORS** — structural: unresolved `subject_id`, `parent`, `up_alt`,
`entry`; duplicate ids; `lon` out of range; non-integer `level`; bad
`kind` or `frontier`; missing `id`/`label`/`view`; `[SOURCE]` without
title or safe URL.

**ERRORS** — working: missing `does`/`when`/`reversible`; `reversible: no`
without `forecloses`; no `reduction` declaring that moves are offered,
not performed.

**ERRORS** — rhythm: a `period` under cadence `once`/`pair` (*two
occurrences define an interval, not a rhythm*); a pool under `once`/`pair`;
a pool with fewer than 3 members; two members sharing a mechanism; a
member missing mechanism or falsifier; a falsifier without a year;
`due`/`overdue`/`inevitable` anywhere in a projection; `phase` without
`phase_zero`; a rhyme without a named null cause or without a disanalogy.

**WARNINGS** — quality: view under 60 words; fewer than two angles;
degenerate angles (mode-aware — the working list differs from the reading
list); a noun-phrase label in a reading orb or a descriptive label in a
working orb; a child more than 95° from its parent; a band over its
latitude's legible capacity; a ring of one; a view overlapping >35% with
a ring neighbour; every `ab` reading 0 across a multi-band orb; more than
seven tags; more than three singleton tags.

Band capacity comes from the projection: bands spread across ±58°, ring
circumference scales with `cos(latitude)`, so the top and bottom bands
hold about **six** where the equatorial band holds **twelve**. A subject
has a handful of framings, a handful of primitives, and the bulk in the
middle — the geometry encodes an editorial truth.
