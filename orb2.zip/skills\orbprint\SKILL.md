---
name: orbprint
description: "Print an orb as one self-contained HTML file — a slowly rotating globe of a subject that you browse inside the page by clicking points, with a path line drawn between everywhere you have been. Use whenever the user invokes /orbprint, or asks to print, build, generate or emit an orb as a file, page, artifact, HTML or JavaScript build they can keep, reopen or share; or asks for a rotating, spinning or 3D orb; or asks for an orb with a point density, a point count, a sparse or dense orb. Also use when the user wants each point of an orb to hand back a copy-out prompt that seeds the next orb, or wants clickable options, angles or creative suggestions for composing that prompt, or wants the orb fully filled out in advance so no further conversation is needed to browse it. `/orb` opens a live session and stays in the chat; `/orbprint` produces the file. If the user asks for a live session, use `orb` instead."
---

# orbprint — the orb as a printed, rotating, browsable file

**Build: orbprint v0.2.0 — a correctness release.** No new output, no new
axes. Everything here came out of building one real file and then testing it
in a browser rather than reading it back.

Four things were wrong and one was missing. **The markers could not be
clicked**: the spec asked for `tabindex` and a `click` handler, and the
renderer replaces the SVG every frame, so a pixel of drift between press and
release swallowed the event — the orb looked finished and only the side panel
worked. **The nine-item self-check never pressed a marker**, which is how
that shipped. **The 95° adjacency window** hands out cousins wherever a
position has no authored child, breaking the inverse guarantee the same file
promises. **UP's fan was mandatory** in a build that cannot honestly author
an instance-of parent everywhere. And **the seed was one fixed string per
position**, deciding the next orb in advance for a user who has just learned
something the build did not know.

So: a pointer contract that resolves a tap before any redraw, three more
self-checks, the child rule stated where it is cheap to satisfy, a
stated-absence path for UP's fan, a **seed workshop** in place of the seed
block, an `angles` field to feed it, `BUILD.note` for declaring a deviation
from a preset out loud, and reading time — counted from words already
written, and explicitly not a sixth instrument.

**The one-line version, unchanged: the file must be complete enough to browse
with no further conversation, and honest about the exact point where it stops
being complete. v0.2.0 adds that it must also be clickable, and that the user
chooses what comes next.**

The companion to `orb`. Same physics, same
six directions, same five instruments, different output: `orb` renders a
cockpit inside a turn and re-measures every move; `orbprint` authors the
whole terrain up front and ships it as **one HTML file** that spins on
its own and is browsed by clicking.

This skill supersedes `../orb/references/standalone.md`, which described
a static build. It keeps that file's data model, adjacency function and
absolute anchor scale — and adds the three things it did not have:
**rotation**, **the path**, and **density as a stated build parameter**.

**The one-line version: the file must be complete enough to browse with
no further conversation, and honest about the exact point where it stops
being complete.**

---

## Read this first: the law this skill inherits

`orb`'s law binds here unchanged: **never let a reading be its own only
evidence — the output must be a count of, or a claim about, something the
build was already obliged to write.**

A file makes this harder, not easier, because there is no turn to check
against. So every instrument in a printed orb computes in JavaScript over
authored data the reader can open and inspect, and any number that cannot
be recomputed from the data in the file is either authored-and-labelled
or absent. There is no third option. A gauge that displays a constant
somebody typed is the failure this skill exists to avoid.

**Two consequences, stated once:**

1. **The instruments read the terrain you actually authored.** A thin
   build reads coarse grain and shallow depth. That is correct, and it
   must not be compensated for. Inflating a reading to make a sparse orb
   feel rich is the single worst thing a build can do, because the
   reading is the only thing distinguishing this from a decorated list.
2. **Everything out of scope is absent and named, never faked.** The
   reduction table below is the file's own statement of what it is not,
   and it renders in the file.

---

## The build interview — ask, then author

Never author before asking. A printed orb is expensive to produce and
impossible to adjust cheaply, so the questions are worth the round trip.
Where the client renders a question tool, use it; otherwise ask in one
message with the options laid out.

**Ask two things, always:**

1. **The subject**, if the invocation did not carry one. Take it as a
   position, not a word — see `orb`'s Grammar section. "Coffee" becomes
   *Coffee as an agricultural commodity and a social ritual*, and the
   file's `SUBJECT.label` is the predicate, not the noun.
2. **The density.** This is the parameter the whole build scales on, and
   the user is entitled to know what each setting costs them.

**Offer these four, with the counts and the costs stated:**

| preset | positions in the subject's world | bands | adjacent worlds | what you get, and what it costs |
|---|---|---|---|---|
| **sparse** | 18–22 | 3 | 2 × ~6 | Fast to build, quick to read. DOWN fans are 1–2 wide, so grain reads **coarse** at most altitudes and says so. Good for a subject you want the shape of, not the substance. |
| **standard** | 36–44 | 5 | 4 × ~10 | The default. DOWN has a real fan at most altitudes, the ring is walkable without wrapping in three steps, and the triangulator has enough pairs to be worth consulting. |
| **dense** | 70–85 | 5–6 | 4–6 × ~15 | A long build. Labels begin to collide, so tier thinning does real work and the draw-density control stops being decorative. Grain reads **fine** in the subject's neighbourhood. |
| **exhaustive** | 140–160 | 6–7 | 6 × ~20 | A very long build, authored in passes. Expect to write the subject's world, deliver, then extend. Only worth it when the user intends to live in the file. |

A user who names a number gets that number. Honour it, and if it lands
outside 12–200, say what it will do to the build before agreeing —
under 12 the adjacency function starts returning empty fans and the orb
becomes a list with a sphere drawn behind it; over 200 the authoring
cost stops being deliverable in one pass and should be planned as
several.

**Optional, only if the user raises them:** creative mode on the
triangulator, the number of worlds along the thread, and whether to
include the seed panel (it ships by default).

**Then say what you chose, before you build.** One short line naming the
subject as a position, the density, the position count you are aiming
at, and the thread you intend to string. The user can correct the terrain
before you spend the effort authoring readings for it, which is the only
moment correcting it is cheap.

---

## Two densities, and they are different things

The single most common way to get this wrong is to conflate them, so:

**BUILD density** is what the interview asks. It sets how many positions
**exist**. It changes instrument readings, because there is genuinely
more or less terrain. It is fixed at build time and the file cannot
change it.

**DRAW density** is a control **in** the page — sparse / normal / dense.
It thins what the sphere **draws**, using `tier`. It must never remove a
position from a fan, never change a reading, and never make a destination
unreachable. It is a rendering preference, and the file labels it as one.

`orb`'s rule — *the interface must not offer a handle on a fact* — is
what forces the split. Draw density is a preference and gets a control.
Grain and depth are facts and get readings. If moving the draw-density
control changes a number in the instrument panel, the build is broken.

**The evidence this leaves:** the file states its build density and
position count on its face, and a reader can count the entries in
`WORLDS` and check. That is the count-of-something-already-written the
law requires.

---

## What a printed orb is: the rotation

A printed orb **spins on its own**, slowly, about the vertical axis. This
is not decoration and it is not a loading state — it is the mechanism by
which the ring becomes browsable without dragging. The ring is a full
360° of directions around the anchor; a static render shows a little
under half of it, and every position on the back is one the user has to
know to go looking for. Rotation makes the whole ring arrive on its own.

**The spin covers the ring; it does not cover the altitude axis.** Only
the ring is circular. Up and down are climbed by clicking, and no amount
of rotation substitutes for that. Say this plainly in the file's help
text rather than letting a spinning graphic imply that watching it long
enough shows everything.

The full rotation spec — rate, tilt, the pause and resume rules, drag,
inertia, and the reduced-motion path — is in `references/shell.md` and is
binding. The three things worth stating here, because they are design
decisions rather than numbers:

- **The spin pauses whenever the user is doing something** — hovering a
  point, dragging, reading an open panel, or holding keyboard focus — and
  resumes after a short idle. An orb that rotates a label out from under
  a cursor is hostile.
- **A click eases the target to the front, then resumes.** Travel is
  never a jump cut on the ring axis; the user must see which way they
  went, because which way they went is the information.
- **`prefers-reduced-motion` disables the auto-spin entirely** and leaves
  drag and the direction pads. The orb is still fully navigable with no
  motion at all, and a build that becomes unusable when motion is off has
  failed.

---

## The path — the trail, drawn

Every position the user visits joins a **path drawn on the sphere**: a
line following the surface from each stop to the next, curving with the
globe, dimmed and drawn first where it passes around the back.

This is the feature that makes a printed orb worth keeping. A session's
trail is a list you can print; a file's trail is a **shape**, and the
shape is legible in a way the list is not — a tight cluster near the
anchor and a long limb running off to one side are two different
sessions, and you can see which one you had.

**Four rules, each of which leaves evidence on screen:**

1. **A ring or altitude move draws a surface segment.** Interpolate along
   the great circle between the two positions so the line lies on the
   sphere rather than cutting through it, and split it at the limb so the
   back half draws at low opacity behind the globe.
2. **A THREAD move does not draw a segment. It draws a break.** Forward
   and backward relocate the whole neighbourhood — the sphere you are
   looking at is a different sphere — so the path shows a labelled gap
   with a chevron naming the world it crossed into. Drawing a smooth line
   across a thread move would assert a surface adjacency that does not
   exist, and `orb` keeps the two kinds of motion visually separate for
   exactly this reason. Keep them separate here.
3. **The newest segment is accented; older segments fade back.** Opacity
   ramps oldest to newest so the direction of travel is readable without
   arrowheads, which do not survive at these line widths.
4. **The path is also text.** Under the orb, the same route renders
   arrow-separated, and it is what the copy-address control copies. The
   drawn path and the text route are the same data, and if they can
   disagree, the build is broken.

**Retracing.** Stepping back onto a visited position does not duplicate
the segment; it thickens it, and the position's marker carries a small
visit count. A path that loops should look looped.

---

## The two outputs at every point

A printed orb is **fully authored by default**: every position carries
its reading, the fans resolve locally, and browsing the file requires no
further conversation. That is the primary output, and it is what makes
the file a file.

But the file's terrain ends somewhere, and the join at that edge is where
printed orbs usually start lying. So every position also carries a
**seed** — a copy-out that opens the *next* orb from here.

**The point panel shows, in this order:**

1. **The reading.** The position's `view`, at the length `orb` specifies.
2. **The instruments**, computed for this position, plus the reading-time
   strip — which is arithmetic over the words already written and is
   explicitly **not** a sixth instrument. See `references/shell.md` §9b.
3. **The six pads**, resolving locally into the authored terrain, each
   naming what its destination costs to read.
4. **The seed workshop**, which composes the next orb's prompt from
   clickable options rather than handing back one fixed string.

**Why a workshop rather than a seed.** A single generated prompt decides in
advance what the next orb is about. The user has just spent time browsing;
they know something the build does not, and the interface should let them
spend it. So the anchor is *chosen* — this position, an authored **angle**,
an apex, a rejected pair offered for re-test, the whole ring, or a set of
points **pinned while browsing** — with mode, density, creative mode and
what to carry as live controls. The option list and the composer are
specified once, in `references/shell.md` §9.

**Angles are the eccentric doors, and they are authored, not generated** —
two or more per position, each a label plus **the flat claim it has to
survive**. `../orb/references/physics.md` already requires that an eccentric
destination be writable as an ordinary sentence with no wonder in it, and
that the flat sentence reach the card. Here it also travels into the prompt,
so the next orb is asked to check the claim rather than inherit it. A claim
that stays true when either term is swapped for a random third topic is
degenerate, and the angle does not ship.

**At an edge position the workshop stops being an extra and becomes the
answer.** Where a direction has no authored destination, the pad renders as
a **stated terminus naming what would have been there**, and the workshop
promotes itself: *this file ends here; this prompt continues it.* The file
never invents a fan to hide its own edge, and never renders a dead pad
without saying why it is dead.

**The seed is a real prompt, not a label.** It must run. If pasting it
does not open a working orb on that position, it is decoration, and
decoration that claims to be a control is the thing rule 1 of the wiring
contract exists to forbid. The same test applies to every control in the
workshop: if a toggle does not change the text in the box, it is a picture
of a toggle.

---

## The reduction — what a printed orb is not

Inherited from `orb`'s standalone rules and widened, because this build
carries more than that one did. **This table renders in the file.**

| in scope | out of scope, and declared |
|---|---|
| noun mode | verb mode — no artifact, no cost notes, no reversibility |
| all six directions, with fans on every axis | images — no illustration, no photograph, no drought |
| UP's part-of / instance-of split, with `upAlt` fans | the delta line, parking, converse mode |
| all five instruments, computed over the authored terrain | live re-measurement — the terrain is frozen at build time |
| the trail, as a drawn path and as an address | frontier **rooms** — the file names and seeds an edge, it does not furnish one |
| the triangulator, over an authored apex table | shape detection — a printed orb is a sphere and says so |
| continuous rotation, drag, keyboard navigation, and **markers that travel on a tap** | |
| build density stated; draw density as a page control | |
| a **seed workshop** at every position: authored angles, apex and rejected-pair bases, the ring, and a pinned set, composed live into a runnable prompt | a live model — the workshop composes text, it does not answer |
| **reading time**, counted from the words the file already wrote | any claim about how fast this reader reads — the rate is one stated assumption |

Because there is no turn, every rule in `orb`'s SKILL.md scoped to
"every turn" is out of scope by construction — the output format, the
exit line, the image budget, the turn-one element count. Same suspension
`orb` already grants parking and text mode.

A build that wants a row back may take it, **provided it moves the row
and can deliver it.** A build that silently drops an in-scope row has
failed.

---

## The data model

Inherited from `orb`'s standalone reference, with three additions. The
full field table, the adjacency function and the absolute anchor scale
live in `references/shell.md`; this is the shape:

```js
SUBJECT = { id, label }                       // the anchor: a real position in WORLDS
THREAD  = [ { id, label, gloss, entry, cap? }, … ]
WORLDS  = { <threadId>: [ …positions… ] }
BUILD   = { density, positions, bands, worlds, authored, note? }  // NEW — stated on the face
APEX    = [ { a, b, apex, note, degenerate? }, … ]
```

```js
{ id, label, level, lon, tier, ab, upAlt?, view, angles, edge?, seed? }
```

`edge`, `seed` and `angles` are the additions. `edge` lists the directions that
have no authored destination, so the terminus pads render from data
rather than from a failed lookup — an absence you declared is checkable,
an absence you discovered at runtime is a bug wearing a feature's
clothes. `seed` is an optional override for the generated prompt, used
where the generic form would produce a bad opening.

`angles` is an array of `{l, f}` — the next-orb options and the flat claim
each has to survive. Two minimum, everywhere; a position with none has a
workshop that can only offer what the geometry already offers.

`BUILD` exists so the file's claims about itself are data. The face
renders `BUILD.positions`; a reader counts `WORLDS`; the two agree or the
build is wrong. `BUILD.note` is where a build declares a deviation from its
own preset — a count outside the density band, a world dropped, a reduction
row taken back — and it renders on the face too.

---

## The authoring order — readings are the cost, so front-load the shape

A printed orb fails in one predictable way: the terrain gets authored,
the readings get rushed, and what ships is a well-drawn sphere of
one-line stubs. Every position needs a **full** `view` at the length
`orb` specifies. That is the build's real cost, and it should shape the
order of work.

1. **The thread first.** Name the worlds and the gloss for each. This is
   the spine and it is cheap to change now and expensive later.
2. **The subject's world, as a skeleton.** Ids, labels as predicates,
   `level`, `lon`, `tier`. Then check the adjacency function against it
   **before writing a single reading**, because a skeleton that fails
   adjacency will fail it just as hard with 40 readings attached. Three
   things, all cheap now:
   - **DOWN-then-UP returns you, from every position** — not from a few.
     Script it; it is six lines.
   - **The child rule** in `references/shell.md` §6: every position either
     has its own nearest position on the band below, or has nothing at all
     within 95° of it there. Anything in between hands out a cousin.
   - **Longitudes are spread**, so no band spends most of a rotation showing
     empty sphere.

   Repairing the child rule costs positions and can push a world past its
   density preset. Take the positions and declare the overshoot in
   `BUILD.note` — a stated deviation is honest; a silent one is the failure
   this skill's law exists to prevent.
3. **The anchor scale.** Set `ab` on every position using the absolute
   scale in `references/shell.md`. Do it while the labels are fresh.
4. **Then the readings**, subject's world first, in altitude order.
5. **Adjacent worlds**, at about a third the density.
6. **The apex table**, weighted toward pairs a user is likely to have
   visited both of, and including `SUBJECT` against several distant
   positions so the unasked `anchor × here` offer lands somewhere.
   Author some **degenerate** verdicts at wide bases — pairs you
   considered and rejected, with the trivial link named. A triangulator
   that always succeeds is one that lies.
7. **The angles**, two or more per position, each with its flat claim.
   Author these last among the content, because by then you know the whole
   terrain and can see which doors genuinely lead out of it. Write the flat
   claim first and the label second: if the claim is boilerplate, no label
   will rescue it.
8. **The shell**, from `references/shell.md`.
9. **The self-check**, from the end of that file. Run all twelve. Checks 10
   to 12 exist because the first nine passed on a build whose orb could not
   be clicked, whose seed offered nothing to choose, and which nobody had
   timed.

**Where an instance-of parent does not exist, say so rather than dropping
the fan.** `../orb/references/physics.md` makes UP's fan non-optional because
it is the only
place anchor-shedding can be chosen. A printed build often cannot honestly
author an instance-of parent for a fine-grained position, and inventing one
is worse than lacking one. So the fan still renders, carrying a stated
absence: *no instance-of parent was authored here; the wholes above this
position are containment parents only — a fact about the build, not about
the terrain.* Absence declared is checkable. Absence by omission is silence,
and silence is what the rule forbids.

**Author fewer worlds rather than thinner ones.** Two worlds with real
readings beat six with stubs, every time.

---

## Delivering

Write the complete self-contained HTML — inline all CSS and JS, system
faces or inlined fonts, no external request of any kind — then deliver it
as a file, and **persist it as an artifact**: a printed orb is by
definition something the user intends to reopen.

Then say, briefly:

- what terrain you chose, and what you left out of it;
- the build density and the actual position count;
- **what the reduction costs for this subject specifically** — not the
  generic table, but the one thing this subject most wants that a file
  cannot carry;
- that `/orb` is the complement: it goes anywhere and re-measures every
  move, and it does not persist.

Do not narrate the reading of every position. The file is the output.

---

## The reference files

- **`references/shell.md`** — the implementation contract: the rotation
  loop, the projection, the path renderer, the density constants, the
  travel state machine, the seed panel, the wiring contract,
  accessibility, and the self-check. Liftable code for the four functions
  that are easy to get subtly wrong. **Read it before building.**
- **`../orb/SKILL.md`** — the engine: grammar, the instruments, the
  frontier rules, the trail, the return pad.
- **`../orb/references/physics.md`** — fans, the triangulator, creative
  mode.
- **`../orb/references/cockpit.md`** — the wiring contract, and the
  visual vocabulary a printed orb should stay recognisably inside.
- **`../orb/references/rhythm.md`** — read it only when printing a
  RHYTHM orb. A printed rhythm orb is the one build where the file
  outlives the conversation that made it, which makes the honesty gates
  matter MORE rather than less: a projection pool whose members lost
  their falsifiers on the way into HTML is a prophecy someone will find
  in six months with no way to check it. Author every band, every
  falsifier and the spread line into the file itself, and let the
  timeline be the axis the points are laid along.

Nothing in this skill redefines those. Where this file and `orb`
disagree on physics, `orb` wins; where they disagree on what a file may
claim about itself, this file wins.
