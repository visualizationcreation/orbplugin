# Geometry — placement as meaning

The studio renders. It does not decide **where a position goes**, and
where a position goes is most of what an orb communicates.

This file is the part of the projection maths an author actually needs.
Not to draw the sphere — to understand what the sphere will say about
the terrain once it draws it.

---

## The projection, in the two facts that matter

```js
latFor(level) = 58 − 116·i/(n−1)      // bands spread across ±58°
vec(lon,lat)  = [cos λ·sin φ, sin λ, cos λ·cos φ]
```

Two consequences fall out, and both constrain authoring:

**1. Circumference shrinks with latitude.** A band at ±58° has
`cos 58° = 0.53` — barely half the ring length of the equatorial band.
Positions there need twice the angular gap to stay legible.

**2. The front hemisphere is the reading surface.** Roughly half the
positions in a band are visible at any moment, and the ones near the limb
are foreshortened into a crowd. The centre is prominent; the edges are
not.

### Band capacity — read this before deciding how many positions

Twelve legible slots at the equator, scaled by `cos λ`:

| bands | level idx | latitude | slots | min gap |
| --- | --- | --- | --- | --- |
| **5** | 0 (most abstract) | +58° | **~6** | 60° |
| | 1 | +29° | ~10 | 36° |
| | 2 | 0° | **~12** | 30° |
| | 3 | −29° | ~10 | 36° |
| | 4 (most concrete) | −58° | **~6** | 60° |

Those are **closed-ring** figures. A ring that folds to ±95° — which is
the default, for the reason in `placement.md` — holds roughly half:
**4 / 6 / 7 / 6 / 4**, about **27 positions** across five bands. The
closed figures apply only to a declared CYCLE.

**Do not lay these out by hand.** `placement.js` computes `lon` and
`level` from anchored weights and enforces every constraint on this page.
The seriation procedure below is what you reason through *before* scoring;
it is not a placement method.

**The geometry encodes an editorial claim, and it happens to be true:**
the top and bottom bands are the *narrowest*. A subject has a handful of
framings, a handful of irreducible primitives, and the bulk in the
middle. An orb with eleven positions in its most abstract band is not
just illegible — it has almost certainly mistaken eleven mid-level ideas
for eleven framings.

---

## The coordinate system

Three ratings, three coordinates, and **none of them is Z**. A sphere
surface carries exactly two degrees of freedom; X and Y consume both.

| coord | rating | range | meaning |
| --- | --- | --- | --- |
| **X** longitude | `lon` | 0–359 | ring position |
| **Y** latitude | `level` | integer | level of detail |
| **R** radius | `ab` | 0–3 | removals from the subject |

**The ratings ARE the coordinates.** There is no separate placement step:
the studio derives latitude from `level`, angle from `lon`, and shell
radius from `ab`. This is why `ab` is the one judgement nothing
downstream can reconstruct — it is a position, not a readout.

The centre of the orb is the subject at average detail. Author with that
in mind: a position rated `ab: 3` sits on the outer shell and looks like
it. **If most of an orb sits on the outside, the orb is about something
other than its stated subject, and the geometry says so before any reader
has to.**

Consequence (`forward`) is a **link**, not a coordinate. It threads
through the terrain and draws as an arc; it does not move a position.

---

## Longitude is three things at once

This is the heart of the file. `lon` is not a slot number. It carries
three meanings simultaneously, and a good ring satisfies all three.

## Ordering a band — the seriation procedure

Arranging n siblings around a circle so that angular distance tracks
semantic distance. Do this deliberately; the default of "spread them
evenly in whatever order I thought of them" throws away the entire ring
axis.

### Step 1 — Name the axis of variation

Almost every real band varies along one dominant dimension. Find it and
say it out loud: time, scale, formality, cost, abstraction, mechanism
type, degree of intervention, who it serves.

If you cannot name one axis, the band is probably not a band — see the
star case below.

### Step 2 — Classify the band's topology

The ring is a circle, so it can only faithfully hold structures that are
themselves circular. Four cases, and only one is free:

**CYCLE — the ideal.** The band is a process that returns to its start:
phases, seasons, a feedback loop, a life stage. Lay it out directly. The
ring *is* the structure and every property above holds automatically.

**LINE — the common case.** The band is a gradient with two genuine
extremes that are not related to each other. A circle will force those
extremes adjacent, which is a lie. Two honest options:

- **Fold.** Run the gradient across 180° of arc and leave the opposite
  side sparse or empty. Empty ring is not waste; it is an accurate
  statement that the band has ends.
- **Close it, if the extremes genuinely meet.** Many gradients are
  secretly circular — maximum formality and maximum informality often
  share properties that the middle lacks. If you can *say why* the
  extremes touch, close the ring and put the reason in one of their
  views. If you cannot say why, fold.

**CLUSTERED.** Two or three groups with internal cohesion. Place each
group as a contiguous arc and put the **widest angular gaps between the
groups**. The gaps then carry information — see below.

**STAR — a diagnostic, not a layout.** One central item and several
others that relate to it but not to each other. This band is not a band:
the hub belongs one level up, and the spokes are its children. **A star
means you have mis-leveled**, and forcing it onto a ring produces false
sibling adjacencies everywhere. Re-level instead of laying it out.

### Step 3 — Set the gaps, and let them mean something

Do not distribute evenly by reflex. Angular gap is a channel: a wide gap
says "there is a real discontinuity here", a tight cluster says "these
three are nearly the same move".

The constraint is legibility — never go under the band's minimum gap from
the capacity table, or labels collide and the studio drops them. So the
budget is: keep every gap at or above the minimum, and spend whatever
slack remains on the discontinuities that deserve it.

### Step 4 — Run the antipodal check

For three sampled positions, name what sits opposite. If any antipode is
an obvious near-relative, reorder. This is the check that catches a ring
that looks fine band-by-band and reads wrong from inside.

### Step 5 — Check the meridian

For each position with a parent, confirm the parent is within 95°. Fix by
moving the child, not the parent — parents are placed by the band above,
which has fewer slots and less freedom.

---

## When the ring cannot be honest

Some bands have a similarity structure that no circular ordering can
represent — three or more clusters mutually equidistant, or a genuine
tree. Forcing them produces adjacencies the reader will believe and that
are not real.

**Say so rather than fake it.** Options, in order of preference:

1. **Split into threads.** If the band has two clusters that do not
   relate, they are probably two worlds, and a thread move is the honest
   crossing.
2. **Re-level.** Clusters are often a missing intermediate band: the
   cluster heads belong one level up, their members one level down.
3. **Fold and leave the ring sparse.** Honest, if visually thin.
4. **Note it in the file.** A `note:` line saying the ring on band 2 is
   clustered rather than graded costs nothing and stops a reader
   over-reading adjacency.

The failure to avoid is the fourth-best option taken silently.

---

## Tilt, prominence, and what the reader meets first

`TILT = 13°` tips the pole toward the viewer, so bands render as ellipses
rather than lines and the upper bands sit visibly above the lower ones.
Two authoring consequences:

- **The most abstract band is visually dominant** even though it has the
  fewest positions. Its labels are the ones a reader sees without
  navigating. Write those labels hardest.
- **`lon: 0` is the front at rest.** A file opens with `lon: 0` facing
  the reader. Put the position you most want met first there — normally
  `subject-id` itself, which is why the subject conventionally sits at
  `lon: 0`.
