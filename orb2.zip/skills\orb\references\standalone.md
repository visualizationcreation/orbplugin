# orb — standalone builds

How to emit the orb as **one self-contained HTML file** the user keeps,
reopens and shares, instead of a cockpit that lives inside a turn.

This file owns four things that exist nowhere else in the skill: the
**reduction** a build declares, the terrain **data model**, the
**adjacency function**, and the **absolute anchor scale**. The physics,
the instruments, the honesty rules and the chrome are specified in
`SKILL.md`, `references/physics.md` and `references/cockpit.md`; a build
implements them, and nothing here redefines them.

---

## A standalone build is a REDUCED build, and says so

The skill is interlocked: frontier rooms need typed blockers, fans need
authored alternates and rejected candidates, images need sources, verb
mode needs an artifact. A file can carry some of that and not all of it,
and a build that quietly implements half while presenting itself as the
orb is the same dishonesty the frontier rules exist to prevent.

**So a build declares its reduction, in the file, and the declaration is
what makes it honest rather than partial.** The default reduction:

| in scope | out of scope, and declared |
|---|---|
| noun mode | verb mode — no artifact, no cost notes, no reversibility |
| all six directions | fans on the ring and thread axes: those pads offer one destination and do not use the closure vocabulary |
| UP's part-of / instance-of split, with fans | images: no illustration, no photograph, no drought |
| depth floor and thread ends as stated termini | frontier ROOMS — the file names an edge, it does not furnish one |
| the five instruments | the delta line, parking, converse mode |

Everything out of scope is **absent and named**, never faked. A build
that wants more may take more, provided it moves the row and can deliver
it. A build that silently drops an in-scope row has failed.

Because there is no turn, every rule in `SKILL.md` scoped to "every turn"
is out of scope by construction — the output format, the exit line, the
image budget, the turn-one element count. This is the same suspension
`SKILL.md` already grants parking and text mode, not a new kind.

**P1 — what this displaces.** The per-turn rules above, for this one
output. It claims no slot any other rule claims.

**P2 — state.** Three values live for the duration of an opening and
feed rules: the **trail** (the retrace swap and the apex selector read
it), the **visited set**, and the **triangulator base**. All three reset
when the file is closed; none is carried across a turn, because there is
no turn. `ab` is not state — it is authored constant data.

**Trigger and routing live in `SKILL.md`.**

---

## The data model

```js
SUBJECT = { id, label }             // the anchor: a real position in WORLDS
THREAD  = [ { id, label, gloss, entry, cap? }, … ]
WORLDS  = { <threadId>: [ …positions… ] }
```

`gloss` is one sentence naming what this world is downstream or upstream
of. `entry` is the position id a thread move lands on. `cap` is
`"origin"` or `"terminus"`, stated rather than inferred from array
position, so a build can carry a thread that continues past what was
authored and say so.

```js
{ id, label, level, lon, tier, ab, upAlt?, view }
```

| field | meaning |
|---|---|
| `id` | short unique slug |
| `label` | the position, as a full predicate — see `SKILL.md`, "Grammar" |
| `level` | altitude band, integer |
| `lon` | position around the ring, degrees `0–359` |
| `tier` | `city` / `town` / `point` |
| `ab` | anchor removals, `0–3`, on the absolute scale below |
| `upAlt` | id of this position's **instance-of** parent, where one exists |
| `view` | the reading, at the length `SKILL.md` specifies |

`SUBJECT` is a full position reference and not a string, because the
return pad must resolve to somewhere flyable and the triangulator's
unasked `anchor × here` base needs an id on both sides.

`upAlt` is what keeps UP's split representable. `physics.md` requires it
as UP's fan alternate whenever UP is live; a model with only `level`
cannot express it, and a build without it has deleted the mechanism that
makes drift a choice rather than an accident.

**`tier` is not map density.** Density is a scenery setting in
`SKILL.md` and stays one. `tier` may thin what the orb graphic draws; it
must never remove a position from a fan, or a control would be changing
an instrument reading.

**Size.** The subject's world wants enough positions that DOWN has a real
fan at most altitudes — around thirty across five bands — and each
adjacent world about a third of that. Every position needs a full
`view`, so this is the build's real cost; author fewer worlds rather than
thinner ones.

---

## The adjacency function

Pads, ring width, depth and grain derive from this. The anchor does not —
it is the stored `ab`. Stated once, because two builds from the same
terrain otherwise disagree:

- **DOWN** — positions on `level − 1` within 95° of `lon`, nearest first.
  Primary is nearest, the rest are the fan. **Once `ab ≥ 2`, primary
  becomes the route toward `SUBJECT`** per `SKILL.md`'s return pad, and
  the nearest-`lon` destination moves into the fan. Empty ⇒ the floor,
  rendered as a stated terminus.
- **UP** — the nearest `lon` on `level + 1`, **within the same 95°
  window**, so that DOWN then UP returns you and the inverse guarantee
  holds. `upAlt` is the fan alternate, labelled anchor-shedding; where
  part-of would retrace a position already in the trail, `upAlt` becomes
  primary and the retrace moves into the fan, per `SKILL.md`. Empty ⇒ the
  ceiling, rendered as a stated terminus.
- **LEFT / RIGHT** — sort the current world's current band by `lon`, step
  ∓1 and ±1 by index, wrapping. A band of one, or of two where both
  directions reach the same position, renders the exhausted end as a
  **stated terminus** naming the position it would have offered. The axis
  stays intact; a terrain edge is an exhaustion, not a dropping.
- **FORWARD / BACKWARD** — the adjacent THREAD entry, landing on its
  `entry`. Absent ⇒ origin or terminus.

Grain is read off the DOWN fan this returns, per `SKILL.md`. Never store
a grain field: a stored grain can disagree with the fan on screen, which
is the failure the reading was inverted to prevent.

---

## The absolute anchor scale

In a session the anchor is a transition function — it reads the previous
value. Authoring has no previous, so a file cannot run that function, and
pretending otherwise is how `ab` becomes an unstated judgement.

**So a build uses a different, absolute scale, and labels it as one.**
Run both halves of the strip test from `SKILL.md` on the position's own
`view` against `SUBJECT`, then:

| | `ab` |
|---|---|
| both halves FAIL — the position is about `SUBJECT` | **0** |
| both SURVIVE, and `SUBJECT` is the canonical case of this position | **1** |
| both SURVIVE, and `SUBJECT` is one of several cases | **2** |
| both SURVIVE, and the position needs no reference to `SUBJECT` at all | **3** |

This is **referential, not positional** — the property worth keeping. A
position deep in the trail may read *in view* while a nearer one reads
*out of sight*. Because the scale runs against text the file ships, a
reader can re-run it on any `view` and disagree, which is the only reason
it is worth having.

---

## The triangulator in a file

Geometry computes; meaning does not. Author an apex table — pairs of ids
with the third point and a short note, weighted toward positions a user
is likely to have visited both of, and including `SUBJECT` paired against
several distant positions so the unasked `anchor × here` offer has
somewhere to land.

**A table miss is not a degenerate verdict.** `physics.md` defines
degenerate by the triviality of the link, and a fall-through has
considered no link and can name none — so a miss reports plainly that no
apex is authored for this pair. Degenerate is authored: the pairs you
considered and rejected, with the trivial link named. Author some, at
wide bases especially, where `physics.md` says the honest answer is most
often that no third point exists.

---

## What the file must show

Four things, each of which leaves evidence in the artifact:

1. **`SUBJECT`**, displayed, so the anchor gauge and return pad are
   legible.
2. **The snapshot line** — a frozen build, not a live orb.
3. **The anchor labelled as authored on the absolute scale**, wherever it
   renders.
4. **The reduction table**, as the file's own statement of what it is not.

Rule 1 of the wiring contract binds with no `sendPrompt` exception: the
file is its own host, so a control resolves locally or does not exist.
Rule 2 binds too — a chip displaying a value changes to the next one on
click, locally. Serve fonts inline or use system faces; a build makes no
external request.

Deliver the file, then say briefly what terrain you chose, what you
decided, and what the reduction costs for this subject. Offer the live
session as the complement: it goes anywhere and re-measures every turn,
and it does not persist.
