# orbprint — the shell

The implementation contract for a printed orb. `SKILL.md` decides *what*
a build carries; this file decides *how*, and owns the parts that are
easy to get subtly wrong: the rotation loop, the projection, the path
renderer, the density constants, the travel state machine, the seed
panel, and the self-check.

**Every code block here has been run.** The functions are liftable
verbatim. Where a build changes one, it owns the consequences and should
re-run the self-check at the end of this file.

---

## 0. The wiring contract

Inherited from `orb`'s `references/cockpit.md`, with **no `sendPrompt`
exception**: the file is its own host, so a control resolves locally or
it does not exist.

1. Every control does its work in the page. No control emits text for a
   human to act on, except the two clipboard controls in the seed panel,
   which copy and say so.
2. A chip displaying a value changes to the next value on click, locally.
3. **No external request of any kind** — no fonts, no CDN, no analytics,
   no images by URL. System faces or inlined data URLs. A printed orb
   must work with the network off, because "keep it and reopen it" is the
   whole point.
4. No `localStorage`, no `sessionStorage`. State lives in variables and
   resets on close, as `orb`'s standalone rules already require.

---

## 1. The data model

Extends `orb`'s standalone model. Full field table:

```js
BUILD   = { density, positions, bands, worlds, authored, note? }
SUBJECT = { id, label }                       // a real position in WORLDS
THREAD  = [ { id, label, gloss, entry, cap? }, … ]
WORLDS  = { <threadId>: [ …positions… ] }
APEX    = [ { a, b, apex, note, degenerate? }, … ]
```

```js
{ id, label, level, lon, tier, ab, upAlt?, view, edge?, seed? }
```

| field | meaning |
|---|---|
| `id` | short unique slug, unique **within its world** |
| `label` | the position as a full predicate — `orb`, "Grammar" |
| `level` | altitude band, integer; higher is broader |
| `lon` | position around the ring, degrees `0–359` |
| `tier` | `city` / `town` / `point` — **draw** weight only |
| `ab` | anchor removals `0–3`, on the absolute scale in §7 |
| `upAlt` | id of this position's **instance-of** parent, where one exists |
| `view` | the reading, at the length `orb` specifies |
| `edge` | array of direction keys with no authored destination |
| `seed` | optional override for the generated seed prompt |
| `angles` | **two or more** authored next-orb angles, each `{l, f}`: a label and the flat claim it has to survive |

`BUILD.note` is where a build **declares a deviation from its own preset** —
a position count outside the density band, a world dropped, a row of the
reduction taken back. It renders on the face. A build that silently lands
outside its preset has made exactly the unfalsifiable claim this skill's law
forbids; a build that says *46 in the subject world, two above the standard
36–44, because two positions needed children to keep the inverse guarantee*
has not.

`BUILD.positions` must equal the true total across `WORLDS`. Compute it
rather than typing it:

```js
BUILD.positions = Object.values(WORLDS).reduce((n,w)=>n+w.length,0);
```

A build that types the number by hand has created the exact class of
unfalsifiable claim `orb`'s law forbids.

**Spread `lon` deliberately.** Positions in a band should not cluster in
one arc unless the subject genuinely does — a band whose entries all sit
between 0° and 60° spends most of a rotation showing empty sphere.

---

## 2. Geometry and projection

Constants: `R` is the sphere radius, `TILT` tips the pole toward the
viewer so latitude bands read as ellipses rather than as straight lines.

```js
const RAD=Math.PI/180, CX=265, CY=265, R=196, TILT=13;
let viewLon=0;

function latFor(level){                     // bands spread across ±58°
  const L=levels(), i=L.indexOf(level);
  return L.length===1 ? 0 : 58-(116*i/(L.length-1));
}
function vec(lon,lat){                      // world-space unit vector
  const la=lat*RAD, lo=lon*RAD;
  return [Math.cos(la)*Math.sin(lo), Math.sin(la), Math.cos(la)*Math.cos(lo)];
}
function projV(v){                          // spin about Y, then tilt about X
  const a=viewLon*RAD, ca=Math.cos(a), sa=Math.sin(a);
  const x=v[0]*ca - v[2]*sa, z=v[0]*sa + v[2]*ca, y=v[1];
  const t=TILT*RAD, ct=Math.cos(t), st=Math.sin(t);
  const y2=y*ct - z*st, z2=y*st + z*ct;
  return {x:CX+R*x, y:CY-R*y2, z:z2, front:z2>-0.02};
}
function project(lon,lat){ return projV(vec(lon,lat)); }
```

`vec` is deliberately **independent of `viewLon`** — world space, not
screen space. The path renderer interpolates in world space and projects
afterwards; interpolating in screen space produces a line that swims when
the orb turns.

**Draw far side first.** Sort by `z` ascending before emitting nodes, so
near markers paint over far ones.

---

## 3. The rotation loop

```js
let targetLon=null, dragVel=0, idleFrames=0, paused=false;
const SPIN=0.11;                            // deg/frame ≈ 6.6°/s ≈ 55s a revolution

function reduced(){ return matchMedia("(prefers-reduced-motion: reduce)").matches; }

function tick(){
  if(targetLon!==null){                     // easing a clicked point to the front
    let d=((targetLon-viewLon+540)%360)-180;
    if(Math.abs(d)>0.35) viewLon=(viewLon+d*0.16+360)%360;
    else { viewLon=targetLon; targetLon=null; }
  } else if(Math.abs(dragVel)>0.02){        // drag inertia, decaying
    viewLon=(viewLon+dragVel+360)%360; dragVel*=0.94;
  } else if(spinOn && !paused && !reduced()){
    if(++idleFrames>36) viewLon=(viewLon+SPIN+360)%360;   // ~0.6s idle before resuming
  }
  draw();
  requestAnimationFrame(tick);
}
```

**The precedence is the specification**: an easing target beats drag
inertia, which beats the idle spin. Any other order produces an orb that
fights the user.

### 3a. `draw()` MUST NOT REBUILD THE FACE

This is the single most consequential line in the file, so it is stated
as a prohibition rather than a preference:

> **`draw()` never assigns `innerHTML`, never calls `removeChild`, and
> never constructs an element. It writes attributes on nodes that already
> exist.**

Markers are mounted ONCE per world and mutated sixty times a second
thereafter. An earlier revision rebuilt the marker layer every frame, and
that one decision is the root of six separate rules elsewhere in this
file — the pointerdown target capture, the `elementFromPoint` fallback,
the pause-on-hover, the pause-on-focus, and both halves of the tap/drag
threshold. **They are all compensations for nodes that vanish mid-gesture.**
Mount once and most of them stop being necessary.

```js
const NS="http://www.w3.org/2000/svg";
function el(n,a,txt){ const e=document.createElementNS(NS,n);
  for(const k in a) e.setAttribute(k,a[k]);
  if(txt!=null) e.textContent=txt; return e; }

const nodes=new Map();                       // "world/id" -> <g>

/* ONCE per world — on load, and on a thread move. NOT in tick(). */
function mountFace(){
  face.textContent=""; nodes.clear();
  for(const p of WORLDS[world]){
    const key=world+"/"+p.id;
    const g=el("g",{class:"node","data-go":key,tabindex:"0",
                    role:"button","aria-label":p.label});
    g.append(el("circle",{r:4,class:"dot"}));
    g.append(el("text",{class:"lbl",x:8,y:4},p.label));
    face.append(g); nodes.set(key,g);
  }
}

/* EVERY FRAME — attributes only. No allocation, no node churn. */
function draw(){
  for(const p of WORLDS[world]){
    const g=nodes.get(world+"/"+p.id), q=project(p,viewLon);
    g.setAttribute("transform","translate("+q.x+" "+q.y+")");
    g.setAttribute("data-front",q.front?"1":"0");
    g.style.opacity=q.front?1:0;
    g.style.pointerEvents=q.front?"auto":"none";       // back face is not a target
  }
  drawPath();                                          // §4, its own layer
  placeLabels();                                       // §8, only when viewLon moved
}
```

**Three layers, three lifetimes.** Keep them as separate `<g>` children of
the SVG so each can be updated on its own clock:

| layer | rebuilt when | touched per frame |
| --- | --- | --- |
| `#face` — markers | world changes | transform + opacity only |
| `#path` — the trail | `travel()` | `d` attribute only |
| `#chrome` — plate, grid | never | never |

The path layer may keep rebuilding its `<path>` elements on `travel()`
alone — the trail changes on travel, not on rotation, and its `d` string
is cheap to recompute per frame. **Nothing in the path layer is
focusable or clickable**, which is why it is exempt from the prohibition
above. The rule protects interactive nodes; it is not a blanket ban on
generating markup.

### 3b. What mounting once actually fixes

The click bug in §8 is the visible symptom. Three more failures share the
cause and are worth naming, because none of them errors and none was
caught by a passing test run:

- **Focus becomes durable rather than conditional.** The current file
  says focus survives "because a paused orb is not redrawn" — a guarantee
  that holds only while paused. With persistent nodes a keyboard user can
  tab to a marker on a *spinning* orb and keep it, which today they
  cannot. This is the accessibility failure, not the click.
- **Screen readers stop re-announcing.** Replacing the subtree every
  frame presents 200 nodes as brand new sixty times a second. The ARIA
  attributes in §8 are correct and were doing nothing.
- **Allocation drops to zero in the steady state.** ~200 nodes × 60fps is
  ~12,000 element allocations per second, all immediately garbage. The
  cost shows up as jank on low-end phones, which is exactly where a
  shared file gets opened.

**A reconciling framework would also fix this, and is the wrong trade.**
Diffing a virtual tree of 200 nodes each frame is strictly more work than
writing one transform attribute each, and it costs the file its "no
external request, opens with the network off" guarantee. Mount once, and
you get the benefit at a fraction of the cost.

**Paused when the user is doing something.** Set `paused=true` on
pointerdown, on `mouseover` of a marker or its label, and while a panel
has keyboard focus; clear it on the matching release, resetting
`idleFrames=0` so the spin waits out the idle window before resuming.

**Rate.** `SPIN=0.11` deg/frame is a full revolution in about 55 seconds
at 60fps. Slower than this and the back of the ring takes too long to
arrive; faster and labels become unreadable. If a build changes it, keep
the revolution between 40 and 90 seconds.

**Reduced motion.** `reduced()` kills the idle spin only. Drag, click
travel, the pads and the keyboard still work, and the orb is fully
navigable with no automatic motion at all. **Test this path.** A build
that becomes a still image with unreachable back-side positions when
motion is off has failed the row it claimed.

**A spin control ships**, labelled `spin: on` / `spin: off`. It is a
preference, not a fact, so it gets a handle — and a user reading a long
`view` should not have to fight the globe.

---

## 4. The path renderer

The trail is `[{w, id}, …]` in visit order. Consecutive entries produce
one of two things.

**A surface segment**, when both stops are in the same world:

```js
function slerp(v0,v1,u){
  let d=v0[0]*v1[0]+v0[1]*v1[1]+v0[2]*v1[2];
  d=Math.max(-1,Math.min(1,d));
  const om=Math.acos(d);
  if(om<1e-4) return v0.map((c,i)=>c+(v1[i]-c)*u);     // coincident: lerp, no divide by zero
  const s=Math.sin(om), a=Math.sin((1-u)*om)/s, b=Math.sin(u*om)/s;
  return v0.map((c,i)=>c*a+v1[i]*b);
}

/* great-circle segment, split into runs of consecutive front/back samples */
function arcRuns(p0,p1){
  const v0=vec(p0.lon,latFor(p0.level)), v1=vec(p1.lon,latFor(p1.level));
  let d=v0[0]*v1[0]+v0[1]*v1[1]+v0[2]*v1[2]; d=Math.max(-1,Math.min(1,d));
  const steps=Math.max(8,Math.ceil(Math.acos(d)/RAD/4));   // a sample every ~4°
  const runs=[]; let run=null;
  for(let i=0;i<=steps;i++){
    const q=projV(slerp(v0,v1,i/steps));
    if(!run || run.front!==q.front){ if(run&&run.pts.length) runs.push(run);
      run={front:q.front, pts:[]}; }
    run.pts.push(q);
  }
  if(run&&run.pts.length) runs.push(run);
  return runs;
}
```

Emit each run as a `<polyline>`. **Back runs draw before the globe body
at low opacity; front runs draw after the nodes.** That ordering is what
makes the line look like it is lying on a sphere rather than floating
over a disc.

Opacity and width ramp with age so direction reads without arrowheads,
which do not survive at these widths:

```js
stroke-opacity = 0.35 + 0.55*age        // age: 0 oldest … 1 newest
stroke-width   = 1.4  + 1.1*age
```

**A thread crossing draws a break, never a segment.** When
`trail[i-1].w !== trail[i].w`, emit no arc. Render a labelled marker
naming the crossing — *"→ Afterwards"* — and keep a count on the face
(*"2 thread crossings in this path"*). `orb` keeps surface motion and
neighbourhood relocation visually separate; a smooth line across a thread
move asserts an adjacency that does not exist.

**Retracing thickens, it does not duplicate.** Keep
`visits: Map<"world/id", count>`. A revisited position draws in the
visited colour with its count; a repeated segment draws once, thicker.

**The drawn path and the text route are one data source.** Render the
arrow-separated route from the same `trail` array in the same pass. If
they can disagree, the build is broken.

---

## 5. Density

**BUILD density** — authored, fixed, stated on the face:

| preset | subject's world | bands | adjacent worlds |
|---|---|---|---|
| sparse | 18–22 | 3 | 2 × ~6 |
| standard | 36–44 | 5 | 4 × ~10 |
| dense | 70–85 | 5–6 | 4–6 × ~15 |
| exhaustive | 140–160 | 6–7 | 6 × ~20 |

**DRAW density** — a page control, thinning by `tier`:

```js
const TIERS={ sparse:["city"], normal:["city","town"], dense:["city","town","point"] };
function drawn(){
  const keep=TIERS[drawDensity];
  return W().filter(p => keep.includes(p.tier)
                      || p.id===cur.id                       // never hide where you are
                      || visits.has(world+"/"+p.id));        // never hide where you have been
}
```

**`drawn()` feeds the renderer and nothing else.** The adjacency
functions read `W()`, the full world. A position hidden at `sparse` is
still offered by its pad and still reachable — verified in the self-check
below. If the fans read `drawn()`, a rendering preference has become a
control over a fact, and `orb`'s rule against that is violated.

**The instrument panel must be byte-identical across all three draw
densities.** That is the check that proves the split held.

---

## 6. Adjacency

Identical to `orb`'s standalone adjacency function; restated as code
because two builds from the same terrain otherwise disagree.

```js
function W(){ return WORLDS[world]; }
function levels(){ return [...new Set(W().map(p=>p.level))].sort((a,b)=>b-a); }
function dlon(a,b){ const d=Math.abs(a-b)%360; return d>180 ? 360-d : d; }

function down(){ return W().filter(p=>p.level===cur.level-1 && dlon(p.lon,cur.lon)<=95)
                           .sort((a,b)=>dlon(a.lon,cur.lon)-dlon(b.lon,cur.lon)); }
function up(){   return W().filter(p=>p.level===cur.level+1 && dlon(p.lon,cur.lon)<=95)
                           .sort((a,b)=>dlon(a.lon,cur.lon)-dlon(b.lon,cur.lon)); }
function ringBand(){ return W().filter(p=>p.level===cur.level).sort((a,b)=>a.lon-b.lon); }
function step(d){ const b=ringBand(), i=b.findIndex(p=>p.id===cur.id);
                  return b.length<2 ? null : b[(i+d+b.length)%b.length]; }
```

**THE CHILD RULE, and it constrains authoring rather than code.** The 95°
window means DOWN returns whatever is nearest below within that arc, which
need not be a child of this position at all. So for every position, exactly
one of two things must be true: **either it has its own nearest position on
the band below — a real child — or it has nothing at all within 95° of it
there.** Anything in between hands the user a cousin and silently breaks the
inverse guarantee, which check 5 will catch and which is tedious to repair
once readings are attached. Verify it on the skeleton, at step 2 of the
authoring order, before writing a word of `view`.

Repairing it costs positions: the fix is to author the missing child, which
can push a world past its density preset. That is fine, and it is what
`BUILD.note` is for — the real build that produced this rule landed at 46 in
a 36–44 band for exactly this reason and said so.

- **DOWN** — primary is nearest; the rest is the fan. Once `ab >= 2`,
  primary becomes the route toward `SUBJECT` per `orb`'s return pad, and
  the nearest destination moves into the fan. Empty ⇒ the floor, as a
  stated terminus.
- **UP** — nearest `lon` on `level+1` within the same 95° window, so
  DOWN-then-UP returns you. `upAlt` is the fan alternate, labelled
  anchor-shedding; where part-of would retrace a position already in the
  trail, `upAlt` becomes primary. Empty ⇒ the ceiling, as a stated
  terminus.
- **LEFT / RIGHT** — ∓1 and ±1 by index around the sorted band, wrapping.
  A band of one, or of two where both directions reach the same position,
  renders the exhausted end as a **stated terminus naming the position it
  would have offered**. "— exhausted" alone is not enough; the user is
  entitled to know what is not there.
- **FORWARD / BACKWARD** — the adjacent `THREAD` entry, landing on its
  `entry`. Absent ⇒ origin or terminus, from `cap`.

Grain reads off the DOWN fan this returns. **Never store a grain field** —
a stored grain can disagree with the fan on screen, which is the failure
the reading was inverted to prevent.

---

## 7. The absolute anchor scale

A session's anchor is a transition function reading the previous value.
Authoring has no previous, so a file cannot run it. **A build uses a
different, absolute scale and labels it as one, wherever it renders.**

Run both halves of `orb`'s strip test on the position's own `view`
against `SUBJECT`, then:

| | `ab` |
|---|---|
| both halves FAIL — the position is about `SUBJECT` | **0** |
| both SURVIVE, and `SUBJECT` is the canonical case | **1** |
| both SURVIVE, and `SUBJECT` is one of several cases | **2** |
| both SURVIVE, and the position needs no reference to `SUBJECT` | **3** |

Referential, not positional: a position deep in the trail may read *in
view* while a nearer one reads *out of sight*. Because the scale runs
against text the file ships, a reader can re-run it on any `view` and
disagree — which is the only reason it is worth having.

---

## 8. Travel, and the state machine

```js
let world="…", cur=…, trail=[{w:world,id:cur.id}];
const visits=new Map([[world+"/"+cur.id,1]]);

function travel(w,id){
  if(w!==world){ world=w; }
  cur=WORLDS[world].find(p=>p.id===id);
  trail.push({w:world,id:cur.id});
  const k=world+"/"+cur.id; visits.set(k,(visits.get(k)||0)+1);
  targetLon=cur.lon; idleFrames=0; render();
}
```

- A **ring or altitude** click eases the target to the front. Never jump
  cut: which way you went is the information.
- A **thread** move relocates the neighbourhood. Fade the stage out and
  back — `orb`'s `threadTransition` — so the change of sphere is visible.
  Do not ease across it; there is nothing to ease along.
- **Markers are buttons, and a `click` handler is not enough to make them
  work.** This is the bug a build ships most reliably, because the spec used
  to stop at the ARIA attributes and the self-check never pressed one. The
  renderer replaces `svg.innerHTML` on every animation frame while the orb
  turns. A `click` event requires press and release on the *same* element, so
  a single pixel of pointer drift between them lands on an element that no
  longer exists and the click is swallowed. The pads keep working, the orb
  does not, and nothing errors — which is why it survives a passing test run.

  **With §3a's persistent nodes a plain `click` works** — press and
  release land on the same element, because the element is still there.
  Keep the pointer handling below anyway: it is what separates a tap from
  a drag, which is a real distinction and not a workaround. What §3a lets
  you delete is the `elementFromPoint` capture fallback, which existed
  only because `e.target` could be a node that no longer existed by the
  time the pointer came up.

  **Resolve the target on `pointerdown` and fire on `pointerup`:**

```js
var isDown=false,lastX=0,pressId=null,pressMoved=0,pressShift=false,TAP=7;
function hit(e){
  var n=e.target&&e.target.closest?e.target.closest("g.node"):null;
  if(n) return n.getAttribute("data-go");
  var el=document.elementFromPoint(e.clientX,e.clientY);       // capture fallback
  var m=el&&el.closest?el.closest("g.node"):null;
  return m?m.getAttribute("data-go"):null;
}
svg.addEventListener("pointerdown",function(e){
  isDown=true; pressMoved=0; lastX=e.clientX; pressShift=e.shiftKey;
  pressId=hit(e);                                              // captured before any redraw
  paused=true; dragVel=0; targetLon=null;
  try{svg.setPointerCapture(e.pointerId);}catch(err){}
});
svg.addEventListener("pointermove",function(e){
  if(!isDown) return;
  var dx=e.clientX-lastX; lastX=e.clientX; pressMoved+=Math.abs(dx);
  if(pressId&&pressMoved<TAP) return;        // hold still under the pointer until it is clearly a drag
  viewLon=(viewLon+dx*0.32+360)%360; dragVel=dx*0.32; dirty=true;
});
svg.addEventListener("pointerup",function(){
  if(!isDown) return; isDown=false;
  if(pressId&&pressMoved<TAP){ dragVel=0;
    var g=pressId.split("/");
    if(pressShift) togglePin(pressId); else travel(g[0],g[1]); }
  pressId=null; paused=false; idleFrames=0;
});
```

  Two consequences worth stating rather than leaving implied. **The delegated
  `click` handler must skip anything inside the SVG** (`if(t.closest("svg"))
  return;`) or a marker fires twice. And **the pointer being anywhere over
  the plate pauses the spin** — `pointerenter` and `pointermove` set `paused`,
  `pointerleave` clears it — because a marker that rotates out from under a
  cursor between aiming and pressing is the same bug in a slower form.

- **Keyboard still works, and focus survives rotation** — not merely
  pausing — because §3a mutates markers instead of replacing them:
  `tabindex="0"`, `role="button"`, `aria-label` = the label, Enter and
  Space activate, and `focusin` still pauses (a reader should not have to
  chase a moving target, even though focus would now survive if they
  did). Arrow keys drive UP / DOWN /
  LEFT / RIGHT from anywhere outside a text field; shift with left or right
  crosses the thread; shift with Enter pins.
- **Labels flip and drop.** A label that would run past the right edge
  renders left of its marker with `text-anchor="end"`; a label that would
  collide with one already placed is **dropped, not overlapped**, except
  for the current position which always renders. Keep a `placed[]` box
  list and test against it. *(This is the failure a build ships most
  often — at `dense`, labels run off the plate and the orb looks broken.)*

---

## 9. The point panel

In this order, per `SKILL.md`:

1. **The reading** — `cur.view`.
2. **The instruments** — depth, grain, anchor, reach, and the shape line.
   All computed. `anchor` renders with its scale named: *"anchor: 2
   removed (authored, absolute scale)"*.
3. **The six pads** — live pads name their destination; dead pads render
   as stated termini naming what is not there, and are `disabled`.
4. **The seed workshop.**

**A single generated prompt is not enough, and the reason is the same one
that makes the orb worth building.** A file that hands back one fixed string
per position has decided in advance what the next orb is about. The user has
just spent time browsing; they know something the build did not. So the seed
is composed from **clickable options**, and every control rewrites the box.

**ANCHOR THE NEXT ORB ON** — a radio row, assembled per position:

- *this position* — the default.
- *each authored angle* from `cur.angles`, at least two. These are the
  eccentric doors: sideways, cross-domain, the reason someone would want a
  next orb at all rather than a finer one. **The flat claim renders on the
  card and is carried into the prompt**, per `../orb/references/physics.md`:
  write the
  connection as an ordinary sentence with no wonder in it, and if the flat
  version is not defensible the angle does not ship.
- *each `APEX` entry involving this position*, as its apex.
- *each degenerate `APEX` entry involving it*, offered as **re-test the
  rejected pair** with the trivial link this build named. Handing back a
  verdict to be refuted is worth more than hiding it.
- *the whole ring at this altitude* — anchor on the band rather than the
  point, so the next orb's ring is this band expanded.
- *the pinned set* — disabled below two pins, so it is never a dead control.

**HOW THE NEXT ORB SHOULD RUN** — `mode: noun | verb` (verb appends the
smallest-artifact instruction), the four density presets, `creative mode`.
**CARRY INTO THE PROMPT** — the anchor, the trail, this whole reading, and
the file's declared reduction as provenance. All toggles, all live.

**PINNING is the browsing tool that makes the pinned set possible.**
Shift-click a point on the orb, or use the workshop control; pinned points
take a distinct ring, are never thinned by draw density, and collect in a
rail under the globe with a clear-all and a *use the pinned set* control.
The composed prompt names every pinned point **and instructs the next orb to
report the base degenerate rather than invent an apex if it is too wide** —
the triangulator's failure mode, carried forward instead of dropped.

```js
function seedText(){
  const o=selectedOption(), L=[];
  L.push("/orbprint "+o.subject, "");
  L.push("density: "+seedState.density, "mode: "+seedState.mode);
  if(seedState.creative) L.push("creative mode: on — widen the triangulator base");
  if(seedState.carry.anchor) L.push("anchor: "+SUBJECT.label);
  if(seedState.carry.trail)  L.push("trail: "+routeText());
  L.push("", o.why);
  if(o.flat) L.push("", "Carried from the source file — "+o.flatlbl.toLowerCase()+": "+o.flat);
  if(seedState.mode==="verb") L.push("", "Run this as work rather than as a subject: name the "+
    "smallest artifact that would count as having done it, state it in one line before the "+
    "first move, and make every pad perform a move on that artifact.");
  if(seedState.carry.reading)   L.push("", "The reading this was reached from:", cur.view.split("\n\n").join(" "));
  if(seedState.carry.reduction) L.push("", "Provenance: reached inside a printed orb on \""+SUBJECT.label+
    "\" (build "+BUILD.density+", "+BUILD.positions+" positions, frozen "+BUILD.authored+"). That file "+
    "carried no images, no verb mode, and an authored absolute anchor scale rather than a live strip "+
    "test. Re-derive those rather than inheriting them.");
  return L.join("\n");
}
function addrText(){
  return "anchor: "+SUBJECT.label+" | trail: "+routeText()
    +" | pinned: "+(pins.size?Array.from(pins).map(labelOf).join("; "):"none")
    +" | settings: build="+BUILD.density+", draw="+drawDensity+" | mode: noun";
}
```

Two clipboard controls: **copy prompt** and **copy address**. Both confirm in
place, and the prompt also sits in a read-only textarea so a browser that
blocks clipboard access still lets it be selected — a control that silently
fails is worse than no control.

**At an edge position the workshop promotes itself.** When `cur.edge` is
non-empty, it leads with *this file ends here in these directions; this
prompt continues it* and the dead pads point at it. That join is the only
honest way for a file to end.

**The seed must actually run.** Paste-test one before shipping.

---

## 9b. Reading time — arithmetic, not a sixth instrument

The five instruments are fixed and enumerated in `orb`'s SKILL.md. Reading
time is **not** one of them and must not be rendered as a sixth gauge. It is
arithmetic over text the file already carries, which is precisely why it is
allowed at all: the law asks that a number be a count of something the build
was already obliged to write, and word counts are the purest available case.

```js
const WPM=220;                                    // the one assumption; state it on the face
const WORDS=new Map(), MINS=new Map();
Object.keys(WORLDS).forEach(function(w){WORLDS[w].forEach(function(p){
  var n=p.view.trim().split(/\s+/).length;
  WORDS.set(w+"/"+p.id,n); MINS.set(w+"/"+p.id,Math.max(1,Math.round(n/WPM)));});});
BUILD.words   = Array.from(WORDS.values()).reduce(function(a,b){return a+b;},0);
BUILD.minutes = Array.from(MINS.values()).reduce(function(a,b){return a+b;},0);
function minsRead(){var t=0;visits.forEach(function(v,k){t+=MINS.get(k)||0;});return t;}
```

Render it as its own strip below the gauges, never inside them: **this
position** (with its word count), **this band**, **this world**, **the whole
file**, and **read so far** across distinct visited positions as a percentage
with a bar. Put the per-destination cost on every pad and fan entry — *"DOWN ·
the mechanism · ~2 min to read"* — because that is where it changes a
decision. Name the rate in the strip and say plainly that it is the only
assumption on the line.

Reading time is also the honest scale check on a build. A standard build runs
around 150–200 words a position; if the total lands far under that, the
readings are stubs and the fix is prose, not positions.

## 10. What renders on the face

Four things, each leaving evidence in the artifact:

1. **`SUBJECT`**, displayed, so the anchor reading and return pad are legible.
2. **The snapshot line** — a frozen build with its date, not a live orb.
3. **`BUILD`** — density and the computed position count.
4. **The reduction table**, in a collapsible block, as the file's own
   statement of what it is not.

Plus a one-line help note saying what the spin does and does not cover:
*the rotation walks the ring; altitude is climbed by clicking.*

---

## 11. Self-check — run this before delivering

Twelve checks. Each one has caught a real failure in a shipped build.

1. **`BUILD.positions` is computed** from `WORLDS`, not typed, and the
   face shows it.
2. **Rotation advances.** Sample `viewLon`, wait a second, sample again.
   Different.
3. **Reduced motion.** With `prefers-reduced-motion: reduce`, the orb
   does not auto-spin, and every position is still reachable by pad,
   arrow key and drag.
4. **The arc lies on the sphere.** Every sampled point of every
   `arcRuns` segment is within `R` of the centre.
5. **Inverse guarantee.** From several positions: DOWN then UP returns
   you to where you started.
6. **The ring wraps.** RIGHT repeatedly from any band returns to the
   start after exactly `band.length` steps.
7. **A thread move draws no arc** and increments the crossing count.
8. **Draw density is inert.** The instrument panel is byte-identical at
   sparse, normal and dense; the drawn marker count differs; and a
   position hidden at sparse is still offered by a pad and still
   reachable.
9. **No console errors, no external requests.** Load the file with the
   network disabled and confirm both.
10. **A marker tap travels — with drift.** Press a point, move the pointer
    **one pixel**, release. It must travel. Then press, drag thirty pixels,
    release: it must rotate and **not** travel. This is check 10 because
    checks 1–9 all passed on a build whose orb could not be clicked at all.
10a. **Focus survives a full revolution.** Tab to a marker while the orb
    is spinning, then let go of the keyboard and watch one complete
    rotation. `document.activeElement` must be the same node at the end.
    This is the check the old renderer could not pass, and unlike check
    10 it cannot be faked by pausing — the orb must be *moving* while
    focus is held.
10b. **The face is mounted once.** Wrap `face.innerHTML` in a setter that
    counts writes, or simply hold a reference to one marker `<g>` and
    confirm it is still `isConnected` after a hundred frames. A build that
    re-mounts per frame passes every other check in this list.
11. **Every position offers options for the next prompt.** `cur.angles` has
    at least two entries everywhere, every flat claim is a real sentence, and
    none of them matches the degenerate boilerplate list — *both involve*,
    *both are systems*, *both concern time*. Then click through one position's
    workshop and confirm each control changes the text in the box.
12. **Reading time recomputes.** Sum the word counts independently and match
    them against what the face prints, and confirm the instrument panel still
    holds exactly five gauges.

Then look at it. At `dense`, in the subject's world, with a path of six
or more stops: labels inside the plate, the path legible over and behind
the globe, the newest segment clearly the brightest.
