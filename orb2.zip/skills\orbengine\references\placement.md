# Placement — coordinates by measurement

> **v1.2.1.** Arc is allocated by *break* — how unlike each neighbouring
> pair is — rather than scaled linearly from `d`. The fold is **located**
> at the largest resulting gap instead of imposed at a fixed span, and
> `d` is demoted from placement driver to global coherence check.

`geometry.md` says a ring should be ordered so relatedness falls off
toward the antipode. It then leaves that to judgement. This file computes
it.

The calculator is a **transducer, not an oracle.** It does not decide what
a position means. It takes two semantic scores per position and converts
them into coordinates deterministically, enforcing the legibility
constraints that `geometry.md` states but never checks. The honesty of an
orb still rests entirely on the scoring pass. What the arithmetic buys is
that the scale stops drifting, the same inputs always give the same orb,
and adding one position re-solves the band instead of re-feeling it.

---

## Anchors — you need three, not two

The instinct is to fix two extremes: the broadest idea, and the most
distant idea that is still relevant. That is nearly right, and it is
short by one.

| anchor | fixes | why |
| --- | --- | --- |
| **A** — apex | `level 0` | the top of the generality scale |
| **S** — subject | `lon 0` | the ring's origin |
| **F** — far | `lon ±span` | the unit of ring distance |
| **L** — left | the sign | **breaks the reflection** |

**Two anchors cannot determine a circle.** With only S at 0 and F at the
far end, a position scored `d = 0.4` is equally consistent with `+38°` and
`−38°`. The two anchors are symmetric about the S–F axis and carry no
information about which side anything falls on. You need a third,
off-axis reference to fix the chirality — which in practice is the axis of
variation from `geometry.md` step 1, used as a sign rather than as an
ordering.

This is the same reason landmark trilateration needs three stations to
place a point in a plane and not two. Distances to two landmarks leave a
mirror pair.

**Choosing F is the load-bearing decision.** It sets the unit: every other
`d` is read as a fraction of the S→F interval. Pick F too close and the
whole ring saturates near 1.0; pick something that is not actually
relevant and every other position compresses toward the origin. The test
is the one already in `terrain.md` for `ab: 3` — recognisably a different
topic that the trail still honestly reaches.

---

## The two scores

Per position, both in `[0,1]`, both scored **in a single pass against the
anchors** rather than absolutely:

- **`g` — generality.** `1` = as broad as A. `0` = as concrete as the
  floor. Drives latitude.
- **`d` — ring distance.** `0` = the band's reference member. `1` = F.
  **Orders** the ring, and serves as the global coherence check. It no
  longer sets the angle.
- **`brk` — break to the next member.** `0` = nearly the same move,
  `1` = a real discontinuity. **This sets the angle.**

**`brk` must be scored independently, not derived from adjacent `d`
differences.** Deriving it is not a cheaper version of the idea — it is a
no-op. If `brk[i] = d[i+1] − d[i]`, cumulative arc is proportional to
`d[i] − d[0]`, which is linear scaling from `d` exactly. The derived
placement is identical to the previous version's, digit for digit. Two
scores that collapse into one are one score.

Score by comparison to the anchors, not on an abstract scale. *"Is this
nearer to the subject or to F, and roughly where between?"* is a far more
stable judgement than *"rate this 0 to 1"*, and it is the whole reason for
fixing anchors first. It is also why the pass must happen once, at the
end, for the same reason `terrain.md` already requires of `ab`.

`side` comes from the axis of variation. `ab` stays a separate judgement —
see the collinearity warning below.

---

## What the calculator does

```
level  = round((1 − g) · (nBands − 1))
order  = sort by side · d
wedge  = arc around the parent, bounded by its neighbours and 95°
lonRaw = allocate wedge in proportion to brk
lon    = relax(lonRaw, minGap(level))
fold   = the widest gap that results
```

**`relax` is the part worth having.** Weights will routinely ask for
angles that collide — two positions scored `d = 0.41` and `0.43` want to
sit 4° apart in a band whose labels need 30°. The solver finds the
placement closest to what the weights asked for, subject to every adjacent
gap meeting the minimum, on a circle.

It is an exact solve, not an iterative nudge. Substituting
`bᵢ = aᵢ − (i−1)·m` turns the gap constraints into plain monotonicity, so
pool-adjacent-violators solves it; the wrap-around gap becomes a range
constraint handled by clamping into a window and searching the offset.
Every cut point is tried and the cheapest kept. Bands are small enough
that the cost is irrelevant.

Three properties matter: it is a **no-op when the weights already fit**,
it **never reorders**, and it **refuses rather than overlaps** when a band
is genuinely overfull.

**`drift` is the diagnostic.** It reports how far each position was pushed
from the angle its weight asked for. Low drift everywhere means geometry
and meaning agree. One position with high drift is usually a scoring
error. High drift across a whole band means the band has more members than
the ring can carry at that latitude, and the answer is to re-level or
split a thread — not to shrink the gap.

---

## Two conflicts the arithmetic exposes

Both were latent in the existing rules. Making placement computable is
what forced them into view.

### 1. A far anchor at 180° cannot coexist with the 95° meridian rule

`geometry.md` requires a child within 95° of its parent. If ring distance
maps to a half-circle, a position at `d = 0.53` is exactly 95° from a
parent on the origin meridian, and **everything beyond it breaks the
rule** — not occasionally, but always, by construction:

| `d` | lon at span 180 | distance to parent | meridian |
| --- | --- | --- | --- |
| 0.40 | 72° | 72° | ok |
| 0.53 | 95° | 95° | limit |
| 0.80 | 144° | 144° | breaks |
| 1.00 | 180° | 180° | breaks |

These are not competing preferences; they are inconsistent constraints. A
single parent's children can span at most 190° of arc, so a far anchor at
180° is unreachable by any child of the subject's own meridian.

**Resolution: the fold is found, not fixed.** A uniform `span = 95`
satisfies the meridian rule by brute force — it works, and it is crude,
because it imposes the same fold on every band regardless of what is in
it. v1.2 replaces it.

**Arc is allocated in proportion to break.** Score `brk` for each
neighbouring pair — how much of a discontinuity is this? — and spend the
available arc proportionally. Tight clusters get tight gaps; real breaks
get wide ones. The **largest gap that falls out is the fold.** Nobody
chooses it.

**Allocation is hierarchical, and that is what makes it work.** Children
are placed inside their own parent's wedge. Breaks decide spacing
*within* a wedge; the boundaries *between* wedges are inherited from
wherever the band above placed the parents.

**Sizing is anchored to legibility, and it has to be.** A wedge's width
swings between two failures if it is anchored to anything else. Capped on
how close the neighbouring parents happen to sit, every wedge collapses
to the minimum-gap floor and the break signal disappears entirely —
measured, careful scoring and no scoring at all produced the same ring to
within 4 degrees. Scaled off raw break sums instead, wedges balloon to
the full meridian envelope.

So: every wedge is guaranteed the arc its members need to stay readable,
a gap is reserved between wedges, and only the **surplus** is handed out
in proportion to dissimilarity. Breaks decide who gets the spare room,
not whether anyone fits. `SPREAD` sets how much of the surplus is in
play; at `0.55`, careful scoring now moves positions a mean of 10 degrees
against flat scoring, with individual positions moving up to 26.

**The fold therefore recurses.** A large break at level N−1 pushes two
parents apart, and that gap becomes the empty arc their children inherit
at level N. Measured on an eight-position, three-parent band: the flat
scheme left children a mean of 34° from their parents with a worst case
of 74°; hierarchical allocation brings that to 19° and 31°, with no
meridian violation at all.

**Meridian coherence stops being an audit and becomes a consequence.**
The 95° rule was previously a constraint checked after placing. Under
hierarchical allocation a child cannot leave its parent's wedge, so the
rule holds by construction — which is the real argument for the scheme,
more than the fold.

**Where a wedge wants more arc than its neighbours leave, that is a fact
about the band above.** It is reported as `parents-too-tight` rather than
absorbed: the parents were placed closer together than their children can
sit under, and the repair is to widen the break between those parents or
split a thread — one level up, not here.

**A corollary worth stating: a cross-wedge break is not yours to score.**
If two adjacent positions sit under different parents, the discontinuity
between them belongs to the band above, where those parents were placed.
The calculator warns when a large `brk` crosses a wedge boundary whose
parents sit close together — the feeling is real, the level is wrong.

### 2. `ab` and ring distance measure the same thing

`ab` is removals from the subject. If `lon` is also driven by distance
from the subject, the two are the same measurement rendered twice, and one
of them is decoration. The test orb scored **r = 0.96**.

**Resolution: measure `d` within the band, from the band's own reference
member — not from the global subject.** Then `d` is dissimilarity among
siblings and `ab` stays topical removal, which can be high for something
sitting adjacent on the ring. The calculator reports the correlation and
warns above `0.9`, so this is checkable per orb rather than assumed.

---

## What this does not do

- **It does not produce `g` and `d`.** Those are semantic judgements, and
  no amount of arithmetic downstream repairs a bad one. The calculator
  makes scoring *consistent*, not *correct*.
- **It does not place across bands.** Each band solves independently; the
  meridian check runs after and reports, rather than jointly optimising.
  Joint solving would let a parent be dragged by its children, which
  `geometry.md` explicitly forbids.
- **It does not know when a band should not be a ring.** The STAR
  diagnostic is still yours. A star will solve cleanly and be wrong.
- **It cannot see global drift from local scores.** `brk` compares
  neighbours; the antipodal law is a property of the whole ring. Eight
  individually defensible breaks can still land two near-relatives
  opposite each other, and nothing local detects it. Nothing in this file
  catches that. The check that does live in `orb-validate.js`, which
  correlates view text similarity against angular distance — it measures
  meaning rather than weights, which is the only place the antipodal law
  can honestly be tested. Run it, and still run the antipodal check by
  hand.
- **It cannot render extreme break ratios.** Gaps of `0.15` and `0.85` in
  one wedge want a 5.7:1 spread, and both gaps must clear the minimum
  legible angle, so the small one gets floored and the ratio compresses.
  Breaks bite in the moderate range. A wedge scored `0.05 / 0.95` will
  come out looking much like one scored `0.2 / 0.8`.

---

## Usage

```js
const { place } = require('./placement.js');

const { points, warnings, folds } = place([
  { id: 'open-syllables', g: 0.5, d: 0.12, side: +1, brk: 0.15, ab: 0, parent: 'method' },
  // ...
], { nBands: 5, subjectId: 'syllable-first' });
```

Pass `subjectId` so the subject is re-pinned to `lon 0` after placing.
Hierarchical allocation inherits its rotation from the parent band, and
nothing else re-establishes the convention that the subject faces the
reader when the file opens. The re-pin is a rigid rotation of the whole
orb, so it preserves every relative angle and costs nothing.

Each returned point carries `level`, `lon`, `lonRaw` and `drift`, and the
result carries the located `folds`. Read the warnings before the
coordinates: `band-overfull`, `no-breaks`, `no-fold`, `high-drift`,
`meridian-break`, `parents-too-tight`, `break-belongs-above` and
`ab-collinear` each name a specific authoring decision to revisit, and
none of them is fixed by adjusting a number in the output.
