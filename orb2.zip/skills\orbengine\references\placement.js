/* placement.js — orbengine point calculator, v1.2
 *
 * Turns semantic weights into lon/level coordinates arithmetically.
 * See placement.md for the reasoning.
 *
 * v1.2: arc is allocated by BREAK (adjacent dissimilarity) rather than
 * scaled linearly from d. The fold is located at the largest resulting
 * gap instead of imposed at a fixed span, and d is demoted from placement
 * driver to global coherence check.
 *
 * Node >= 18. No dependencies.
 */

'use strict';

const TAU = 360;
/* how much of the spare arc break scores are allowed to redistribute */
const SPREAD = 0.55;

/* ---------- geometry ------------------------------------------------- */

function latFor(level, nBands) {
  if (nBands < 2) return 0;
  return 58 - (116 * level) / (nBands - 1);
}

function minGapFor(level, nBands, baseGap = 30) {
  const lat = (latFor(level, nBands) * Math.PI) / 180;
  return baseGap / Math.cos(lat);
}

function capacityFor(level, nBands, baseGap = 30) {
  return Math.floor(TAU / minGapFor(level, nBands, baseGap));
}

function levelFor(g, nBands) {
  const idx = Math.round((1 - g) * (nBands - 1));
  return Math.min(nBands - 1, Math.max(0, idx));
}

function angDist(a, b) {
  const d = Math.abs(((a - b) % TAU + TAU) % TAU);
  return d > 180 ? TAU - d : d;
}

/* ---------- isotonic relaxation (unchanged from v1.1) ---------------- */

function pava(u) {
  const val = [], cnt = [];
  for (const x of u) {
    val.push(x); cnt.push(1);
    while (val.length > 1 && val[val.length - 2] > val[val.length - 1]) {
      const v2 = val.pop(), c2 = cnt.pop(), v1 = val.pop(), c1 = cnt.pop();
      val.push((v1 * c1 + v2 * c2) / (c1 + c2)); cnt.push(c1 + c2);
    }
  }
  const out = [];
  for (let i = 0; i < val.length; i++)
    for (let j = 0; j < cnt[i]; j++) out.push(val[i]);
  return out;
}

function sqCost(a, t) {
  let s = 0;
  for (let i = 0; i < a.length; i++) s += (a[i] - t[i]) ** 2;
  return s;
}

function solveLinear(t, m) {
  const n = t.length;
  const W = TAU - n * m;
  const u = t.map((x, i) => x - i * m);
  const mono = pava(u);
  if (mono[n - 1] - mono[0] <= W + 1e-9)
    return { b: mono, cost: sqCost(mono.map((b, i) => b + i * m), t) };
  let best = null;
  const lo = Math.min(...mono) - W, hi = Math.max(...mono);
  for (let s = 0; s <= 600; s++) {
    const v = lo + ((hi - lo) * s) / 600;
    const b = mono.map((x) => Math.min(v + W, Math.max(v, x)));
    const c = sqCost(b.map((x, i) => x + i * m), t);
    if (!best || c < best.cost) best = { b, cost: c };
  }
  return best;
}

function relax(targets, m) {
  const n = targets.length;
  if (n === 0) return [];
  if (n === 1) return [targets[0]];
  if (n * m > TAU + 1e-9)
    throw new Error(
      `band overfull: ${n} positions need ${(n * m).toFixed(1)}deg but only 360deg available (min gap ${m.toFixed(1)}deg)`
    );
  const idx = targets.map((a, i) => i).sort((x, y) => targets[x] - targets[y]);
  const sorted = idx.map((i) => targets[i]);
  let best = null;
  for (let cut = 0; cut < n; cut++) {
    const t = [];
    for (let k = 0; k < n; k++) {
      const j = (cut + k) % n;
      let v = sorted[j];
      while (k > 0 && v < t[k - 1]) v += TAU;
      t.push(v);
    }
    const base = t[0];
    const sol = solveLinear(t.map((x) => x - base), m);
    const a = sol.b.map((x, i) => x + i * m + base);
    if (!best || sol.cost < best.cost) best = { cost: sol.cost, a, cut };
  }
  const out = new Array(n);
  for (let k = 0; k < n; k++) {
    const j = (best.cut + k) % n;
    let v = best.a[k] % TAU;
    if (v < 0) v += TAU;
    out[idx[j]] = v;
  }
  return out;
}

/* ---------- v1.2: arc allocation by break ---------------------------- */

/**
 * Order the band, then spend the full 360 degrees in proportion to how
 * unlike each neighbouring pair is. The largest gap that falls out IS
 * the fold: it is not chosen, it is found.
 *
 * members: [{ t, brk }] where
 *   t   = side * d, the signed ordering key (-1 .. +1)
 *   brk = dissimilarity to the NEXT member around the ring (0..1)
 * Returns angles in member order.
 */
function allocateByBreak(members) {
  const n = members.length;
  if (n < 2) return members.map(() => 0);

  const order = members.map((_, i) => i).sort((a, b) => members[a].t - members[b].t);

  const brks = order.map((i) => {
    const b = members[i].brk;
    return typeof b === 'number' && b > 0 ? b : 1e-6;
  });
  const total = brks.reduce((a, b) => a + b, 0);

  const angles = new Array(n);
  let acc = 0;
  for (let k = 0; k < n; k++) {
    angles[order[k]] = acc;
    acc += (TAU * brks[k]) / total;
  }

  /* rotate so the band's reference member -- smallest |t| -- sits at 0 */
  let refIdx = 0, best = Infinity;
  members.forEach((m, i) => {
    const a = Math.abs(m.t);
    if (a < best) { best = a; refIdx = i; }
  });
  const shift = angles[refIdx];
  for (let i = 0; i < n; i++) {
    let v = (angles[i] - shift) % TAU;
    if (v < 0) v += TAU;
    angles[i] = v;
  }
  return angles;
}

/**
 * Hierarchical allocation. Children live inside their own parent's wedge;
 * breaks decide spacing WITHIN a wedge; the boundaries BETWEEN wedges are
 * inherited from wherever the band above placed the parents.
 *
 * The fold therefore recurses: a large break at level N-1 pushes two
 * parents apart, and that gap becomes the empty arc their children
 * inherit at level N. Meridian coherence holds by construction rather
 * than by audit.
 *
 * members: [{ t, brk, parentLon }]. Returns angles in member order.
 */
function allocateHierarchical(members, minGap) {
  const n = members.length;
  if (n < 2) return members.map((m) => m.parentLon || 0);

  /* group by parent longitude */
  const wedges = new Map();
  members.forEach((m, i) => {
    const key = m.parentLon === undefined ? '_' : String(m.parentLon);
    if (!wedges.has(key)) wedges.set(key, { lon: m.parentLon, idx: [] });
    wedges.get(key).idx.push(i);
  });

  const centres = [...wedges.values()]
    .filter((w) => w.lon !== undefined)
    .map((w) => w.lon)
    .sort((a, b) => a - b);

  /* Measure each wedge before placing any of it. A wedge of near-identical
   * siblings must come out NARROW; one carrying real internal variation
   * must get room. */
  for (const w of wedges.values()) {
    w.idx.sort((a, b) => members[a].t - members[b].t);
    let nearest = 360;
    for (const c of centres) {
      if (c === w.lon || w.lon === undefined) continue;
      nearest = Math.min(nearest, angDist(c, w.lon));
    }
    w.room = nearest === 360 ? 190 : nearest;
    w.brks = [];
    for (let j = 0; j < w.idx.length - 1; j++) {
      const b = members[w.idx[j]].brk;
      w.brks.push(typeof b === 'number' && b > 0 ? b : 1e-6);
    }
    w.B = w.brks.reduce((a, b) => a + b, 0);
  }

  /* One scale in degrees-per-unit-break, shared by every wedge, so a wedge
   * carrying three times the dissimilarity gets three times the arc.
   *
   * Bounded ONLY by the meridian envelope and the ring, never by how close
   * the parents happen to sit. Capping on parent spacing was silently
   * flattening the break signal to the minimum-gap floor: it made careful
   * scoring and no scoring produce the same ring. Where a wedge now wants
   * more arc than its neighbours leave, that is a real structural fact
   * about the band above, and it is reported rather than absorbed. */
  /* Sizing has to be anchored to something real, or it swings between two
   * failures: capped on parent spacing it collapses to the minimum-gap
   * floor and the break signal vanishes; scaled off raw break sums it
   * balloons to the meridian envelope.
   *
   * The anchor is legibility. Every wedge is guaranteed the arc its
   * members need to stay readable, gaps are reserved between wedges, and
   * only the SURPLUS is handed out in proportion to dissimilarity. So
   * breaks decide who gets the spare room, not whether anyone fits. */
  const multi = [...wedges.values()].filter((w) => w.idx.length > 1 && w.B > 0);
  const sumB = multi.reduce((a, w) => a + w.B, 0);
  let base = 0;
  for (const w of wedges.values()) base += (w.idx.length - 1) * minGap;
  const surplus = Math.max(0, TAU - base - wedges.size * minGap) * SPREAD;

  const angles = new Array(n);
  const tight = [];

  for (const w of wedges.values()) {
    const idx = w.idx;
    const k = idx.length;

    if (w.lon === undefined) {
      const sub = idx.map((i) => ({ t: members[i].t, brk: members[i].brk }));
      const a = allocateByBreak(sub);
      idx.forEach((i, j) => (angles[i] = a[j]));
      continue;
    }
    if (k === 1) { angles[idx[0]] = w.lon; continue; }

    const floor = (k - 1) * minGap;
    const share = sumB > 0 ? surplus * (w.B / sumB) : 0;
    const width = Math.min(190, floor + share);
    if (width > w.room) tight.push({ lon: w.lon, width: Math.round(width), room: Math.round(w.room) });

    let acc = w.lon - width / 2;
    idx.forEach((i, j) => {
      angles[i] = ((acc % TAU) + TAU) % TAU;
      if (j < k - 1) acc += (width * w.brks[j]) / w.B;
    });
  }
  angles.tight = tight;
  return angles;
}

/** Locate the fold: the widest gap around a placed ring. */
function findFold(angles, ids) {
  const n = angles.length;
  if (n < 2) return null;
  const idx = angles.map((_, i) => i).sort((a, b) => angles[a] - angles[b]);
  let best = { size: -1 };
  for (let k = 0; k < n; k++) {
    const a = idx[k], b = idx[(k + 1) % n];
    const size = ((angles[b] - angles[a]) % TAU + TAU) % TAU;
    if (size > best.size) best = { size, after: ids[a], before: ids[b], at: angles[a] };
  }
  return best;
}

/* ---------- statistics ----------------------------------------------- */

function pearson(xs, ys) {
  const n = xs.length;
  if (n < 4) return null;
  const mx = xs.reduce((a, b) => a + b, 0) / n;
  const my = ys.reduce((a, b) => a + b, 0) / n;
  let num = 0, dx = 0, dy = 0;
  for (let i = 0; i < n; i++) {
    const a = xs[i] - mx, b = ys[i] - my;
    num += a * b; dx += a * a; dy += b * b;
  }
  if (dx === 0 || dy === 0) return null;
  return num / Math.sqrt(dx * dy);
}

/* ---------- the calculator ------------------------------------------- */

/**
 * points: [{ id, band?, g, d, side, brk, ab, parent, parentLon? }]
 *   g    generality      [0,1]  1 = apex anchor        -> level
 *   d    ring distance   [0,1]  0 = band reference     -> ordering + coherence
 *   side +1 | -1                axis of variation      -> which way round
 *   brk  break to next   [0,1]  adjacent dissimilarity -> arc allocation
 *   ab   0..3                   topical removal, scored independently
 */
function place(points, opts = {}) {
  const nBands = opts.nBands || 5;
  const baseGap = opts.baseGap || 30;
  const meridianLimit = opts.meridianLimit === undefined ? 95 : opts.meridianLimit;

  const out = points.map((p) => ({
    ...p,
    level: p.band !== undefined ? p.band : levelFor(p.g, nBands),
  }));

  const warnings = [];
  const folds = [];
  const byId = new Map(out.map((p) => [p.id, p]));
  const byBand = new Map();
  for (const p of out) {
    if (!byBand.has(p.level)) byBand.set(p.level, []);
    byBand.get(p.level).push(p);
  }

  for (const level of [...byBand.keys()].sort((a, b) => a - b)) {
    const members = byBand.get(level);
    const m = minGapFor(level, nBands, baseGap);
    const cap = capacityFor(level, nBands, baseGap);

    if (members.length > cap) {
      warnings.push({
        kind: 'band-overfull', level,
        detail: `${members.length} positions, capacity ${cap} at lat ${latFor(level, nBands).toFixed(0)}deg`,
      });
      continue;
    }

    if (members.every((p) => typeof p.brk !== 'number') && members.length > 2) {
      warnings.push({
        kind: 'no-breaks', level,
        detail: `band ${level} has no brk scores -- arc fell back to even spacing, which is a slot count, not a placement`,
      });
    }

    const byId0 = new Map(out.map((q) => [q.id, q]));
    const hasParents = members.some((p) => {
      const par = byId0.get(p.parent);
      return (par && par.lon !== undefined) || p.parentLon !== undefined;
    });
    const shaped = members.map((p) => {
      const par = byId0.get(p.parent);
      const pl = par && par.lon !== undefined ? par.lon : p.parentLon;
      return { t: p.side * p.d, brk: p.brk, parentLon: pl };
    });
    const targets = hasParents
      ? allocateHierarchical(shaped, m)
      : allocateByBreak(shaped);
    if (targets.tight && targets.tight.length) {
      for (const t of targets.tight) {
        warnings.push({
          kind: 'parents-too-tight', level,
          detail: `a wedge at ${Math.round(t.lon)}deg needs ${t.width}deg of arc but its neighbours leave only ${t.room}deg -- band ${level - 1} is packed tighter than its children can sit under. Widen the break between those parents, or split a thread.`,
        });
      }
    }
    let solved;
    try {
      solved = relax(targets, m);
    } catch (e) {
      warnings.push({ kind: 'band-overfull', level, detail: e.message });
      continue;
    }

    members.forEach((p, i) => {
      p.lonRaw = targets[i];
      p.lon = Math.round(solved[i]) % TAU;
      p.drift = +angDist(targets[i], solved[i]).toFixed(1);
    });

    const fold = findFold(members.map((p) => p.lon), members.map((p) => p.id));
    if (fold) {
      folds.push({ level, after: fold.after, before: fold.before, size: +fold.size.toFixed(0) });
      if (fold.size < m * 1.5 && members.length > 3) {
        warnings.push({
          kind: 'no-fold', level,
          detail: `widest gap is only ${fold.size.toFixed(0)}deg -- the band has no discontinuity, so either it is a genuine cycle or the brk scores are flat`,
        });
      }
    }

    /* A break BETWEEN wedges is the parent band's business, not this
     * one's -- wedge boundaries are inherited. If the author scored a
     * large cross-wedge break, the discontinuity they felt is real but
     * belongs one level up, where the parents were placed. */
    const ordered = [...members].sort((a, b) => a.side * a.d - b.side * b.d);
    for (let i = 0; i < ordered.length - 1; i++) {
      const a = ordered[i], b = ordered[i + 1];
      if (a.parent === b.parent) continue;
      if (typeof a.brk === 'number' && a.brk > 0.6) {
        const pa = byId.get(a.parent), pb = byId.get(b.parent);
        const pl = pa && pa.lon !== undefined ? pa.lon : a.parentLon;
        const pr = pb && pb.lon !== undefined ? pb.lon : b.parentLon;
        if (pl !== undefined && pr !== undefined && angDist(pl, pr) < 60) {
          warnings.push({
            kind: 'break-belongs-above', id: a.id,
            detail: `brk ${a.brk} to "${b.id}" crosses a wedge boundary, but their parents sit only ${Math.round(angDist(pl, pr))}deg apart -- score that break between the parents in band ${level - 1}, not here`,
          });
        }
      }
    }
  }

  /* meridian */
  for (const p of out) {
    if (!p.parent || p.parent === 'null') continue;
    const par = byId.get(p.parent);
    const parLon = par ? par.lon : p.parentLon;
    if (parLon === undefined || p.lon === undefined) continue;
    const dist = angDist(p.lon, parLon);
    if (dist > meridianLimit) {
      warnings.push({
        kind: 'meridian-break', id: p.id,
        detail: `parent ${p.parent} is ${dist.toFixed(0)}deg away (limit ${meridianLimit}deg) -- widen the brk on the gap before this wedge`,
      });
    }
  }

  /* drift */
  for (const p of out) {
    if (p.drift !== undefined && p.drift > minGapFor(p.level, nBands, baseGap) * 0.75) {
      warnings.push({
        kind: 'high-drift', id: p.id,
        detail: `moved ${p.drift}deg from the angle its break asked for`,
      });
    }
  }

  /* Re-pin the subject to lon 0. geometry.md: lon 0 is the front at rest,
   * and the subject sits there so it faces the reader when the file opens.
   * Hierarchical allocation inherits its rotation from the parent band and
   * nothing else re-establishes this. A rigid rotation of the whole orb
   * preserves every relative angle, so it costs nothing. */
  const subject =
    (opts.subjectId && byId.get(opts.subjectId)) ||
    out.find((p) => p.subject === true) ||
    null;
  if (subject && subject.lon !== undefined && subject.lon !== 0) {
    const turn = subject.lon;
    for (const p of out) {
      if (p.lon === undefined) continue;
      p.lon = Math.round(((p.lon - turn) % TAU + TAU) % TAU);
    }
    for (const f of folds) if (f.at !== undefined) f.at = ((f.at - turn) % TAU + TAU) % TAU;
  }

  /* ab independence */
  const withAb = out.filter((p) => typeof p.ab === 'number' && typeof p.d === 'number');
  const rAb = pearson(withAb.map((p) => p.d), withAb.map((p) => p.ab));
  if (rAb !== null && Math.abs(rAb) > 0.9) {
    warnings.push({
      kind: 'ab-collinear',
      detail: `ab correlates with ring distance at r=${rAb.toFixed(2)}; ab is not adding an independent judgement`,
    });
  }

  return { points: out, warnings, folds, abRingCorrelation: rAb };
}

module.exports = {
  place, relax, pava, allocateByBreak, allocateHierarchical, findFold, levelFor,
  minGapFor, capacityFor, latFor, angDist, pearson,
};
