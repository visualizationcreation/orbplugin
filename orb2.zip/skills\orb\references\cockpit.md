# orb — the cockpit

The chrome is fixed; only the content varies. Read this before rendering
your first cockpit of a session. The physics live in `SKILL.md`, the
geometry in `references/physics.md`. Nothing here is restated there.

**These are SPECIFICATIONS, not illustrations.** The previous revision
shipped templates that showed what a cockpit looks like and never stated
what it must do, so every direction pad in the file rendered with a hand
cursor and no handler. Copy these blocks as given, handlers included.

---

## 0. The wiring contract

Three rules. They are not style guidance; a cockpit that breaks them is
broken.

1. **Any element carrying `cursor:pointer` carries a handler.** That is
   `.ob-pad`, `.ob-key`, `.ob-btn`, `.ob-sc` — every instance, every
   turn. Pads, buttons and chips call `sendPrompt('…')` with the text of
   the move they make. **`.ob-key` in the movement panel is the one
   exception to *what* the handler does**: its keys COMPOSE into the
   queue rather than firing, so they carry the panel's own listener. A
   handler is still mandatory; only its job differs.
2. **Any element displaying a value sends the NEXT value.** A settings
   chip reading `fov 3` sends `field of view 2`. One click cycles;
   nothing opens a menu.
3. **Anything not interactive must not look interactive.** This skill's
   own line is *"a control that looks adjustable is a promise."* The
   movement panel's `undo · clear` was a styled `<span>` for two
   revisions — it is now wired, and anything that cannot be wired loses
   its pointer cursor.

`sendPrompt(text)` is the host function that sends text as the user's
next message. It is the one external dependency of this file. **If the
environment has no widget tool, or no `sendPrompt`, fall back to the
numbered text format in `SKILL.md` — do not render a cockpit whose
buttons do nothing.**

---

## 1. The style block — emit once per turn, verbatim

```html
<style>
@import url('https://fonts.googleapis.com/css2?family=Newsreader:opsz,wght@6..72,300;6..72,500&family=Archivo:wght@400;500;600&family=IBM+Plex+Mono:wght@400;500;600&display=swap');
.ob,.ob *{box-sizing:border-box}
.ob{width:420px;max-width:100%;background:#16150f;color:#f6f3ec;font-family:Archivo,system-ui,sans-serif;border-radius:12px;overflow:hidden}
.ob-hd{display:flex;align-items:center;justify-content:space-between;padding:11px 14px;border-bottom:1px solid rgba(246,243,236,.10)}
.ob-brand{font:600 10px/1 'IBM Plex Mono',monospace;letter-spacing:.14em;color:oklch(.78 .13 70)}
.ob-meta{font:400 10px/1 'IBM Plex Mono',monospace;color:rgba(246,243,236,.42)}
.ob-body{padding:14px}
.ob-lbl{font:400 10px/1 'IBM Plex Mono',monospace;letter-spacing:.13em;color:rgba(246,243,236,.38)}
.ob-pos{font:500 19px/1.25 Newsreader,serif;margin-top:6px;text-wrap:pretty}
.ob-pos span{color:rgba(246,243,236,.5)}
.ob-delta{font:400 10px/1.4 'IBM Plex Mono',monospace;color:oklch(.78 .13 165);margin-top:8px}
.ob-scene{font:400 12.5px/1.5 Archivo,sans-serif;color:rgba(246,243,236,.62);margin-top:12px;text-wrap:pretty}
.ob-read{font:300 14.5px/1.55 Newsreader,serif;margin-top:9px;text-wrap:pretty}
.ob-one{font:400 11px/1.4 'IBM Plex Mono',monospace;color:rgba(246,243,236,.42);margin-top:12px}
.ob-gauges{margin-top:12px;padding:10px 12px;border:1px solid rgba(246,243,236,.10);border-radius:8px;background:rgba(246,243,236,.03);display:grid;grid-template-columns:repeat(5,1fr);gap:8px}
.ob-g{display:flex;flex-direction:column;gap:5px}
.ob-gl{font:400 8.5px/1 'IBM Plex Mono',monospace;letter-spacing:.08em;color:rgba(246,243,236,.4)}
.ob-gv{font:500 11px/1 Archivo,sans-serif;white-space:nowrap}
.ob-gb{height:3px;border-radius:2px;background:linear-gradient(90deg,oklch(.78 .13 70) var(--f),rgba(246,243,236,.13) var(--f))}
.ob-gb.thread{background:linear-gradient(90deg,oklch(.78 .13 165) var(--f),rgba(246,243,236,.13) var(--f))}
.ob-gb.grain{background:repeating-linear-gradient(90deg,oklch(.78 .13 165) 0 2px,transparent 2px 4px)}
.ob-gb.anchor{background:linear-gradient(90deg,rgba(246,243,236,.13) var(--f),oklch(.82 .13 30) var(--f))}
.ob-fig{margin-top:12px;padding:10px;border:1px solid rgba(246,243,236,.10);border-radius:8px;background:rgba(246,243,236,.03)}
.ob-fig svg{display:block;width:100%;height:auto}
.ob-cap{margin-top:5px;font:400 9px/1.4 'IBM Plex Mono',monospace;color:rgba(246,243,236,.38)}
.ob-photo{margin-top:12px;border:1px solid rgba(246,243,236,.10);border-radius:8px;overflow:hidden}
.ob-photo img{display:block;width:100%;height:auto}
.ob-photo .ob-cap{margin:0;padding:7px 9px}
.ob-compass{margin-top:14px;display:grid;grid-template-columns:1fr 132px 1fr;gap:8px;align-items:center}
.ob-wide{grid-column:1/4;display:flex;justify-content:center}
.ob-wide>.ob-pad{width:190px;text-align:center}
.ob-pad{padding:8px 9px;border:1px solid rgba(246,243,236,.16);border-radius:8px;background:rgba(246,243,236,.05);cursor:pointer}
.ob-pt{font:500 12.5px/1.25 Archivo,sans-serif}
.ob-pd{font:400 9px/1 'IBM Plex Mono',monospace;letter-spacing:.1em;color:rgba(246,243,236,.4);margin-top:4px}
.ob-pd.thread{color:oklch(.78 .13 165)}
.ob-orb{display:flex;flex-direction:column;align-items:center;gap:6px}
.ob-thread{margin-top:14px;padding-top:11px;border-top:1px dashed rgba(246,243,236,.14);display:grid;grid-template-columns:1fr 1fr;gap:8px}
.ob-thread .ob-pad{border-color:oklch(.78 .13 165 / .35);background:none}
.ob-thread .ob-pd{color:oklch(.78 .13 165)}
.ob-stack{display:flex;flex-direction:column;gap:7px;margin-top:12px}
.ob-fan{margin:7px 0 0 16px;border-left:1px solid rgba(246,243,236,.14);padding-left:12px;display:flex;flex-direction:column;gap:7px}
.ob-fan .ob-pad{background:none;padding:6px 9px}
.ob-fan .ob-pt{font-size:11.5px;color:rgba(246,243,236,.8)}
.ob-pad.primary{border-color:oklch(.78 .13 70 / .5);background:oklch(.78 .13 70 / .09)}
.ob-pad.home{border-color:oklch(.82 .13 30 / .5);background:oklch(.82 .13 30 / .10)}
.ob-sub{font:400 11px/1.4 Archivo,sans-serif;color:rgba(246,243,236,.5);margin-top:3px}
.ob-flag{display:flex;align-items:center;gap:7px;font:600 10px/1 'IBM Plex Mono',monospace;letter-spacing:.13em;color:oklch(.78 .13 165)}
.ob-flag.warn{color:oklch(.82 .13 30)}
.ob-flag.odd{color:oklch(.80 .13 310)}
.ob-chip{padding:5px 8px;border-radius:99px;background:rgba(246,243,236,.07);font:500 10px/1 'IBM Plex Mono',monospace;white-space:nowrap}
.ob-chips{display:flex;flex-wrap:wrap;gap:6px;margin-top:9px}
.ob-work{margin-top:12px;padding:12px;border:1px solid rgba(246,243,236,.13);border-radius:8px;background:rgba(246,243,236,.03);font:300 15px/1.6 Newsreader,serif;text-wrap:pretty}
.ob-cut{margin-top:9px;font:400 12px/1.5 Archivo,sans-serif;color:rgba(246,243,236,.4);text-decoration:line-through}
.ob-note{font:400 12px/1.45 Archivo,sans-serif;color:rgba(246,243,236,.72);margin-top:8px}
.ob-note b{font:600 10px 'IBM Plex Mono',monospace;letter-spacing:.1em;color:oklch(.78 .13 165)}
.ob-note.cost b{color:oklch(.82 .13 30)}
.ob-btn{padding:10px;border-radius:7px;background:oklch(.78 .13 70);color:#16150f;text-align:center;font:600 12px/1 Archivo,sans-serif;cursor:pointer}
.ob-btn.warn{background:oklch(.68 .16 30)}
.ob-btn.ghost{background:none;border:1px solid rgba(246,243,236,.2);color:#f6f3ec;font-weight:500}
.ob-key{border:1px solid rgba(246,243,236,.2);border-radius:6px;display:flex;align-items:center;justify-content:center;padding:9px 10px;font:500 11px 'IBM Plex Mono',monospace;cursor:pointer}
.ob-key.thread{border-color:oklch(.78 .13 165 / .45);color:oklch(.78 .13 165)}
.ob-set{margin-top:14px;padding-top:11px;border-top:1px solid rgba(246,243,236,.10);display:flex;flex-wrap:wrap;gap:6px;align-items:center}
.ob-sc{padding:5px 8px;border-radius:99px;border:1px solid rgba(246,243,236,.14);background:rgba(246,243,236,.04);font:400 9.5px/1 'IBM Plex Mono',monospace;color:rgba(246,243,236,.5);cursor:pointer;white-space:nowrap}
.ob-sc b{font-weight:600;color:oklch(.78 .13 70)}
.ob-sc.odd b{color:oklch(.80 .13 310)}
.ob-exit{margin-top:11px;font:400 10px/1.5 'IBM Plex Mono',monospace;color:rgba(246,243,236,.34);text-wrap:pretty}
.ob-exit code{color:rgba(246,243,236,.55)}
</style>
```

## 2. The shell — every turn, in this order

```html
<div class="ob">
  <div class="ob-hd">
    <span class="ob-brand">ORB</span>
    <span class="ob-meta">{mode} · {shape} · stop {n}</span>
  </div>
  <div class="ob-body">
    <div class="ob-lbl">POSITION</div>
    <div class="ob-pos">{position} · <span>{altitude or work state}</span></div>
    <div class="ob-delta">{whatever reading moved, and why}</div>

    <!-- INSTRUMENTS: one plain sentence by default, or the gauge block -->
    <div class="ob-one">{one-sentence reading}</div>

    <div class="ob-scene">{scenery, 1–2 sentences}</div>
    <div class="ob-read">{reading}</div>   <!-- or the WORK block, verb mode -->

    <!-- PHOTOGRAPH, when THIS POSITION has a referent -->
    <!-- ILLUSTRATION -->
    <!-- MOVES: compass, or stack -->
    <!-- SETTINGS STRIP -->
    <!-- EXIT LINE — every turn, no exceptions, never a button -->
  </div>
</div>
```

`.ob-delta` sits **directly under the position and outside the gauge
block**. It was nested inside `.ob-gauges` for two revisions while the
prose called it the most useful line on the panel — and the gauge block
is hidden by default, so on a typical turn the most useful line was not
rendered at all. Omit it on turn one only.

## 3. Blocks

### Gauges — when a reading starts mattering

Five cells, in the order given by the instrument table in `SKILL.md`.
`--f` is the fill fraction; set it to the reading, never to a flattering
number.

`.grain` is a texture with no fill — grain is a category, not a
magnitude. `.thread` colours reach. `.anchor` fills from the RIGHT in
warning red, so a drifting session looks wrong at a glance; `--f` is the
fraction still in view, meaning 100% is home and 0% is out of sight.

```html
<div class="ob-gauges">
  <div class="ob-g"><span class="ob-gl">DEPTH</span><span class="ob-gv">4</span><span class="ob-gb" style="--f:80%"></span></div>
  <div class="ob-g"><span class="ob-gl">ANCHOR</span><span class="ob-gv">2 removed</span><span class="ob-gb anchor" style="--f:40%"></span></div>
  <div class="ob-g"><span class="ob-gl">RING</span><span class="ob-gv">9</span><span class="ob-gb" style="--f:70%"></span></div>
  <div class="ob-g"><span class="ob-gl">REACH</span><span class="ob-gv">2↤ 3↦</span><span class="ob-gb thread" style="--f:62%"></span></div>
  <div class="ob-g"><span class="ob-gl">GRAIN</span><span class="ob-gv">fine</span><span class="ob-gb grain"></span></div>
</div>
```

Verb mode swaps labels 1 and 3 to `DISTANCE` and `OPTIONS`. Cramped turns
may use `.ob-chips` instead of the grid; the anchor chip takes
`style="background:oklch(.82 .13 30 / .22);color:oklch(.82 .13 30)"` at
`2 removed` or worse.

### Photograph — when the current position has a referent

Raster data URL only. Remote `src` is blocked; SVG in an `img` is
blocked; inline `<svg>` markup works. See `SKILL.md`.

```html
<div class="ob-photo">
  <img src="data:image/jpeg;base64,{…}" alt="{what it shows}">
  <div class="ob-cap">{what it shows · where it came from}</div>
</div>
```

A dropped image names itself in the slot where it would have gone:

```html
<div class="ob-cap" style="margin-top:8px">illustration dropped — one image block on turn one, and the photograph outranks it in the cut order.</div>
```

Declining renders one line and names the missing referent class:

```html
<div class="ob-cap" style="margin-top:8px">photograph: none — {referent class that is missing, e.g. this position is a legal threshold, not an object}. {n} consecutive stops without a referent.</div>
```

And the fourth outcome, which does **not** advance the drought:

```html
<div class="ob-cap" style="margin-top:8px">photograph: referent present, image unsourceable — {what exists and why it cannot be sourced}. Drought unchanged at {n}.</div>
```

### Illustration — every turn

```html
<div class="ob-fig">
  <svg viewBox="0 0 360 110">…</svg>
  <div class="ob-cap">{what the drawing shows}</div>
</div>
```

Explanatory, not decorative. Axis labels in IBM Plex Mono 9px,
`rgba(246,243,236,.45)`; one series in `oklch(.78 .13 70)`, a second in
`oklch(.78 .13 165)` dashed. Never more than two series.

### Moves — compass form

Use when labels are short. **Fans do not fit the compass** — the
left/right cells are ~110px and a fan is an indented column. So: if any
pad this turn carries a fan, use the stack form. If you drop to the
compass to keep labels tight, the fans close, and that closure needs a
cited reason like any other.

```html
<div class="ob-compass">
  <div class="ob-wide"><div class="ob-pad" onclick="sendPrompt('UP · part-of — Leavening, broadly')"><div class="ob-pt">Leavening, broadly</div><div class="ob-pd">UP · the whole</div></div></div>
  <div class="ob-pad" onclick="sendPrompt(&quot;LEFT — The starter's ecology&quot;)"><div class="ob-pt">The starter's ecology</div><div class="ob-pd">LEFT</div></div>
  <div class="ob-orb">{orb svg}<span class="ob-cap">you are here</span></div>
  <div class="ob-pad" onclick="sendPrompt('RIGHT — Dough rheology')"><div class="ob-pt">Dough rheology</div><div class="ob-pd">RIGHT</div></div>
  <div class="ob-wide"><div class="ob-pad" onclick="sendPrompt('DOWN — Maltose metabolism')"><div class="ob-pt">Maltose metabolism</div><div class="ob-pd">DOWN · the mechanism</div></div></div>
</div>
<div class="ob-thread">
  <div class="ob-pad" onclick="sendPrompt('FORWARD — Why the loaf tastes sour')"><div class="ob-pt">Why the loaf tastes sour</div><div class="ob-pd">FORWARD · leads to</div></div>
  <div class="ob-pad" onclick="sendPrompt('BACKWARD — Grain, water, wild spores')"><div class="ob-pt">Grain, water, wild spores</div><div class="ob-pd">BACKWARD · follows from</div></div>
</div>
```

Drop `.ob-thread` entirely when the thread is dead — never an empty pair.
Axes are atomic: dropping it drops both.

### Moves — stack form

The default. Use on turn one, on frontier rooms, in verb mode, whenever
labels are sentences, and whenever any fan is open.

**Pad order in the stack is fixed:** UP (and its fan) · DOWN · LEFT ·
RIGHT · FORWARD · BACKWARD. The thread pair keeps its visual separation
in stack form too — put `border-top:1px dashed rgba(246,243,236,.14);
padding-top:11px;margin-top:11px` on the FORWARD pad, because "move the
orb" and "move on the orb" are not the same kind of move and the compass
form says so with a rule.

```html
<div class="ob-stack">
  <div class="ob-pad" onclick="sendPrompt('DOWN — What the bacteria are actually eating')">
    <div class="ob-pt">What the bacteria are actually eating</div>
    <div class="ob-sub">{one line on why this destination}</div>
    <div class="ob-pd">DOWN · the mechanism</div>
  </div>
</div>
```

Direction captions become plain English on turn one — `go deeper`,
`zoom out`, `next door`.

### Branch fan

Always visible, indented under its pad, never behind a hover or
`display:none` — hidden content streams invisibly and arrives blank.

```html
<div class="ob-pad primary" onclick="sendPrompt('UP · part-of — The building this belongs to')">
  <div class="ob-pt">The building this belongs to</div>
  <div class="ob-sub">the primary — the whole, and the subject survives</div>
  <div class="ob-pd">UP · the whole</div>
</div>
<div class="ob-fan">
  <div class="ob-pad" onclick="sendPrompt('UP · instance-of — Condominiums as a category (anchor-shedding)')">
    <div class="ob-pt">Condominiums as a category</div>
    <div class="ob-sub">instance-of · sheds the anchor</div>
  </div>
</div>
```

### The return pad — at anchor `2 removed` or worse

DOWN's primary becomes the way home, and it is styled so it reads as
different from an ordinary destination.

```html
<div class="ob-pad home" onclick="sendPrompt('DOWN — back toward {anchor}')">
  <div class="ob-pt">Back toward {anchor}</div>
  <div class="ob-sub">the way home — {n} moves out</div>
  <div class="ob-pd">DOWN · return</div>
</div>
```

### The orb graphic — the marker is computed, not guessed

**Not on turn one.** With no trail and the marker at dead centre it
costs about 110px to convey nothing; it earns its slot from stop two.

```html
<svg viewBox="0 0 120 120" style="width:104px;height:104px">
  <circle cx="60" cy="60" r="46" fill="none" stroke="rgba(246,243,236,.16)"/>
  <ellipse cx="60" cy="60" rx="46" ry="17" fill="none" stroke="rgba(246,243,236,.13)"/>
  <ellipse cx="60" cy="60" rx="46" ry="33" fill="none" stroke="rgba(246,243,236,.08)"/>
  <ellipse cx="60" cy="60" rx="17" ry="46" fill="none" stroke="rgba(246,243,236,.13)"/>
  <ellipse cx="60" cy="60" rx="33" ry="46" fill="none" stroke="rgba(246,243,236,.08)"/>
  <polyline points="{last 4 markers}" fill="none" stroke="rgba(246,243,236,.30)" stroke-dasharray="2 3"/>
  <circle cx="{x}" cy="{y}" r="5.5" fill="oklch(.78 .13 70)"/>
  <circle cx="{x}" cy="{y}" r="10" fill="none" stroke="oklch(.78 .13 70)" stroke-opacity=".4"/>
</svg>
```

The old instruction was "decorative-but-consistent", which is
unachievable without a mapping, so every turn invented coordinates and
the trail polyline was noise. **The mapping:**

- `a` = net UP moves minus net DOWN moves since the session started.
- `r` = net RIGHT minus net LEFT.
- `w` = current ring width, floor 4.
- **`y = clamp(60 − 12a, 18, 102)`** — up is up.
- **`x = 60 + round(34 · sin(2π · r / w))`** — the ring closes because
  the sine closes.
- The polyline is the last four `(x,y)` pairs, oldest first.

Thread moves do not move the marker; they relocate the neighbourhood, so
they reset the trail polyline to the current point alone. Do not redraw
the sphere.

### Settings strip — every turn, last in the body

**Turn one uses the SHORT strip below, not the full row.** The previous
revision shipped only the nine-chip block and told you to copy blocks as
given, so a compliant turn one rendered sixteen elements against a
twelve-element manifest.

```html
<div class="ob-set">
  <span class="ob-sc" onclick="sendPrompt('orb: field of view 2')">fov <b>3</b>/3 axes</span>
  <span class="ob-sc" onclick="sendPrompt('orb: switch to verb mode')">mode <b>noun</b></span>
  <span class="ob-sc odd" onclick="sendPrompt('creative mode on')">creative <b>off</b></span>
  <span class="ob-sc" onclick="sendPrompt('orb: map density dense')">density <b>normal</b></span>
  <span class="ob-sc" onclick="sendPrompt('show all orb settings')">more</span>
</div>
```

**Every turn from stop two shows the full row below** — not only after
`more` is pressed. Each chip displays the value in force and sends the
next one. **Suppress the `triangulate` chip on any turn the unasked
triangulate PAD is mounted**, or the same affordance renders twice.

```html
<div class="ob-set">
  <span class="ob-sc" onclick="sendPrompt('orb: field of view 2')">fov <b>3</b>/3 axes</span>
  <span class="ob-sc" onclick="sendPrompt('orb: step size 2')">step <b>1</b></span>
  <span class="ob-sc" onclick="sendPrompt('orb: map density dense')">density <b>normal</b></span>
  <span class="ob-sc" onclick="sendPrompt('orb: switch to verb mode')">mode <b>noun</b></span>
  <span class="ob-sc odd" onclick="sendPrompt('creative mode on')">creative <b>off</b></span>
  <span class="ob-sc" onclick="sendPrompt('show the movement panel')">movement panel</span>
  <span class="ob-sc" onclick="sendPrompt('triangulate the anchor against here')">triangulate</span>
  <span class="ob-sc" onclick="sendPrompt('show the trail')">trail</span>
  <span class="ob-sc" onclick="sendPrompt('park the orb')">park</span>
</div>
```

Field of view cycles 3 → 2 → 1 → 3. **No chip for grain or anchor.** They
are measurements, and a chip is a handle; giving one to a reading is the
exact failure the controls-versus-readings rule exists to prevent.

**The mode chip is hardcoded above for a noun session.** In a verb
session it must read `mode verb` and send `switch to noun mode`. That is
not an edit to the chrome; it is the chip doing its stated job of
displaying the value in force and sending the next one.

### The exit line — last thing in the card, every turn

```html
<div class="ob-exit">type anything to just talk — a question, a correction, a change of subject. Your place is held. <code>park</code> holds it explicitly, <code>resume</code> comes back.</div>
```

No pointer cursor and no handler, which is correct under the wiring
contract: it does not look interactive because it is not. It costs zero
clickable elements, which is why it fits on a turn already at its wall.

### Movement panel — with its script

The queue never fires on click; one explicit button flies it. The script
below is the implementation — ship it, do not reinvent it per session.

```html
<div class="ob-body" style="border-top:1px solid rgba(246,243,236,.10)">
  <div class="ob-hd" style="padding:0 0 12px"><span class="ob-brand">MOVEMENT</span><span class="ob-meta">step 1 · fov 3</span></div>
  <div style="display:flex;gap:14px;align-items:center">
    <div style="display:grid;grid-template-columns:repeat(3,48px);grid-template-rows:repeat(3,34px);gap:5px">
      <div></div><div class="ob-key" data-d="UP">UP</div><div></div>
      <div class="ob-key" data-d="LEFT">←</div><div>{small orb svg}</div><div class="ob-key" data-d="RIGHT">→</div>
      <div></div><div class="ob-key" data-d="DOWN">DOWN</div><div></div>
    </div>
    <div style="flex:1;padding-left:14px;border-left:1px dashed rgba(246,243,236,.16);display:flex;flex-direction:column;gap:5px">
      <div class="ob-lbl">MOVE THE ORB</div>
      <div class="ob-key thread" data-d="FORWARD">FORWARD ↦</div>
      <div class="ob-key thread" data-d="BACKWARD">BACKWARD ↤</div>
    </div>
  </div>
  <div style="margin-top:13px;padding:10px 11px;border:1px solid rgba(246,243,236,.14);border-radius:8px">
    <div style="display:flex;justify-content:space-between;align-items:center">
      <span id="mq" style="font:500 12px 'IBM Plex Mono',monospace;color:rgba(246,243,236,.75)">queue empty</span>
      <span class="ob-meta"><span id="mu" style="cursor:pointer">undo</span> · <span id="mc" style="cursor:pointer">clear</span></span>
    </div>
    <div class="ob-stack" id="mp" style="gap:4px"></div>
    <div class="ob-btn" id="mf" style="margin-top:10px">Fly the sequence</div>
  </div>
</div>
<script>
(function(){
var map={UP:"{up dest}",DOWN:"{down dest}",LEFT:"{left dest}",RIGHT:"{right dest}",FORWARD:"{fwd dest}",BACKWARD:"{back dest}"};
var root=document.currentScript.parentNode,q=[],qs=root.querySelector("#mq"),pv=root.querySelector("#mp");
function draw(){
 if(!q.length){qs.textContent="queue empty";pv.innerHTML='<div class="ob-cap" style="margin:0">press a direction to compose a flight — nothing fires until you fly it</div>';return}
 var c=[],last=null,n=0;
 q.forEach(function(d){if(d===last){n++}else{if(last)c.push(n+" "+last.toLowerCase());last=d;n=1}});
 c.push(n+" "+last.toLowerCase());
 qs.textContent=c.join(" · ");
 var h="";
 q.forEach(function(d,i){h+='<div class="ob-cap" style="margin:0">'+(i+1)+' · '+d+' → '+(i===0?map[d]:"unmapped from here")+'</div>'});
 if(q.length>1)h+='<div class="ob-cap" style="margin:2px 0 0;color:oklch(.78 .13 165)">beyond one stop the terrain is not honestly visible — the flight halts if a move is not there</div>';
 pv.innerHTML=h}
root.querySelectorAll("[data-d]").forEach(function(k){k.addEventListener("click",function(){q.push(k.getAttribute("data-d"));draw()})});
root.querySelector("#mu").addEventListener("click",function(){q.pop();draw()});
root.querySelector("#mc").addEventListener("click",function(){q=[];draw()});
root.querySelector("#mf").addEventListener("click",function(){if(q.length)sendPrompt("fly the sequence: "+q.join(", "))});
draw()})();
</script>
```

Only the first stop is previewed by name. Past that the honest word is
`unmapped`.

### Flight frames

Every move is a frame — never a summary of where the chain ended. An
intermediate frame is the shell cut down to position, one sentence of
what changed, and the anchor reading, plus `border-left:3px solid
oklch(.78 .13 70)` on `.ob`. Make each one clickable to halt there:

```html
<div class="ob frame" onclick="sendPrompt('halt the flight at frame {n} — {position}')">
  <div class="ob-body" style="padding:10px 13px">
    <div class="ob-meta">frame {n}/{total} · {DIRECTION} · anchor {reading}</div>
    <div class="ob-pos" style="font-size:14px;margin-top:3px">{position}</div>
    <div style="font:400 11.5px/1.45 Archivo,sans-serif;color:rgba(246,243,236,.58);margin-top:6px">{what changed}</div>
  </div>
</div>
```

Add `.ob.frame{border-radius:0 12px 12px 0;margin-bottom:6px;cursor:pointer}`.
A halt swaps the border to `oklch(.68 .16 30)` and names the move that
failed and the terrain that stopped it. The destination frame is full.

### Frontier

`.ob` gets `border-top:3px solid oklch(.78 .13 165)`. Flag row, position,
then the blocker line — the type is mandatory and comes from the seven in
`SKILL.md`.

```html
<div class="ob-flag">FRONTIER<span class="ob-meta" style="margin-left:auto">floor of the known</span></div>
<div style="margin-top:10px;padding:9px 11px;border-radius:8px;background:rgba(246,243,236,.05);font:400 11px/1.45 'IBM Plex Mono',monospace;color:rgba(246,243,236,.62)">blocker: <span style="color:oklch(.78 .13 165)">{one of the seven types}</span> — {why}</div>
```

**Do not hardcode a blocker type.** The previous revision shipped
`information gap` literally in this template, which is defined as *"the
answer exists in the world but not in this session"* — never true at a
knowledge frontier. A model copying the block shipped a blocker that
contradicted the frontier it was labelling. Pick from the seven in
`SKILL.md`; `open question` is the noun-frontier default.

At a frontier every fan closes, but the RETURN PAD is not a fan
alternate — when the anchor reads `2 removed` or worse at a frontier, it
renders as an extra stack pad below the six, so the road home never
vanishes at the position where drift is worst.

Moves render as the stack, in the frontier's own six-direction order —
see `SKILL.md`. The old caption `condition / experiment / workaround /
head-on` mapped those onto the wrong axes and is gone.

### Terminus — an exhausted direction

A terrain edge exhausts one end of an axis. It is not a dropped half-axis
and it must never be silent or a dead pad. Render the exhausted end as a
terminus in the pad's slot:

```html
<div style="padding:8px 9px;border:1px dashed rgba(246,243,236,.18);border-radius:8px;opacity:.72">
  <div class="ob-pt" style="color:rgba(246,243,236,.6)">UP — nothing above this</div>
  <div class="ob-sub">{why: the next step up is "systems", which is true and says nothing}</div>
  <div class="ob-pd">TERMINUS · the axis is intact, this end has run out</div>
</div>
```

No pointer cursor, no handler — and that is consistent with the wiring
contract, because it does not look interactive.

The **ceiling frontier** uses the same chrome with the meta reading
`ceiling of the useful` and no blocker line — it is a terrain edge, not
an obstacle. **UP renders as the TERMINUS block above, never as an
omission** — an absent pad is silence, and silence fails the
axes-are-atomic rule and assertion A2 alike.

### Verb mode work + cost

```html
<div class="ob-work">{the artifact as it now stands}<div class="ob-cut">{what the move removed}</div></div>
<div class="ob-note"><b>CHANGED</b> {what the move did}</div>
<div class="ob-note cost"><b>COST</b> {a concrete thing lost or risked}</div>
```

The cost note is not optional and not hedgeable.

### Armed one-way move

```html
<div class="ob" style="border:1px solid oklch(.68 .16 30 / .55)">
  <div class="ob-body">
    <div class="ob-flag warn">ARMED · ONE-WAY</div>
    <div class="ob-pos" style="font-size:15px">{the move}</div>
    <div class="ob-scene">{what stops being reversible}</div>
    <div style="display:flex;gap:8px;margin-top:12px">
      <div class="ob-btn warn" style="flex:1" onclick="sendPrompt('fire it — {the move}')">Fire it</div>
      <div class="ob-btn ghost" style="flex:1" onclick="sendPrompt('disarm')">Disarm</div>
    </div>
  </div>
</div>
```

This card is where verb-mode reversibility lives, which is why it is not
a permanent gauge.

### Triangulator

Base points at the lower corners, apex at the top; the two readings sit
in one bordered row below and never join the permanent panel. The
degenerate verdict uses `.ob-flag warn`, names the trivial link it
rejected, and offers two narrower bases as wired pads.

### Creative mode

One banner strip above the position,
`background:linear-gradient(90deg,oklch(.55 .18 310 / .30),transparent)`
with `.ob-flag odd`. The wildcard pad takes
`border-color:oklch(.80 .13 310 / .5);background:oklch(.55 .18 310 / .12)`
and the caption `WILDCARD · resolves on entry`. It is wired like any
other pad.

### Trail and parking

Trail is a dotted rail; visited nodes hollow, current filled
`oklch(.78 .13 70)`, each labelled with the direction that reached it,
and the anchor marked. Parking renders one light bar and then nothing:

```html
<div class="ob" style="background:#e8e4db;color:#16150f;font-family:'IBM Plex Mono',monospace;padding:13px 14px;display:flex;justify-content:space-between;align-items:center;gap:12px">
  <div style="font:400 11.5px/1.45">Parked at <strong>{position}</strong> · anchor {anchor} · {mode} · fov {n} · step {n}. Held.</div>
  <div style="font:500 11px;padding:7px 10px;border:1px solid rgba(22,21,15,.28);border-radius:6px;cursor:pointer" onclick="sendPrompt('resume')">resume</div>
</div>
```

---

## 4. What must never be edited

Card width, the three accents — `oklch(.78 .13 70)` amber for the surface
axes, `oklch(.78 .13 165)` jade for the thread axis and frontiers,
`oklch(.68 .16 30)` red reserved for one-way moves and halts, with
`oklch(.82 .13 30)` for the anchor warning — the three fonts, and the
gauge rendering. Everything a turn changes is content.

This file is the live reference. Earlier revisions pointed at a
standalone cockpit HTML file that was never packaged with the skill, so
the declared source of truth did not exist wherever the skill actually
ran.
